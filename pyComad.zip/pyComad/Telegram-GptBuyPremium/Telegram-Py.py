# Telegram-Py.py (для aiogram 3.x)
import os
import json
from datetime import datetime
import asyncio
import logging
from typing import Dict, List, Optional

from aiogram import Bot, Dispatcher, types, Router, F
from aiogram.types import (
    ReplyKeyboardMarkup, 
    KeyboardButton, 
    InlineKeyboardMarkup, 
    InlineKeyboardButton,
    ReplyKeyboardRemove,
    InputMediaPhoto
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.state import StatesGroup, State
from aiogram.filters import Command, StateFilter
from aiogram.utils.markdown import hbold, hlink

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Конфигурация
TOKEN = "7924281348:AAFemTxnC6zgHR7XfkSvXo-6Ozxy7ik1tfU"
ADMIN_ID = 8550701850
DATA_PATH = "/storage/emulated/0/Download/pyComad/Telegram-GptBuyPremium/"

router = Router()

# Модели ИИ с ценами и ИЗОБРАЖЕНИЯМИ
AI_MODELS = {
    "chatgpt_premium": {
        "name": "🤖 ChatGPT Premium",
        "description": "Полный доступ к GPT-5 Plus, DALL-E 3, расширенный контекст",
        "original_price": 22,
        "our_price": 13.99,
        "currency": "USD",
        # ========== ИЗОБРАЖЕНИЕ ChatGPT ==========
        "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/ChatGPT_logo.svg/512px-ChatGPT_logo.svg.png",
        "features": [
            "🔹 GPT-5 Plus без ограничений",
            "🔹 DALL-E 3 (генерация изображений)",
            "🔹 128K контекст",
            "🔹 Файловые загрузки",
            "🔹 Веб-поиск",
            "🔹 Кастомные GPTs"
        ],
        "payment_links": {
            1: "http://t.me/send?start=IVrAd3kp4DZA",
            3: "http://t.me/send?start=IVf25rd3aTmE", 
            6: "http://t.me/send?start=IVhUOtL6iaSP",
            12: "http://t.me/send?start=IVzBhCvVzoJq"
        }
    },
    "claude_pro": {
        "name": "🧠 Claude Pro",
        "description": "Расширенный доступ к Claude 3 с большим контекстом",
        "original_price": 100,
        "our_price": 29.00,
        "currency": "USD",
        # ========== ИЗОБРАЖЕНИЕ Claude ==========
        "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Anthropic_logo.svg/512px-Anthropic_logo.svg.png",
        "features": [
            "🔹 Claude 3 Opus/Sonnet",
            "🔹 200K контекстное окно",
            "🔹 Приоритетный доступ",
            "🔹 Увеличенные лимиты",
            "🔹 Ранний доступ к новым функциям"
        ],
        "payment_links": {
            1: "http://t.me/send?start=IVcXqn4svwxI",
            3: "http://t.me/send?start=IVhUOtL6iaSP",
            6: "http://t.me/send?start=IVbZXHLsaTLm",
            12: "http://t.me/send?start=IVG6S9dJLUqP"
        }
    },
    "midjourney_premium": {
        "name": "🎨 Midjourney Premium",
        "description": "Неограниченная генерация изображений",
        "original_price": 60,
        "our_price": 25.00,
        "currency": "USD",
        # ========== ИЗОБРАЖЕНИЕ Midjourney ==========
        "image_url": "https://upload.wikimedia.org/wikipedia/commons/e/e6/Midjourney_Emblem.png",
        "features": [
            "🔹 Неограниченная fast генерация",
            "🔹 Приватный режим",
            "🔹 Все модели (V6, Niji)",
            "🔹 Коммерческое использование",
            "🔹 Concurrent jobs"
        ],
        "payment_links": {
            1: "http://t.me/send?start=IVxUHhrE9BOD",
            3: "http://t.me/send?start=IVvju5BqXvPG",
            6: "http://t.me/send?start=IVADehIO9jvo",
            12: "http://t.me/send?start=IVTUT4obhrqu"
        }
    },
    "copilot_pro": {
        "name": "💼 Microsoft Copilot Pro",
        "description": "AI помощник для Office и Windows",
        "original_price": 60,
        "our_price": 31.00,
        "currency": "USD",
        # ========== ИЗОБРАЖЕНИЕ Copilot ==========
        "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Microsoft_365_Copilot_Icon.svg/512px-Microsoft_365_Copilot_Icon.svg.png",
        "features": [
            "🔹 GPT-4 в чатах",
            "🔹 Copilot в Word/Excel/PowerPoint",
            "🔹 Приоритетный доступ в часы пик",
            "🔹 Дизайнер изображений (DALL-E 3)",
            "🔹 Расширенный анализ данных"
        ],
        "payment_links": {
            1: "http://t.me/send?start=IVeYZcJn9oW5",
            3: "http://t.me/send?start=IVQZA9Tw5LVx",
            6: "http://t.me/send?start=IVbZXHLsaTLm",
            12: "http://t.me/send?start=IVG6S9dJLUqP"
        }
    },
    "perplexity_pro": {
        "name": "🔍 Perplexity Pro",
        "description": "Поисковик с ИИ и точными источниками",
        "original_price": 20,
        "our_price": 13.99,
        "currency": "USD",
        # ========== ИЗОБРАЖЕНИЕ Perplexity ==========
        "image_url": "https://uxwing.com/wp-content/themes/uxwing/download/brands-and-social-media/perplexity-ai-icon.png",
        "features": [
            "🔹 Неограниченные Pro-запросы",
            "🔹 Загрузка файлов (PDF, Word)",
            "🔹 Доступ к Claude 3",
            "🔹 Приоритетная поддержка",
            "🔹 Экспорт в разные форматы"
        ],
        "payment_links": {
            1: "http://t.me/send?start=IVDM2BXv8zWa",
            3: "http://t.me/send?start=IVf25rd3aTmE",
            6: "http://t.me/send?start=IVhUOtL6iaSP",
            12: "http://t.me/send?start=IVzBhCvVzoJq"
        }
    }
}

# Альтернативный способ оплаты
DONATION_ALERTS_LINK = "https://www.donationalerts.com/r/joeio"

# Периоды подписки (в месяцах)
SUBSCRIPTION_PERIODS = [1, 3, 6, 12]

# FSM состояния
class OrderState(StatesGroup):
    selecting_model = State()
    viewing_model_details = State()
    selecting_period = State()
    selecting_accounts = State()
    confirming_order = State()
    waiting_admin_message = State()

# ========== НОВОЕ: Состояния для админа ==========
class AdminState(StatesGroup):
    waiting_reply = State()

# Создание папки и файлов
if not os.path.exists(DATA_PATH):
    os.makedirs(DATA_PATH)

USER_FILE = os.path.join(DATA_PATH, "users.json")
ORDERS_FILE = os.path.join(DATA_PATH, "orders.json")

def init_files():
    """Инициализация JSON файлов"""
    if not os.path.exists(USER_FILE):
        with open(USER_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f)
    
    if not os.path.exists(ORDERS_FILE):
        with open(ORDERS_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)

init_files()

# Сохранение пользователя
def save_user(user: types.User):
    """Сохранение нового пользователя в БД"""
    try:
        with open(USER_FILE, "r", encoding="utf-8") as f:
            users = json.load(f)
        
        user_id = str(user.id)
        if user_id not in users:
            users[user_id] = {
                "username": user.username,
                "first_name": user.first_name,
                "join_date": datetime.now().isoformat(),
                "orders_count": 0
            }
            
            with open(USER_FILE, "w", encoding="utf-8") as f:
                json.dump(users, f, ensure_ascii=False, indent=2)
            
            logger.info(f"Новый пользователь: {user_id} (@{user.username})")
    except Exception as e:
        logger.error(f"Ошибка сохранения пользователя: {e}")

def save_order(order_data: Dict):
    """Сохранение заказа"""
    try:
        with open(ORDERS_FILE, "r", encoding="utf-8") as f:
            orders = json.load(f)
        
        order_data["order_id"] = len(orders) + 1
        order_data["created_at"] = datetime.now().isoformat()
        order_data["status"] = "pending"
        
        orders.append(order_data)
        
        with open(ORDERS_FILE, "w", encoding="utf-8") as f:
            json.dump(orders, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Новый заказ #{order_data['order_id']}")
        return order_data["order_id"]
    except Exception as e:
        logger.error(f"Ошибка сохранения заказа: {e}")
        return None

def update_order_status(order_id: int, status: str):
    """Обновление статуса заказа"""
    try:
        with open(ORDERS_FILE, "r", encoding="utf-8") as f:
            orders = json.load(f)
        
        for order in orders:
            if order.get("order_id") == order_id:
                order["status"] = status
                order["updated_at"] = datetime.now().isoformat()
                break
        
        with open(ORDERS_FILE, "w", encoding="utf-8") as f:
            json.dump(orders, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Статус заказа #{order_id} изменен на: {status}")
        return True
    except Exception as e:
        logger.error(f"Ошибка обновления статуса заказа: {e}")
        return False

def get_order(order_id: int):
    """Получение заказа по ID"""
    try:
        with open(ORDERS_FILE, "r", encoding="utf-8") as f:
            orders = json.load(f)
        
        for order in orders:
            if order.get("order_id") == order_id:
                return order
        return None
    except Exception as e:
        logger.error(f"Ошибка получения заказа: {e}")
        return None

# Клавиатуры
def get_main_keyboard() -> ReplyKeyboardMarkup:
    """Главная клавиатура"""
    return ReplyKeyboardMarkup(
        resize_keyboard=True,
        keyboard=[
            [KeyboardButton(text="🛒 Купить премиум")],
            [KeyboardButton(text="ℹ️ Информация о покупке")],
            [KeyboardButton(text="💰 Уведомления о скидках")],
            [KeyboardButton(text="📞 Поддержка")]
        ]
    )

def get_models_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура выбора модели ИИ"""
    buttons = []
    for model_id, model_info in AI_MODELS.items():
        buttons.append([
            InlineKeyboardButton(
                text=f"{model_info['name']} - ${model_info['our_price']}/мес",
                callback_data=f"model_{model_id}"
            )
        ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_periods_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура выбора периода"""
    buttons = []
    row = []
    for period in SUBSCRIPTION_PERIODS:
        row.append(KeyboardButton(text=f"{period} мес"))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    buttons.append([KeyboardButton(text="⬅️ Назад")])
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=buttons)

def get_accounts_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура выбора количества аккаунтов"""
    buttons = []
    row = []
    for count in [1, 2, 3, 5, 10]:
        row.append(KeyboardButton(text=str(count)))
        if len(row) == 3:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    buttons.append([KeyboardButton(text="⬅️ Назад")])
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=buttons)

def get_back_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура с кнопкой Назад"""
    return ReplyKeyboardMarkup(
        resize_keyboard=True,
        keyboard=[[KeyboardButton(text="⬅️ Назад")]]
    )

def get_payment_keyboard(payment_link: str, total_price: float, period: int, model_name: str) -> InlineKeyboardMarkup:
    """Клавиатура для выбора способа оплаты"""
    buttons = [
        [
            InlineKeyboardButton(
                text="💳 Оплатить криптовалютой (Telegram)",
                url=payment_link
            )
        ],
        [
            InlineKeyboardButton(
                text="🏦 Оплатить картой / СБП / Криптой",
                url=DONATION_ALERTS_LINK
            )
        ],
        [
            InlineKeyboardButton(
                text="✅ Я оплатил",
                callback_data="payment_done"
            )
        ],
        [
            InlineKeyboardButton(
                text="❌ Отменить",
                callback_data="payment_cancel"
            )
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_admin_confirm_keyboard(order_id: int) -> InlineKeyboardMarkup:
    """Клавиатура для подтверждения оплаты админом"""
    buttons = [
        [
            InlineKeyboardButton(
                text="✅ Подтвердить оплату",
                callback_data=f"admin_confirm_{order_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="❌ Отклонить (нет оплаты)",
                callback_data=f"admin_reject_{order_id}"
            )
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ========== НОВОЕ: Клавиатура для ответа на сообщение пользователя ==========
def get_reply_keyboard(user_id: int, username: str) -> InlineKeyboardMarkup:
    """Клавиатура с кнопкой ответить пользователю"""
    buttons = [
        [
            InlineKeyboardButton(
                text="✉️ Ответить",
                callback_data=f"reply_to_{user_id}"
            )
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ========== НОВОЕ: Клавиатура отмены ответа для админа ==========
def get_cancel_reply_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура с кнопкой отмены ответа"""
    return ReplyKeyboardMarkup(
        resize_keyboard=True,
        keyboard=[[KeyboardButton(text="❌ Отменить ответ")]]
    )

# Команда /start
@router.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    """Обработчик команды /start"""
    # Очищаем состояние при старте
    await state.clear()
    save_user(message.from_user)
    
    welcome_text = (
        f"👋 Добро пожаловать, {message.from_user.first_name}!\n\n"
        "🤖 Я бот для покупки премиум-подписок на ИИ по выгодным ценам.\n\n"
        "🎯 У нас доступны:\n"
        "• ChatGPT Premium - $13.99 (вместо $22)\n"
        "• Claude Pro - $29 (вместо $100)\n"
        "• Midjourney Premium - $25 (вместо $60)\n"
        "• Copilot Pro - $31 (вместо $60)\n"
        "• Perplexity Pro - $13.99 (вместо $20)\n\n"
        "💡 Выберите действие:"
    )
    
    await message.answer(welcome_text, reply_markup=get_main_keyboard())

# Главное меню
@router.message(F.text == "🛒 Купить премиум")
async def process_buy(message: types.Message, state: FSMContext):
    """Начало процесса покупки"""
    await message.answer(
        "🎯 Выберите модель ИИ для покупки:",
        reply_markup=get_models_keyboard()
    )
    await state.set_state(OrderState.selecting_model)

@router.message(F.text == "ℹ️ Информация о покупке")
async def process_info(message: types.Message):
    """Информация о процессе покупки"""
    info_text = (
        "📋 Как работает покупка:\n\n"
        "1️⃣ Вы выбираете модель ИИ (ChatGPT, Claude и др.)\n"
        "2️⃣ Выбираете срок подписки (1, 3, 6 или 12 месяцев)\n"
        "3️⃣ Указываете количество аккаунтов\n"
        "4️⃣ Оплачиваете заказ\n"
        "5️⃣ Админ проверяет оплату\n"
        "6️⃣ Вы получаете доступ к аккаунту\n\n"
        "💳 Доступные способы оплаты:\n"
        "• Криптовалюта через Telegram\n"
        "• Банковская карта / СБП\n"
        "• Альтернативные крипто-платежи\n\n"
        "🔐 После оплаты вы получаете:\n"
        "• Специальный Google аккаунт\n"
        "• Доступ к премиум функциям\n"
        "• Инструкцию по использованию\n\n"
        "⏳ Когда подписка закончится:\n"
        "• Аккаунт будет автоматически заблокирован\n"
        "• Вы сможете купить новую подписку\n\n"
        "💡 Все аккаунты индивидуальные, безопасные и работают напрямую!"
    )
    
    await message.answer(info_text, reply_markup=get_main_keyboard())

@router.message(F.text == "💰 Уведомления о скидках")
async def process_discounts(message: types.Message):
    """Подписка на уведомления о скидках"""
    await message.answer(
        "🔔 Вы подписались на уведомления о скидках!\n"
        "Мы сообщим вам о специальных предложениях и акциях.",
        reply_markup=get_main_keyboard()
    )

@router.message(F.text == "📞 Поддержка")
async def process_support(message: types.Message, state: FSMContext):
    """Связь с поддержкой"""
    await state.set_state(OrderState.waiting_admin_message)
    await message.answer(
        "💬 Введите ваше сообщение для поддержки:",
        reply_markup=get_back_keyboard()
    )

# ========== ВЫБОР МОДЕЛИ ИИ С ИЗОБРАЖЕНИЕМ ==========
@router.callback_query(F.data.startswith("model_"))
async def select_model(callback: types.CallbackQuery, state: FSMContext):
    """Обработка выбора модели ИИ - ТЕПЕРЬ С ИЗОБРАЖЕНИЕМ"""
    model_id = callback.data.replace("model_", "")
    
    if model_id not in AI_MODELS:
        await callback.answer("Модель не найдена")
        return
    
    model = AI_MODELS[model_id]
    
    # Сохраняем выбор модели
    await state.update_data(selected_model=model_id)
    
    # Формируем текст описания
    details_text = (
        f"{model['name']}\n\n"
        f"{model['description']}\n\n"
        f"💎 Преимущества премиум:\n"
    )
    
    for feature in model["features"]:
        details_text += f"{feature}\n"
    
    details_text += (
        f"\n💰 Цены:\n"
        f"• Оригинал: ${model['original_price']}/месяц\n"
        f"• Наша цена: ${model['our_price']}/месяц\n"
        f"• 🔥 Экономия: {round((model['original_price'] - model['our_price']) / model['original_price'] * 100)}%\n\n"
        f"Выберите действие:"
    )
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Выбрать эту модель", callback_data=f"select_{model_id}")],
        [InlineKeyboardButton(text="⬅️ Назад к выбору", callback_data="back_to_models")]
    ])
    
    # ========== ОТПРАВЛЯЕМ ФОТО С ОПИСАНИЕМ ==========
    try:
        # Удаляем предыдущее сообщение
        await callback.message.delete()
        
        # Отправляем фото с описанием модели
        await callback.message.answer_photo(
            photo=model["image_url"],
            caption=details_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    except Exception as e:
        logger.error(f"Ошибка отправки фото: {e}")
        # Если не удалось отправить фото, отправляем просто текст
        await callback.message.answer(
            details_text,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    
    await callback.answer()

@router.callback_query(F.data == "back_to_models")
async def back_to_models(callback: types.CallbackQuery, state: FSMContext):
    """Возврат к выбору модели"""
    try:
        # Пробуем удалить сообщение с фото
        await callback.message.delete()
    except:
        pass
    
    await callback.message.answer(
        "🎯 Выберите модель ИИ для покупки:",
        reply_markup=get_models_keyboard()
    )
    await state.set_state(OrderState.selecting_model)
    await callback.answer()

@router.callback_query(F.data.startswith("select_"))
async def confirm_model_selection(callback: types.CallbackQuery, state: FSMContext):
    """Подтверждение выбора модели"""
    model_id = callback.data.replace("select_", "")
    
    await state.update_data(selected_model=model_id)
    
    try:
        await callback.message.delete()
    except:
        pass
    
    await callback.message.answer(
        f"✅ Вы выбрали: {AI_MODELS[model_id]['name']}\n\n"
        "📅 Теперь выберите срок подписки:",
        reply_markup=get_periods_keyboard()
    )
    
    await state.set_state(OrderState.selecting_period)
    await callback.answer()

# Выбор периода
@router.message(OrderState.selecting_period, F.text.regexp(r'^\d+ мес$'))
async def select_period(message: types.Message, state: FSMContext):
    """Обработка выбора периода"""
    period = int(message.text.split()[0])
    
    if period not in SUBSCRIPTION_PERIODS:
        await message.answer("Пожалуйста, выберите период из предложенных:")
        return
    
    await state.update_data(period=period)
    
    # Получаем данные о выбранной модели
    data = await state.get_data()
    model_id = data.get("selected_model")
    model = AI_MODELS[model_id]
    
    # Расчет стоимости
    monthly_price = model["our_price"]
    total_price = monthly_price * period
    
    await message.answer(
        f"📅 Срок: {period} месяцев\n"
        f"💳 Стоимость за 1 аккаунт: ${total_price:.2f}\n"
        f"(${monthly_price}/мес × {period} мес)\n\n"
        "👥 Сколько аккаунтов вам нужно?",
        reply_markup=get_accounts_keyboard()
    )
    
    await state.set_state(OrderState.selecting_accounts)

# Выбор количества аккаунтов
@router.message(OrderState.selecting_accounts, F.text.regexp(r'^\d+$'))
async def select_accounts(message: types.Message, state: FSMContext):
    """Обработка выбора количества аккаунтов"""
    try:
        accounts_count = int(message.text)
        
        if accounts_count <= 0 or accounts_count > 10:
            await message.answer("Пожалуйста, выберите количество от 1 до 10:")
            return
        
        await state.update_data(accounts_count=accounts_count)
        
        # Расчет итоговой стоимости
        data = await state.get_data()
        model_id = data.get("selected_model")
        period = data.get("period")
        
        model = AI_MODELS[model_id]
        monthly_price = model["our_price"]
        total_price = monthly_price * period * accounts_count
        
        # Получаем payment link для данного периода
        payment_link = model["payment_links"].get(period, model["payment_links"][1])
        
        # Формирование деталей заказа
        order_text = (
            f"📋 Детали вашего заказа:\n\n"
            f"• Модель: {model['name']}\n"
            f"• Срок: {period} месяцев\n"
            f"• Аккаунтов: {accounts_count}\n"
            f"• Цена за аккаунт: ${monthly_price * period:.2f}\n"
            f"• Итого: ${total_price:.2f}\n\n"
            f"💡 Вы экономите: ${(model['original_price'] - model['our_price']) * period * accounts_count:.2f}\n\n"
            "💳 Выберите способ оплаты:"
        )
        
        # ========== ОТПРАВЛЯЕМ ФОТО С ДЕТАЛЯМИ ЗАКАЗА ==========
        try:
            await message.answer_photo(
                photo=model["image_url"],
                caption=order_text,
                reply_markup=get_payment_keyboard(payment_link, total_price, period, model['name']),
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Ошибка отправки фото заказа: {e}")
            # Если не удалось отправить фото, отправляем просто текст
            await message.answer(
                order_text,
                reply_markup=get_payment_keyboard(payment_link, total_price, period, model['name']),
                parse_mode="HTML"
            )
        
        # Сохраняем данные заказа для подтверждения
        await state.update_data(
            total_price=total_price,
            payment_link=payment_link,
            model_name=model['name'],
            image_url=model['image_url']
        )
        
        await state.set_state(OrderState.confirming_order)
        
    except ValueError:
        await message.answer("Пожалуйста, введите число:")

# Обработка оплаты пользователем
@router.callback_query(OrderState.confirming_order, F.data == "payment_done")
async def payment_done(callback: types.CallbackQuery, state: FSMContext):
    """Пользователь подтвердил оплату"""
    data = await state.get_data()
    model_id = data.get("selected_model")
    period = data.get("period")
    accounts_count = data.get("accounts_count")
    total_price = data.get("total_price")
    model_name = data.get("model_name")
    image_url = data.get("image_url", "")
    
    # Создание заказа
    order_data = {
        "user_id": callback.from_user.id,
        "username": callback.from_user.username,
        "model": model_id,
        "period": period,
        "accounts_count": accounts_count,
        "total_price": total_price,
        "payment_method": "telegram_crypto" if "t.me" in data.get("payment_link", "") else "donation_alerts",
        "payment_link": data.get("payment_link", ""),
        "image_url": image_url
    }
    
    order_id = save_order(order_data)
    
    if order_id:
        # Отправка подтверждения пользователю
        success_text = (
            f"✅ Заказ #{order_id} принят в обработку!\n\n"
            f"📋 Детали заказа:\n"
            f"• Модель: {model_name}\n"
            f"• Срок: {period} месяцев\n"
            f"• Аккаунтов: {accounts_count}\n"
            f"• Сумма: ${total_price:.2f}\n\n"
            "⏳ Ожидайте проверки оплаты...\n"
            "Мы проверим оплату в течение 5-15 минут.\n\n"
            "📩 Вы получите уведомление, как только администратор подтвердит оплату."
        )
        
        try:
            await callback.message.delete()
        except:
            pass
        
        # Отправляем подтверждение с фото
        try:
            await callback.message.answer_photo(
                photo=image_url,
                caption=success_text,
                parse_mode="HTML"
            )
        except:
            await callback.message.answer(success_text, parse_mode="HTML")
        
        # ========== УВЕДОМЛЕНИЕ АДМИНУ С ФОТО ==========
        admin_text = (
            f"🛒 НОВЫЙ ЗАКАЗ #{order_id} ОЖИДАЕТ ПРОВЕРКИ\n\n"
            f"👤 Пользователь: @{callback.from_user.username} ({callback.from_user.id})\n"
            f"🤖 Модель: {model_name}\n"
            f"📅 Срок: {period} месяцев\n"
            f"👥 Аккаунтов: {accounts_count}\n"
            f"💰 Сумма: ${total_price:.2f}\n"
            f"💳 Способ оплаты: {'Telegram Crypto' if 't.me' in data.get('payment_link', '') else 'DonationAlerts'}\n"
            f"🔗 Ссылка на оплату: {data.get('payment_link', 'N/A')}\n\n"
            f"⚠️ Проверьте получение средств и нажмите соответствующую кнопку:"
        )
        
        try:
            # Отправляем админу уведомление с фото модели
            await callback.message.bot.send_photo(
                ADMIN_ID,
                photo=image_url,
                caption=admin_text,
                reply_markup=get_admin_confirm_keyboard(order_id),
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Не удалось отправить фото админу: {e}")
            # Пробуем отправить без фото
            try:
                await callback.message.bot.send_message(
                    ADMIN_ID, 
                    admin_text,
                    reply_markup=get_admin_confirm_keyboard(order_id),
                    parse_mode="HTML"
                )
            except Exception as e2:
                logger.error(f"Не удалось уведомить админа: {e2}")
    
    else:
        try:
            await callback.message.delete()
        except:
            pass
        await callback.message.answer(
            "❌ Произошла ошибка при создании заказа. Пожалуйста, свяжитесь с поддержкой.",
            reply_markup=get_main_keyboard()
        )
    
    await callback.answer()
    await state.clear()

@router.callback_query(OrderState.confirming_order, F.data == "payment_cancel")
async def payment_cancel(callback: types.CallbackQuery, state: FSMContext):
    """Отмена оплаты пользователем"""
    try:
        await callback.message.delete()
    except:
        pass
    
    await callback.message.answer(
        "❌ Оплата отменена.\n"
        "Если передумаете, всегда можно создать новый заказ.",
        reply_markup=get_main_keyboard()
    )
    await callback.answer()
    await state.clear()

# Подтверждение/отклонение оплаты админом
@router.callback_query(F.data.startswith("admin_confirm_"))
async def admin_confirm_payment(callback: types.CallbackQuery):
    """Админ подтвердил оплату"""
    order_id = int(callback.data.replace("admin_confirm_", ""))
    
    # Обновляем статус заказа
    if update_order_status(order_id, "confirmed"):
        # Получаем данные заказа
        order = get_order(order_id)
        if order:
            model = AI_MODELS.get(order['model'], {})
            model_name = model.get('name', 'N/A')
            image_url = model.get('image_url', '')
            
            # Отправляем уведомление пользователю
            success_text = (
                f"🎉 Оплата подтверждена!\n\n"
                f"✅ Ваш заказ #{order_id} успешно оплачен!\n\n"
                f"📋 Детали заказа:\n"
                f"• Модель: {model_name}\n"
                f"• Срок: {order['period']} месяцев\n"
                f"• Аккаунтов: {order['accounts_count']}\n"
                f"• Сумма: ${order['total_price']:.2f}\n\n"
                f"📩 Отправляем специальный аккаунт лично для вас с универсальным паролем. Ожидайте через пару секунд.\n"
                f"Если возникнут вопросы, обращайтесь в поддержку."
            )
            
            try:
                # Отправляем пользователю уведомление с фото
                await callback.message.bot.send_photo(
                    order["user_id"],
                    photo=image_url,
                    caption=success_text,
                    parse_mode="HTML"
                )
            except Exception as e:
                logger.error(f"Не удалось отправить фото пользователю: {e}")
                try:
                    await callback.message.bot.send_message(
                        order["user_id"],
                        success_text,
                        parse_mode="HTML"
                    )
                except Exception as e2:
                    logger.error(f"Не удалось уведомить пользователя: {e2}")
            
            # Обновляем сообщение админу
            try:
                await callback.message.edit_caption(
                    caption=f"✅ Заказ #{order_id} подтвержден!\n"
                    f"Пользователь @{order['username']} уведомлен."
                )
            except:
                try:
                    await callback.message.edit_text(
                        f"✅ Заказ #{order_id} подтвержден!\n"
                        f"Пользователь @{order['username']} уведомлен."
                    )
                except:
                    pass
            
            await callback.answer("Оплата подтверждена!")
        else:
            await callback.answer("Ошибка: заказ не найден")
    else:
        await callback.answer("Ошибка обновления статуса")

@router.callback_query(F.data.startswith("admin_reject_"))
async def admin_reject_payment(callback: types.CallbackQuery):
    """Админ отклонил оплату (денег нет)"""
    order_id = int(callback.data.replace("admin_reject_", ""))
    
    # Обновляем статус заказа
    if update_order_status(order_id, "rejected"):
        # Получаем данные заказа
        order = get_order(order_id)
        if order:
            # Отправляем уведомление пользователю
            reject_text = (
                f"❌ Оплата не подтверждена\n\n"
                f"Заказ #{order_id} отклонен.\n\n"
                f"💡 Возможные причины:\n"
                f"• Средства не поступили\n"
                f"• Неверная сумма\n"
                f"• Техническая ошибка\n\n"
                f"📞 Свяжитесь с поддержкой для уточнения деталей:\n"
                f"/start → 📞 Поддержка"
            )
            
            try:
                await callback.message.bot.send_message(
                    order["user_id"],
                    reject_text,
                    parse_mode="HTML"
                )
            except Exception as e:
                logger.error(f"Не удалось уведомить пользователя: {e}")
            
            # Обновляем сообщение админу
            try:
                await callback.message.edit_caption(
                    caption=f"❌ Заказ #{order_id} отклонен!\n"
                    f"Пользователь @{order['username']} уведомлен."
                )
            except:
                try:
                    await callback.message.edit_text(
                        f"❌ Заказ #{order_id} отклонен!\n"
                        f"Пользователь @{order['username']} уведомлен."
                    )
                except:
                    pass
            
            await callback.answer("Оплата отклонена!")
        else:
            await callback.answer("Ошибка: заказ не найден")
    else:
        await callback.answer("Ошибка обновления статуса")

# ========== ИСПРАВЛЕННЫЕ СООБЩЕНИЯ АДМИНУ С КНОПКОЙ ОТВЕТИТЬ ==========
@router.message(OrderState.waiting_admin_message)
async def send_to_admin(message: types.Message, state: FSMContext):
    """Отправка сообщения админу"""
    if message.text == "⬅️ Назад":
        await state.clear()
        await message.answer(
            "Вы вернулись в главное меню:",
            reply_markup=get_main_keyboard()
        )
        return
    
    # ========== ДОБАВЛЕНА КНОПКА ОТВЕТИТЬ ==========
    reply_keyboard = get_reply_keyboard(message.from_user.id, message.from_user.username)
    
    admin_text = (
        f"📩 Сообщение от пользователя\n\n"
        f"👤 @{message.from_user.username} (ID: {message.from_user.id})\n"
        f"📝 {message.text}"
    )
    
    try:
        await message.bot.send_message(
            ADMIN_ID, 
            admin_text, 
            reply_markup=reply_keyboard,  # ← ДОБАВЛЕНА КЛАВИАТУРА С КНОПКОЙ
            parse_mode="HTML"
        )
        await message.answer(
            "✅ Ваше сообщение отправлено! Мы ответим вам в ближайшее время.",
            reply_markup=get_main_keyboard()
        )
    except Exception as e:
        logger.error(f"Ошибка отправки сообщения админу: {e}")
        await message.answer(
            "❌ Не удалось отправить сообщение. Попробуйте позже.",
            reply_markup=get_main_keyboard()
        )
    
    await state.clear()

# ========== НОВОЕ: Обработка кнопки "Ответить" для админа ==========
@router.callback_query(F.data.startswith("reply_to_"))
async def start_reply_to_user(callback: types.CallbackQuery, state: FSMContext):
    """Админ нажал кнопку Ответить"""
    # Проверяем что это админ
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("⛔ Только для администратора!", show_alert=True)
        return
    
    # Извлекаем ID пользователя из callback_data
    user_id = int(callback.data.replace("reply_to_", ""))
    
    # Сохраняем ID пользователя для ответа
    await state.update_data(reply_to_user_id=user_id)
    await state.set_state(AdminState.waiting_reply)
    
    await callback.message.answer(
        f"✏️ Введите ответ для пользователя (ID: {user_id}):\n\n"
        f"💡 Или нажмите кнопку ниже для отмены.",
        reply_markup=get_cancel_reply_keyboard()
    )
    await callback.answer()

# ========== НОВОЕ: Обработка ответа админа ==========
@router.message(AdminState.waiting_reply)
async def send_reply_to_user(message: types.Message, state: FSMContext):
    """Отправка ответа админа пользователю"""
    # Проверяем отмену
    if message.text == "❌ Отменить ответ":
        await state.clear()
        await message.answer(
            "❌ Ответ отменен.",
            reply_markup=ReplyKeyboardRemove()
        )
        return
    
    # Получаем ID пользователя из состояния
    data = await state.get_data()
    user_id = data.get("reply_to_user_id")
    
    if not user_id:
        await state.clear()
        await message.answer(
            "❌ Ошибка: ID пользователя не найден. Попробуйте снова.",
            reply_markup=ReplyKeyboardRemove()
        )
        return
    
    # Формируем сообщение для пользователя
    reply_text = (
        f"📩 Ответ от поддержки:\n\n"
        f"{message.text}"
    )
    
    try:
        # Отправляем ответ пользователю
        await message.bot.send_message(
            user_id,
            reply_text,
            reply_markup=get_main_keyboard(),
            parse_mode="HTML"
        )
        
        await message.answer(
            f"✅ Ответ успешно отправлен пользователю (ID: {user_id})!",
            reply_markup=ReplyKeyboardRemove()
        )
        logger.info(f"Админ отправил ответ пользователю {user_id}")
        
    except Exception as e:
        logger.error(f"Ошибка отправки ответа пользователю {user_id}: {e}")
        await message.answer(
            f"❌ Не удалось отправить ответ пользователю.\n"
            f"Ошибка: {e}",
            reply_markup=ReplyKeyboardRemove()
        )
    
    await state.clear()

# Назад в меню
@router.message(F.text == "⬅️ Назад")
async def back_to_menu(message: types.Message, state: FSMContext):
    """Возврат в главное меню"""
    await state.clear()
    await message.answer(
        "Вы вернулись в главное меню:",
        reply_markup=get_main_keyboard()
    )

# ========== НОВОЕ: Отмена ответа для админа ==========
@router.message(F.text == "❌ Отменить ответ")
async def cancel_admin_reply(message: types.Message, state: FSMContext):
    """Отмена ответа админом"""
    await state.clear()
    await message.answer(
        "❌ Ответ отменен.",
        reply_markup=ReplyKeyboardRemove()
    )

# Запуск бота
async def main():
    """Основная функция запуска бота"""
    bot = Bot(token=TOKEN)
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)
    
    logger.info("Бот запущен")
    
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
