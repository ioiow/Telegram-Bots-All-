import requests
import re
import instaloader
import sqlite3
import json
import threading
from datetime import datetime
import os

# Настройки
BOT_TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"
INSTAGRAM_USERNAME = "ai.telegrambot.io"  # ТВОЙ логин
INSTAGRAM_PASSWORD = "Seitnebi2008"  # ТВОЙ пароль

# Глобальный объект для Instagram
instagram_loader = None
loader_lock = threading.Lock()

def init_instagram():
    """Инициализация Instagram с авторизацией"""
    global instagram_loader
    try:
        with loader_lock:
            if instagram_loader is None:
                instagram_loader = instaloader.Instaloader()
                instagram_loader.login(INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD)
                print("✅ Авторизация в Instagram успешна!")
        return True
    except Exception as e:
        print(f"❌ Ошибка авторизации Instagram: {e}")
        return False

def download_instagram_video(instagram_url, chat_id):
    """Скачивание видео через авторизованный аккаунт"""
    try:
        # Извлекаем shortcode из ссылки
        if "/reel/" in instagram_url:
            shortcode = instagram_url.split("/reel/")[1].split("/")[0]
        elif "/p/" in instagram_url:
            shortcode = instagram_url.split("/p/")[1].split("/")[0]
        else:
            return False, "❌ Неверная ссылка Instagram"
        
        with loader_lock:
            # Получаем пост
            post = instaloader.Post.from_shortcode(instagram_loader.context, shortcode)
            
            if not post.is_video:
                return False, "❌ В этом посте нет видео"
            
            # Создаем временную папку для загрузки
            temp_dir = f"temp_{chat_id}"
            os.makedirs(temp_dir, exist_ok=True)
            
            # Скачиваем видео
            instagram_loader.download_post(post, target=temp_dir)
            
            # Ищем скачанный файл
            for file in os.listdir(temp_dir):
                if file.endswith('.mp4'):
                    video_path = os.path.join(temp_dir, file)
                    return True, video_path
            
            return False, "❌ Не удалось найти скачанный файл"
            
    except Exception as e:
        return False, f"❌ Ошибка загрузки: {str(e)}"

def send_video_to_telegram(chat_id, video_path, caption="🎥 Ваше видео готово!"):
    """Отправка видео в телеграм"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendVideo"
        
        with open(video_path, 'rb') as video_file:
            files = {'video': video_file}
            data = {'chat_id': chat_id, 'caption': caption}
            
            response = requests.post(url, files=files, data=data, timeout=30)
            
        # Удаляем временный файл
        try:
            os.remove(video_path)
            os.rmdir(os.path.dirname(video_path))
        except:
            pass
            
        return response.status_code == 200
    except Exception as e:
        print(f"❌ Ошибка отправки видео: {e}")
        return False

def send_message(chat_id, text):
    """Отправка сообщения"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": chat_id, "text": text}
    try:
        requests.post(url, data=data, timeout=5)
    except:
        pass

def process_message(message):
    """Обработка сообщений"""
    chat_id = message["chat"]["id"]
    text = message.get("text", "").strip()
    
    if text == "/start":
        send_message(chat_id, "👋 Привет! Отправь мне ссылку на видео из Instagram и я скачаю его через свой аккаунт!")
        return
    
    # Проверяем Instagram ссылку
    if re.match(r'https?://(www\.)?instagram\.com/(p|reel)/', text):
        send_message(chat_id, "⏳ Скачиваю видео через мой аккаунт Instagram...")
        
        # Скачиваем видео
        success, result = download_instagram_video(text, chat_id)
        
        if success:
            # Отправляем видео
            video_sent = send_video_to_telegram(chat_id, result)
            if not video_sent:
                send_message(chat_id, "❌ Не удалось отправить видео. Попробуйте другую ссылку.")
        else:
            send_message(chat_id, result)
    
    elif re.match(r'https?://', text):
        send_message(chat_id, "❌ Поддерживаются только ссылки Instagram (посты и рилы)")
    else:
        send_message(chat_id, "📨 Отправь мне ссылку на Instagram пост или рил")

def main():
    """Основная функция"""
    print("🤖 Запускаю бота...")
    
    # Инициализируем Instagram
    if not init_instagram():
        print("❌ Не удалось авторизоваться в Instagram. Проверь логин/пароль.")
        return
    
    print("✅ Бот готов к работе!")
    
    offset = 0
    while True:
        try:
            url = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"
            params = {"offset": offset, "timeout": 10}
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data["ok"] and data["result"]:
                    for update in data["result"]:
                        if "message" in update:
                            process_message(update["message"])
                        offset = update["update_id"] + 1
                
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            continue

if __name__ == "__main__":
    # Установи: pip install instaloader requests
    main()