import requests
import re
import instaloader
import sqlite3
import json
import threading
from datetime import datetime
import os
import yt_dlp
from TikTokApi import TikTokApi
import pickle

# Настройки
BOT_TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"

# Аккаунты для всех соцсетей
ACCOUNTS = {
    "instagram": {
        "username": "ai.telegrambot.io",
        "password": "Seitnebi2008"
    },
    "tiktok": {
        "username": "твой_логин_tiktok",  # замени
        "password": "твой_пароль_tiktok"  # замени
    },
    "youtube": {
        "username": "твой_email_youtube@gmail.com",  # замени
        "password": "твой_пароль_youtube"  # замени
    },
    "pinterest": {
        "username": "твой_логин_pinterest",  # замени
        "password": "твой_пароль_pinterest"  # замени
    }
}

# Глобальные объекты
instagram_loader = None
tiktok_api = None
youtube_dlp = None
loader_lock = threading.Lock()

def init_instagram():
    """Инициализация Instagram с авторизацией"""
    global instagram_loader
    try:
        with loader_lock:
            if instagram_loader is None:
                instagram_loader = instaloader.Instaloader()
                instagram_loader.login(
                    ACCOUNTS["instagram"]["username"], 
                    ACCOUNTS["instagram"]["password"]
                )
                print("✅ Авторизация в Instagram успешна!")
        return True
    except Exception as e:
        print(f"❌ Ошибка авторизации Instagram: {e}")
        return False

def init_tiktok():
    """Инициализация TikTok с авторизацией"""
    global tiktok_api
    try:
        with loader_lock:
            if tiktok_api is None:
                # TikTokApi требует сложную авторизацию
                # Используем альтернативный способ
                tiktok_api = TikTokApi()
                print("✅ TikTok инициализирован!")
        return True
    except Exception as e:
        print(f"❌ Ошибка инициализации TikTok: {e}")
        return False

def init_youtube():
    """Инициализация YouTube с авторизацией"""
    global youtube_dlp
    try:
        with loader_lock:
            if youtube_dlp is None:
                # yt-dlp поддерживает авторизацию через cookies
                yt_dlp.utils.std_headers['Cookie'] = f'username={ACCOUNTS["youtube"]["username"]}'
                print("✅ YouTube инициализирован!")
        return True
    except Exception as e:
        print(f"❌ Ошибка инициализации YouTube: {e}")
        return False

def download_instagram_video(instagram_url, chat_id):
    """Скачивание видео через авторизованный аккаунт"""
    try:
        # Извлекаем shortcode из ссылки
        if "/reel/" in instagram_url:
            shortcode = instagram_url.split("/reel/")[1].split("/")[0]
        elif "/p/" in instagram_url:
            shortcode = instagram_url.split("/p/")[1].split("/")[0]
        else:
            return False, "❌ Неверная ссылка Instagram"
        
        with loader_lock:
            # Получаем пост
            post = instaloader.Post.from_shortcode(instagram_loader.context, shortcode)
            
            if not post.is_video:
                return False, "❌ В этом посте нет видео"
            
            # Создаем временную папку для загрузки
            temp_dir = f"temp_{chat_id}"
            os.makedirs(temp_dir, exist_ok=True)
            
            # Скачиваем видео
            instagram_loader.download_post(post, target=temp_dir)
            
            # Ищем скачанный файл
            for file in os.listdir(temp_dir):
                if file.endswith('.mp4'):
                    video_path = os.path.join(temp_dir, file)
                    return True, video_path
            
            return False, "❌ Не удалось найти скачанный файл"
            
    except Exception as e:
        return False, f"❌ Ошибка загрузки Instagram: {str(e)}"

def download_youtube_video(youtube_url, chat_id):
    """Скачивание видео с YouTube"""
    try:
        temp_dir = f"temp_{chat_id}"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Настройки для yt-dlp
        ydl_opts = {
            'outtmpl': f'{temp_dir}/%(title)s.%(ext)s',
            'format': 'best[height<=720]',  # Максимум 720p
            'quiet': True,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(youtube_url, download=True)
            video_file = ydl.prepare_filename(info)
            
        return True, video_file
        
    except Exception as e:
        return False, f"❌ Ошибка загрузки YouTube: {str(e)}"

def download_tiktok_video(tiktok_url, chat_id):
    """Скачивание видео с TikTok"""
    try:
        temp_dir = f"temp_{chat_id}"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Используем yt-dlp для TikTok (более надежно)
        ydl_opts = {
            'outtmpl': f'{temp_dir}/%(title)s.%(ext)s',
            'format': 'best',
            'quiet': True,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(tiktok_url, download=True)
            video_file = ydl.prepare_filename(info)
            
        return True, video_file
        
    except Exception as e:
        return False, f"❌ Ошибка загрузки TikTok: {str(e)}"

def download_pinterest_video(pinterest_url, chat_id):
    """Скачивание видео с Pinterest"""
    try:
        temp_dir = f"temp_{chat_id}"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Используем yt-dlp для Pinterest
        ydl_opts = {
            'outtmpl': f'{temp_dir}/%(title)s.%(ext)s',
            'format': 'best',
            'quiet': True,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(pinterest_url, download=True)
            video_file = ydl.prepare_filename(info)
            
        return True, video_file
        
    except Exception as e:
        return False, f"❌ Ошибка загрузки Pinterest: {str(e)}"

def send_video_to_telegram(chat_id, video_path, caption="🎥 Ваше видео готово!"):
    """Отправка видео в телеграм"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendVideo"
        
        with open(video_path, 'rb') as video_file:
            files = {'video': video_file}
            data = {'chat_id': chat_id, 'caption': caption}
            
            response = requests.post(url, files=files, data=data, timeout=30)
            
        # Удаляем временный файл
        try:
            os.remove(video_path)
            os.rmdir(os.path.dirname(video_path))
        except:
            pass
            
        return response.status_code == 200
    except Exception as e:
        print(f"❌ Ошибка отправки видео: {e}")
        return False

def send_message(chat_id, text):
    """Отправка сообщения"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": chat_id, "text": text}
    try:
        requests.post(url, data=data, timeout=5)
    except:
        pass

def process_message(message):
    """Обработка сообщений"""
    chat_id = message["chat"]["id"]
    text = message.get("text", "").strip()
    
    if text == "/start":
        send_message(chat_id, 
            "👋 Привет! Я скачиваю видео из:\n"
            "• Instagram 📷\n" 
            "• YouTube 🎬\n"
            "• TikTok 🎵\n"
            "• Pinterest 📌\n\n"
            "Просто отправь мне ссылку!"
        )
        return
    
    # Определяем тип ссылки и скачиваем
    if re.match(r'https?://(www\.)?instagram\.com/(p|reel)/', text):
        send_message(chat_id, "⏳ Скачиваю видео из Instagram...")
        success, result = download_instagram_video(text, chat_id)
        
    elif re.match(r'https?://(www\.)?(youtube\.com|youtu\.be)/', text):
        send_message(chat_id, "⏳ Скачиваю видео с YouTube...")
        success, result = download_youtube_video(text, chat_id)
        
    elif re.match(r'https?://(www\.)?tiktok\.com/', text):
        send_message(chat_id, "⏳ Скачиваю видео с TikTok...")
        success, result = download_tiktok_video(text, chat_id)
        
    elif re.match(r'https?://(www\.)?pinterest\.com/', text):
        send_message(chat_id, "⏳ Скачиваю видео с Pinterest...")
        success, result = download_pinterest_video(text, chat_id)
        
    elif re.match(r'https?://', text):
        send_message(chat_id, "❌ Неподдерживаемая ссылка. Поддерживаются: Instagram, YouTube, TikTok, Pinterest")
        return
    else:
        send_message(chat_id, "📨 Отправь мне ссылку на видео")
        return
    
    # Отправляем результат
    if success:
        video_sent = send_video_to_telegram(chat_id, result)
        if not video_sent:
            send_message(chat_id, "❌ Не удалось отправить видео. Попробуйте другую ссылку.")
    else:
        send_message(chat_id, result)

def main():
    """Основная функция"""
    print("🤖 Запускаю бота...")
    
    # Инициализируем все соцсети
    print("🔐 Инициализация аккаунтов...")
    init_instagram()
    init_youtube()
    init_tiktok()
    
    print("✅ Бот готов к работе!")
    
    offset = 0
    while True:
        try:
            url = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"
            params = {"offset": offset, "timeout": 10}
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data["ok"] and data["result"]:
                    for update in data["result"]:
                        if "message" in update:
                            process_message(update["message"])
                        offset = update["update_id"] + 1
                
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            continue

if __name__ == "__main__":
    # Установи зависимости:
    # pip install instaloader yt-dlp TikTokApi requests
    main()