import logging
import sqlite3
import os
import json
import requests
from telebot import TeleBot, types
from datetime import datetime

# Настройки
BOT_TOKEN = "8075393657:AAGMw6jnuMbjmQiNgPt0Z3iFN1y2JvgTgWs"
ADMIN_ID = 8550701850
CHANNELS = [
    "@searchPersonIP",
    "@Freelancestar_bot", 
    "@IT_Programmer_io",
    "@Iruma_Standoff2"
]
ADMIN_USERNAME = "@Goooolllp"

# Папка для данных
DATA_DIR = "/storage/emulated/0/Download/pyComad/Telegram-ChityBot/user_data"

# Удаляем вебхук перед запуском
try:
    response = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/deleteWebhook")
    print(f"Вебхук удален: {response.json()}")
except Exception as e:
    print(f"Ошибка при удалении вебхука: {e}")

# Инициализация бота
bot = TeleBot(BOT_TOKEN)
logging.basicConfig(level=logging.INFO)

# Функции для работы с файлами данных
def get_user_file_path(user_id):
    """Получает путь к файлу пользователя"""
    return os.path.join(DATA_DIR, f"{user_id}.json")

def load_user_data(user_id):
    """Загружает данные пользователя из файла"""
    file_path = get_user_file_path(user_id)
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Ошибка загрузки данных пользователя {user_id}: {e}")
    
    # Возвращаем данные по умолчанию
    return {
        "user_id": user_id,
        "username": "",
        "phone_number": None,
        "phone_history": [],
        "referrer_id": None,
        "balance": 0.0,
        "total_earned": 0.0,
        "referrals_count": 0,
        "referrals": [],
        "is_subscribed": 0,
        "registered_at": datetime.now().isoformat(),
        "transactions": [],
        "pending_withdraw": None
    }

def save_user_data(user_data):
    """Сохраняет данные пользователя в файл"""
    try:
        # Создаем папку только если она не существует
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR, exist_ok=True)
        
        file_path = get_user_file_path(user_data["user_id"])
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(user_data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"Ошибка сохранения данных пользователя {user_data['user_id']}: {e}")
        return False

def update_user_balance(user_id, amount):
    """Обновляет баланс пользователя"""
    user_data = load_user_data(user_id)
    user_data["balance"] = round(user_data["balance"] + amount, 2)
    user_data["total_earned"] = round(user_data["total_earned"] + amount, 2)
    save_user_data(user_data)
    return user_data

def add_referral(user_id, referral_id):
    """Добавляет реферала пользователю"""
    user_data = load_user_data(user_id)
    if referral_id not in user_data["referrals"]:
        user_data["referrals"].append(referral_id)
        user_data["referrals_count"] = len(user_data["referrals"])
        save_user_data(user_data)
    return user_data

def get_all_users():
    """Получает список всех пользователей"""
    users = []
    if not os.path.exists(DATA_DIR):
        return users
        
    for filename in os.listdir(DATA_DIR):
        if filename.endswith('.json'):
            user_id = filename.replace('.json', '')
            try:
                user_data = load_user_data(user_id)
                users.append(user_data)
            except:
                continue
    return users

# Функции для работы с подписками
def check_subscription(user_id):
    """Проверяет подписку на все каналы"""
    not_subscribed = []
    for channel in CHANNELS:
        try:
            chat_member = bot.get_chat_member(channel, user_id)
            if chat_member.status not in ['member', 'administrator', 'creator']:
                not_subscribed.append(channel)
        except Exception as e:
            print(f"Ошибка проверки канала {channel}: {e}")
            not_subscribed.append(channel)
    
    return not_subscribed

# Главное меню
def main_menu():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.add("👥 Мои рефералы", "💰 Баланс")
    markup.add("📤 Вывод средств", "ℹ️ Инструкция")
    markup.add("🎯 Увеличить доход")
    return markup

def get_user_stats(user_id):
    user_data = load_user_data(user_id)
    
    balance_text = f"{user_data['balance']:.2f}€"
    total_earned_text = f"{user_data['total_earned']:.2f}€"
    referrals_count = user_data["referrals_count"]
    
    welcome_text = f"""🎉 Добро пожаловать в реферальную систему!

📊 Ваша статистика:
├ Рефералы: {referrals_count} чел.
├ Баланс: {balance_text}
└ Всего заработано: {total_earned_text}

💡 Зарабатывайте 0.25€ за каждого приглашенного друга + 10% от его покупок!"""

    return welcome_text

# АДМИН КОМАНДЫ - ПЕРВЫМИ
@bot.message_handler(commands=['admin'])
def admin_panel(message):
    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        bot.send_message(user_id, "❌ У вас нет доступа к админ панели")
        return
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("📊 Статистика", callback_data="admin_stats"))
    markup.add(types.InlineKeyboardButton("👥 Все пользователи", callback_data="admin_users"))
    
    bot.send_message(user_id, "👨‍💻 Панель администратора", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith('admin_'))
def admin_callbacks(call):
    user_id = call.from_user.id
    if user_id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Нет доступа")
        return
    
    if call.data == "admin_stats":
        all_users = get_all_users()
        total_users = len(all_users)
        active_users = len([u for u in all_users if u.get('is_subscribed', 0) == 1])
        total_balance = sum(user.get('balance', 0) for user in all_users)
        total_earned = sum(user.get('total_earned', 0) for user in all_users)
        total_referrals = sum(user.get('referrals_count', 0) for user in all_users)
        
        channels_compact = " • ".join([channel.replace('@', '') for channel in CHANNELS])
        
        stats_text = f"""📊 **СТАТИСТИКА БОТА**

👥 **Пользователи:**
├ Всего: {total_users}
├ Активных: {active_users}
└ Всего рефералов: {total_referrals}

💰 **Финансы:**
├ Общий баланс: {total_balance:.2f}€
├ Всего выплачено: {total_earned:.2f}€
└ Оборот: {total_balance + total_earned:.2f}€

📢 **Каналы:** {len(CHANNELS)}
`{channels_compact}`"""
        
        bot.edit_message_text(stats_text, call.message.chat.id, call.message.message_id, parse_mode='Markdown')
    
    elif call.data == "admin_users":
        all_users = get_all_users()
        if not all_users:
            bot.edit_message_text("👥 Пользователей пока нет", call.message.chat.id, call.message.message_id)
            return
        
        users_text = "👥 **Все пользователи:**\n\n"
        for i, user in enumerate(all_users[:50], 1):  # Ограничиваем 50 пользователями
            username = user.get('username', 'нет username')
            balance = user.get('balance', 0)
            referrals = user.get('referrals_count', 0)
            users_text += f"{i}. @{username} | {balance}€ | {referrals} реф.\n"
        
        if len(all_users) > 50:
            users_text += f"\n... и ещё {len(all_users) - 50} пользователей"
        
        bot.edit_message_text(users_text, call.message.chat.id, call.message.message_id, parse_mode='Markdown')

# ОБРАБОТЧИКИ ДЛЯ ПОЛЬЗОВАТЕЛЕЙ (кроме админа)
@bot.message_handler(commands=['start'])
def start_command(message):
    user_id = message.from_user.id
    
    # Если это админ - показываем админ панель
    if user_id == ADMIN_ID:
        admin_panel(message)
        return
    
    username = message.from_user.username or f"user_{user_id}"
    args = message.text.split()
    
    referrer_id = int(args[1]) if len(args) > 1 and args[1].isdigit() else None
    
    # Загружаем или создаем данные пользователя
    user_data = load_user_data(user_id)
    user_data["username"] = username
    
    # Если есть реферер, добавляем его
    if referrer_id and str(referrer_id) != str(user_id):
        user_data["referrer_id"] = referrer_id
        # Добавляем реферала рефереру
        add_referral(referrer_id, user_id)
    
    save_user_data(user_data)
    
    # Проверка подписки на все каналы
    not_subscribed = check_subscription(user_id)
    if not_subscribed:
        show_subscription_request(user_id, not_subscribed)
        return
    
    # Обновление статуса подписки
    user_data["is_subscribed"] = 1
    save_user_data(user_data)
    
    # Начисление бонуса рефереру
    if referrer_id:
        update_user_balance(referrer_id, 0.25)
        try:
            bot.send_message(referrer_id, f"🎉 Ваш друг подписался! +0.25€ на ваш баланс!")
        except Exception as e:
            print(f"Ошибка отправки рефереру: {e}")
    
    welcome_text = get_user_stats(user_id)
    markup = main_menu()
    bot.send_message(user_id, welcome_text, reply_markup=markup)

def show_subscription_request(user_id, not_subscribed_channels):
    """Показывает компактные кнопки для подписки на каналы"""
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Создаем компактные кнопки для каналов
    channel_buttons = []
    for channel in not_subscribed_channels:
        channel_name = channel.replace('@', '')
        if len(channel_name) > 15:
            channel_name = channel_name[:12] + "..."
        
        subscribe_btn = types.InlineKeyboardButton(
            f"📢 {channel_name}", 
            url=f"https://t.me/{channel[1:]}"
        )
        channel_buttons.append(subscribe_btn)
    
    # Добавляем кнопки каналов компактно (по 2 в ряду)
    for i in range(0, len(channel_buttons), 2):
        if i + 1 < len(channel_buttons):
            markup.add(channel_buttons[i], channel_buttons[i + 1])
        else:
            markup.add(channel_buttons[i])
    
    # Кнопка проверки подписки
    check_btn = types.InlineKeyboardButton("✅ Я подписался на все", callback_data="check_subscription")
    markup.add(check_btn)
    
    # Компактный список каналов
    channels_compact = " • ".join([channel.replace('@', '') for channel in not_subscribed_channels])
    
    bot.send_message(user_id, 
                    f"📢 **Необходимо подписаться на каналы:**\n"
                    f"`{channels_compact}`\n\n"
                    f"⬇️ **Нажмите на кнопки ниже:**",
                    reply_markup=markup,
                    parse_mode='Markdown')

@bot.callback_query_handler(func=lambda call: call.data == "check_subscription")
def check_subscription_callback(call):
    user_id = call.from_user.id
    
    # Если это админ - не обрабатываем
    if user_id == ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Админ не может использовать эту функцию")
        return
    
    not_subscribed = check_subscription(user_id)
    if not not_subscribed:
        # Пользователь подписан на все каналы
        user_data = load_user_data(user_id)
        user_data["is_subscribed"] = 1
        save_user_data(user_data)
        
        # Начисляем бонус рефереру
        referrer_id = user_data.get("referrer_id")
        if referrer_id:
            update_user_balance(referrer_id, 0.25)
            try:
                bot.send_message(referrer_id, f"🎉 Ваш друг подписался! +0.25€ на ваш баланс!")
            except Exception as e:
                print(f"Ошибка отправки рефереру: {e}")
        
        welcome_text = get_user_stats(user_id)
        markup = main_menu()
        bot.edit_message_text(chat_id=user_id, 
                            message_id=call.message.message_id,
                            text="✅ **Отлично! Вы подписаны на все каналы!**\n\nТеперь вы можете пользоваться ботом!",
                            reply_markup=None,
                            parse_mode='Markdown')
        bot.send_message(user_id, welcome_text, reply_markup=markup)
    else:
        # Показываем компактный список оставшихся каналов
        channels_compact = " • ".join([channel.replace('@', '') for channel in not_subscribed])
        bot.answer_callback_query(call.id, f"❌ Не подписан на: {channels_compact}", show_alert=True)
        
        # Обновляем сообщение с компактными кнопками
        markup = types.InlineKeyboardMarkup(row_width=2)
        
        channel_buttons = []
        for channel in not_subscribed:
            channel_name = channel.replace('@', '')
            if len(channel_name) > 15:
                channel_name = channel_name[:12] + "..."
            
            subscribe_btn = types.InlineKeyboardButton(
                f"📢 {channel_name}", 
                url=f"https://t.me/{channel[1:]}"
            )
            channel_buttons.append(subscribe_btn)
        
        for i in range(0, len(channel_buttons), 2):
            if i + 1 < len(channel_buttons):
                markup.add(channel_buttons[i], channel_buttons[i + 1])
            else:
                markup.add(channel_buttons[i])
        
        markup.add(types.InlineKeyboardButton("✅ Я подписался на все", callback_data="check_subscription"))
        
        bot.edit_message_text(
            chat_id=user_id,
            message_id=call.message.message_id,
            text=f"📢 **Остались неподписанные каналы:**\n"
                 f"`{channels_compact}`\n\n"
                 f"⬇️ **Нажмите на кнопки ниже:**",
            reply_markup=markup,
            parse_mode='Markdown'
        )

# ОБРАБОТЧИКИ КНОПОК МЕНЮ (только для пользователей)
@bot.message_handler(func=lambda message: message.text == "👥 Мои рефералы")
def show_referrals(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    referral_link = f"https://t.me/{bot.get_me().username}?start={user_id}"
    
    text = f"""👥 Ваши рефералы:

📊 Статистика:
├ Приглашено: {user_data['referrals_count']} чел.
├ Заработано с рефералов: {user_data['total_earned']:.2f}€
└ Ваша ссылка для приглашений:

`{referral_link}`

💌 Отправляйте эту ссылку друзьям и зарабатывайте!"""

    bot.send_message(user_id, text, parse_mode='Markdown')

@bot.message_handler(func=lambda message: message.text == "💰 Баланс")
def show_balance(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    text = f"""💰 Ваш баланс:

💳 Доступно: {user_data['balance']:.2f}€
🏆 Всего заработано: {user_data['total_earned']:.2f}€
👥 Активных рефералов: {user_data['referrals_count']}

💸 Минимальная сумма вывода: 50€"""

    bot.send_message(user_id, text)

@bot.message_handler(func=lambda message: message.text == "📤 Вывод средств")
def withdraw_menu(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    if user_data['balance'] < 50:
        bot.send_message(user_id, f"❌ Минимальная сумма вывода - 50€\n💳 Ваш текущий баланс: {user_data['balance']:.2f}€")
        return
    
    # Спрашиваем сумму вывода
    bot.send_message(user_id, 
                    f"💳 Ваш текущий баланс: {user_data['balance']:.2f}€\n\n"
                    f"💰 Введите сумму для вывода (минимум 50€, максимум {user_data['balance']:.2f}€):")
    
    bot.register_next_step_handler(message, process_withdraw_amount)

@bot.message_handler(func=lambda message: message.text == "ℹ️ Инструкция")
def show_instructions(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    channels_compact = " • ".join([channel.replace('@', '') for channel in CHANNELS])
    
    text = f"""🎯 **ИНСТРУКЦИЯ ДЛЯ ПАРТНЕРОВ**

📢 **Необходимые каналы:**
`{channels_compact}`

💰 **Как зарабатывать:**
1. Приглашайте друзей по вашей реферальной ссылке
2. Друг должен подписаться на ВСЕ каналы
3. Вы получаете 0.25€ сразу за каждого приглашенного
4. +10% от всех покупок ваших рефералов

💸 **Условия вывода:**
• Минимальная сумма: 50€
• Можно выбрать любую сумму от 50€ до вашего баланса
• 🔓 Аккаунт должен быть открытым на 24 часа для связи
• 📞 При выводе укажите номер телефона для связи
• Можно использовать номер от Telegram или WhatsApp
• Доступные методы: Россия, Европа, Украина, СНГ, Telegram Stars, Криптовалюта
• Вывод обрабатывается вручную администратором

📞 **Контакты:**
При проблемах с выводом: {ADMIN_USERNAME}

📊 **Статистика:**
• Отслеживайте количество рефералов
• Следите за балансом и общим заработком
• Получайте уведомления о новых рефералах"""

    bot.send_message(user_id, text, parse_mode='Markdown')

@bot.message_handler(func=lambda message: message.text == "🎯 Увеличить доход")
def increase_income_tips(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    text = """🚀 **КАК УВЕЛИЧИТЬ ДОХОД:**

🎪 **Лайфхаки для привлечения рефералов:**
• Делитесь ссылкой в соцсетях и тематических чатах
• Создайте контент о нашем боте
• Приглашайте друзей личными сообщениями
• Используйте мессенджеры и соцсети

📈 **Стратегия:**
1. Начните с близкого круга друзей
2. Расширяйтесь на тематические сообщества
3. Создайте постоянный поток приглашений
4. Активно привлекайте новых пользователей

💡 **Помните:** больше рефералов = больше пассивного дохода!"""

    bot.send_message(user_id, text, parse_mode='Markdown')

@bot.message_handler(func=lambda message: message.text == "⬅️ Назад")
def back_to_main(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    # Очищаем pending данные при возврате в главное меню
    if user_data.get("pending_withdraw"):
        user_data["pending_withdraw"] = None
        save_user_data(user_data)
    
    welcome_text = get_user_stats(user_id)
    markup = main_menu()
    bot.send_message(user_id, welcome_text, reply_markup=markup)

# Остальной код для вывода средств (без изменений, но с проверкой на админа)
def process_withdraw_amount(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    try:
        amount = float(message.text.replace(',', '.'))
        
        if amount < 50:
            bot.send_message(user_id, "❌ Минимальная сумма вывода - 50€")
            return
        elif amount > user_data['balance']:
            bot.send_message(user_id, f"❌ Недостаточно средств. Ваш баланс: {user_data['balance']:.2f}€")
            return
    except ValueError:
        bot.send_message(user_id, "❌ Пожалуйста, введите корректную сумму (например: 50, 100, 150.50)")
        return
    
    # Сохраняем сумму вывода
    user_data["pending_withdraw"] = {
        "amount": amount,
        "step": "choose_method"
    }
    save_user_data(user_data)
    
    # Показываем методы вывода
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.add("🇷🇺 Россия", "🇪🇺 Европа")
    markup.add("🇺🇦 Украина", "🌍 СНГ")
    markup.add("⭐ Telegram Stars", "₿ Криптовалюта")
    markup.add("⬅️ Назад")
    
    bot.send_message(user_id, 
                    f"🌍 Выберите способ вывода средств:\n\n"
                    f"💵 Сумма вывода: {amount:.2f}€",
                    reply_markup=markup)

@bot.message_handler(func=lambda message: message.text in ["🇷🇺 Россия", "🇪🇺 Европа", "🇺🇦 Украина", "🌍 СНГ", "⭐ Telegram Stars", "₿ Криптовалюта"])
def handle_withdraw_method(message):
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    if not user_data.get("pending_withdraw"):
        bot.send_message(user_id, "❌ Ошибка: данные вывода не найдены. Начните заново.")
        return
    
    method = {
        "🇷🇺 Россия": "Россия (банковская карта)",
        "🇪🇺 Европа": "Европа (банковский перевод)",
        "🇺🇦 Украина": "Украина (банковская карта)", 
        "🌍 СНГ": "СНГ (разные методы)",
        "⭐ Telegram Stars": "Telegram Stars",
        "₿ Криптовалюта": "Криптовалюта (USDT TRC20)"
    }[message.text]
    
    # Обновляем данные вывода
    user_data["pending_withdraw"]["method"] = method
    user_data["pending_withdraw"]["step"] = "enter_phone"
    save_user_data(user_data)
    
    # Всегда запрашиваем номер телефона (как в первый раз)
    show_phone_input_request(user_id, user_data)

def show_phone_input_request(user_id, user_data):
    """Показывает запрос на ввод номера телефона"""
    important_info = """📋 **ВАЖНАЯ ИНФОРМАЦИЯ ДЛЯ ВЫВОДА**

🔓 **Откройте свой профиль Telegram:**
• Перейдите в Настройки → Конфиденциальность
• Сделайте профиль открытым на 24 часа
• Это нужно чтобы менеджер мог с вами связаться при проблемах

📞 **Номер телефона для связи:**
• Можно использовать номер от Telegram или WhatsApp
• Главное - чтобы можно было с вами связаться
• Номер нужен для подтверждения и связи

👇 **Введите ваш номер телефона:**"""
    
    bot.send_message(user_id, important_info, parse_mode='Markdown')
    
    # Устанавливаем следующий шаг
    user_data["pending_withdraw"]["step"] = "waiting_phone"
    save_user_data(user_data)

@bot.callback_query_handler(func=lambda call: call.data in ["use_current_phone", "change_phone_number"])
def handle_phone_choice(call):
    user_id = call.from_user.id
    if user_id == ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Админ не может использовать эту функцию")
        return
    
    user_data = load_user_data(user_id)
    
    if call.data == "use_current_phone":
        # Используем текущий номер, переходим к реквизитам
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text=f"✅ Используем номер: {user_data['phone_number']}\n\n"
                                 f"Теперь введите реквизиты для вывода...")
        
        ask_for_withdraw_details(call.message, user_data)
        
    elif call.data == "change_phone_number":
        # Просим ввести новый номер
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text="📱 **Введите новый номер телефона:**\n\n"
                                 "Можно использовать номер от Telegram или WhatsApp\n"
                                 "Формат: +79991234567 или 89991234567\n\n"
                                 "📞 Номер нужен для связи и подтверждения вывода.",
                            parse_mode='Markdown')
        
        user_data["pending_withdraw"]["step"] = "waiting_phone"
        save_user_data(user_data)

# ГЛАВНЫЙ ОБРАБОТЧИК ДОЛЖЕН БЫТЬ ПОСЛЕДНИМ
@bot.message_handler(func=lambda message: True, content_types=['text'])
def handle_all_text_messages(message):
    """Обработчик всех текстовых сообщений для отслеживания шагов вывода"""
    user_id = message.from_user.id
    if user_id == ADMIN_ID:
        return
    
    user_data = load_user_data(user_id)
    
    pending = user_data.get("pending_withdraw")
    if not pending:
        return
    
    current_step = pending.get("step")
    
    if current_step == "waiting_phone":
        process_phone_number(message, user_data)
    elif current_step == "waiting_details":
        process_withdraw_details_input(message, user_data)
    elif current_step == "enter_amount":
        process_withdraw_amount(message)
    elif current_step == "confirm_phone":  # ← ДОБАВЬТЕ ЭТУ СТРОКУ
        show_confirmation(message, user_data)  # ← И ЭТУ СТРОКУ

def process_phone_number(message, user_data):
    """Обрабатывает ввод номера телефона"""
    user_id = message.from_user.id
    phone_number = message.text.strip()
    
    # Простая валидация номера
    if not any(char.isdigit() for char in phone_number) or len(phone_number) < 10:
        bot.send_message(user_id, "❌ Пожалуйста, введите корректный номер телефона")
        return
    
    # Сохраняем номер телефона с историей изменений
    old_phone = user_data.get("phone_number")
    
    # Добавляем в историю изменений
    if old_phone and old_phone != phone_number:
        user_data["phone_history"].append({
            "old_phone": old_phone,
            "new_phone": phone_number,
            "changed_at": datetime.now().isoformat()
        })
    
    user_data["phone_number"] = phone_number
    user_data["pending_withdraw"]["step"] = "waiting_details"
    save_user_data(user_data)
    
    if old_phone and old_phone != phone_number:
        bot.send_message(user_id, f"✅ Номер телефона изменен: {old_phone} → {phone_number}")
    else:
        bot.send_message(user_id, f"✅ Номер телефона сохранен: {phone_number}")
    
    # Переходим к вводу реквизитов
    ask_for_withdraw_details(message, user_data)

def ask_for_withdraw_details(message, user_data):
    """Запрашивает реквизиты для вывода"""
    user_id = message.from_user.id
    pending = user_data["pending_withdraw"]
    method = pending["method"]
    
    # Формируем инструкции в зависимости от метода
    instructions = {
        "Россия (банковская карта)": "💳 **Укажите:**\n• Номер банковской карты\n• ФИО владельца карты\n• Банк (если известно)",
        "Европа (банковский перевод)": "💳 **Укажите:**\n• IBAN номер счета\n• ФИО владельца счета\n• Название банка\n• BIC/SWIFT код",
        "Украина (банковская карта)": "💳 **Укажите:**\n• Номер банковской карты\n• ФИО владельца карты\n• Банк",
        "СНГ (разные методы)": "💳 **Укажите:**\n• Реквизиты для получения\n• ФИО получателя\n• Способ получения",
        "Telegram Stars": "⭐ **Укажите:**\n• Ваш Telegram username\n• Количество Stars для вывода",
        "Криптовалюта (USDT TRC20)": "₿ **Укажите:**\n• Адрес кошелька USDT TRC20\n• Сеть: TRC20 (Tron)"
    }
    
    instruction_text = instructions.get(method, "💳 **Укажите реквизиты для получения средств:**")
    
    # Создаем кнопку для изменения номера
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("📱 Изменить номер телефона", callback_data="change_phone_before_details"))
    
    bot.send_message(user_id,
                    f"📝 **Отправьте реквизиты для вывода:**\n\n"
                    f"💳 Метод: {method}\n"
                    f"💵 Сумма: {pending['amount']:.2f}€\n"
                    f"📱 Телефон: {user_data['phone_number']}\n\n"
                    f"{instruction_text}\n\n"
                    f"⚠️ Проверьте правильность данных перед отправкой!",
                    reply_markup=markup,
                    parse_mode='Markdown')
    
    user_data["pending_withdraw"]["step"] = "waiting_details"
    save_user_data(user_data)

@bot.callback_query_handler(func=lambda call: call.data == "change_phone_before_details")
def handle_change_phone_before_details(call):
    user_id = call.from_user.id
    if user_id == ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Админ не может использовать эту функцию")
        return
    
    user_data = load_user_data(user_id)
    
    bot.edit_message_text(chat_id=user_id,
                         message_id=call.message.message_id,
                         text="📱 **Введите новый номер телефона:**\n\n"
                              "Можно использовать номер от Telegram или WhatsApp\n"
                              "Формат: +79991234567 или 89991234567\n\n"
                              "📞 Номер нужен для связи и подтверждения вывода.",
                         parse_mode='Markdown')
    
    user_data["pending_withdraw"]["step"] = "waiting_phone"
    save_user_data(user_data)

def process_withdraw_details_input(message, user_data):
    """Обрабатывает ввод реквизитов и показывает подтверждение"""
    user_id = message.from_user.id
    withdraw_details = message.text
    
    # Сохраняем реквизиты
    user_data["pending_withdraw"]["details"] = withdraw_details
    save_user_data(user_data)
    
    # Проверяем, есть ли сохраненный номер телефона
    if user_data.get("phone_number"):
        # Показываем текущий номер и предлагаем изменить
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("✅ Использовать текущий номер", callback_data="use_current_phone"))
        markup.add(types.InlineKeyboardButton("📱 Изменить номер", callback_data="change_phone_number"))
        
        bot.send_message(user_id,
                        f"📋 **Подтвердите номер телефона:**\n\n"
                        f"📱 Ваш текущий номер: {user_data['phone_number']}\n\n"
                        f"ℹ️ Если номер верный - используйте текущий, иначе измените его.",
                        reply_markup=markup)
        
        user_data["pending_withdraw"]["step"] = "confirm_phone"
        save_user_data(user_data)
    else:
        # Номера нет, просим ввести
        show_phone_input_request(user_id, user_data)

def show_confirmation(message, user_data):
    """Показывает подтверждение вывода"""
    user_id = message.from_user.id
    pending = user_data["pending_withdraw"]
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("✅ Да, все верно", callback_data="confirm_withdraw_yes"),
        types.InlineKeyboardButton("❌ Нет, исправить", callback_data="confirm_withdraw_no")
    )
    
    bot.send_message(user_id,
                    f"🔍 **Проверьте данные перед отправкой:**\n\n"
                    f"💵 Сумма: {pending['amount']:.2f}€\n"
                    f"💳 Метод: {pending['method']}\n"
                    f"📱 Телефон: {user_data['phone_number']}\n"
                    f"📋 Реквизиты:\n{pending['details']}\n\n"
                    f"**Всё верно?**",
                    reply_markup=markup,
                    parse_mode='Markdown')
    
    user_data["pending_withdraw"]["step"] = "confirm_details"
    save_user_data(user_data)
    
@bot.callback_query_handler(func=lambda call: call.data in ["confirm_withdraw_yes", "confirm_withdraw_no"])
def handle_confirmation(call):
    user_id = call.from_user.id
    if user_id == ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Админ не может использовать эту функцию")
        return
    
    user_data = load_user_data(user_id)
    
    if call.data == "confirm_withdraw_yes":
        # Подтверждаем вывод
        complete_withdraw_request(call, user_data)
    elif call.data == "confirm_withdraw_no":
        # Предлагаем исправить данные
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("📱 Исправить номер", callback_data="fix_phone"),
            types.InlineKeyboardButton("📋 Исправить реквизиты", callback_data="fix_details"),
            types.InlineKeyboardButton("💳 Исправить метод", callback_data="fix_method"),
            types.InlineKeyboardButton("💵 Исправить сумму", callback_data="fix_amount")
        )
        
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text="❌ **Что нужно исправить?**\n\nВыберите что изменить:",
                            reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith('fix_'))
def handle_fix_data(call):
    user_id = call.from_user.id
    if user_id == ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Админ не может использовать эту функцию")
        return
    
    user_data = load_user_data(user_id)
    
    if call.data == "fix_phone":
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text="📱 **Введите новый номер телефона:**")
        user_data["pending_withdraw"]["step"] = "waiting_phone"
        save_user_data(user_data)
        
    elif call.data == "fix_details":
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text="📝 **Введите правильные реквизиты:**")
        user_data["pending_withdraw"]["step"] = "waiting_details"
        save_user_data(user_data)
        
    elif call.data == "fix_method":
        # Возвращаем к выбору метода
        user_data["pending_withdraw"]["step"] = "choose_method"
        save_user_data(user_data)
        
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
        markup.add("🇷🇺 Россия", "🇪🇺 Европа")
        markup.add("🇺🇦 Украина", "🌍 СНГ")
        markup.add("⭐ Telegram Stars", "₿ Криптовалюта")
        markup.add("⬅️ Назад")
        
        bot.send_message(user_id,
                        f"🌍 Выберите способ вывода средств:\n\n"
                        f"💵 Сумма вывода: {user_data['pending_withdraw']['amount']:.2f}€",
                        reply_markup=markup)
        
    elif call.data == "fix_amount":
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text=f"💰 Введите новую сумму для вывода (минимум 50€, максимум {user_data['balance']:.2f}€):")
        user_data["pending_withdraw"]["step"] = "enter_amount"
        save_user_data(user_data)

def complete_withdraw_request(call, user_data):
    """Завершает запрос на вывод и отправляет администратору"""
    user_id = call.from_user.id
    pending = user_data["pending_withdraw"]
    
    amount = pending["amount"]
    method = pending["method"]
    phone_number = user_data["phone_number"]
    withdraw_details = pending["details"]
    
    # Пересылаем данные администратору
    forward_text = f"🔄 ЗАПРОС ВЫВОДА\n\n" \
                  f"👤 Пользователь: @{user_data['username']} (ID: {user_id})\n" \
                  f"📱 Телефон: {phone_number}\n" \
                  f"💳 Метод: {method}\n" \
                  f"💵 Сумма: {amount:.2f}€\n" \
                  f"📋 Реквизиты:\n{withdraw_details}\n\n"
    
    # Добавляем историю номеров если есть
    if user_data.get("phone_history"):
        forward_text += f"📞 История номеров:\n"
        for history in user_data["phone_history"][-3:]:
            old_phone = history.get("old_phone", "не указан")
            new_phone = history.get("new_phone", "не указан")
            changed_at = history.get("changed_at", "")
            forward_text += f"• {old_phone} → {new_phone} ({changed_at[:16]})\n"
    
    forward_text += f"\n⏰ Время: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    # Отправляем администратору (с возможностью ответа)
    try:
        sent_msg = bot.send_message(ADMIN_ID, forward_text)
        admin_sent = True
    except Exception as e:
        print(f"Ошибка отправки админу: {e}")
        admin_sent = False
    
    # Обновляем баланс и сохраняем транзакцию
    user_data["balance"] = round(user_data["balance"] - amount, 2)
    user_data["transactions"].append({
        "type": "withdraw",
        "amount": amount,
        "method": method,
        "phone": phone_number,
        "details": withdraw_details,
        "timestamp": datetime.now().isoformat(),
        "status": "pending"
    })
    
    # Очищаем временные данные
    user_data["pending_withdraw"] = None
    save_user_data(user_data)
    
    # Ответ пользователю
    markup = main_menu()
    if admin_sent:
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text="✅ **Запрос на вывод отправлен!**\n\n"
                                 "📊 Детали запроса:\n"
                                 f"• Сумма: {amount:.2f}€\n"
                                 f"• Метод: {method}\n"
                                 f"• Телефон: {phone_number}\n\n"
                                 "⏳ Ожидайте обработки администратором.\n"
                                 "🔓 Не забудьте держать профиль открытым 24 часа\n\n"
                                 f"📞 По вопросам: {ADMIN_USERNAME}",
                            reply_markup=None)
    else:
        bot.edit_message_text(chat_id=user_id,
                            message_id=call.message.message_id,
                            text="❌ **Ошибка отправки запроса!**\n\n"
                                 "Пожалуйста, попробуйте позже или свяжитесь с администратором.",
                            reply_markup=None)
    
    bot.send_message(user_id, "🔄 Возвращаемся в главное меню...", reply_markup=markup)
# 👍new 

# Обработчик ответов администратора
@bot.message_handler(func=lambda message: message.reply_to_message and message.from_user.id == ADMIN_ID)
def handle_admin_reply(message):
    """Обрабатывает ответ администратора на запрос вывода"""
    try:
        # Получаем оригинальное сообщение
        original_message = message.reply_to_message.text
        
        # Ищем ID пользователя в сообщении (улучшенный поиск)
        if "ID:" in original_message:
            # Более надежный способ извлечения ID
            import re
            match = re.search(r'ID:\s*(\d+)', original_message)
            if match:
                user_id = int(match.group(1))
                
                # Отправляем ответ пользователю
                bot.send_message(user_id, f"📢 **Ответ от администратора:**\n\n{message.text}")
                
                # Подтверждаем администратору
                bot.reply_to(message, "✅ Ответ отправлен пользователю!")
            else:
                bot.reply_to(message, "❌ Не удалось извлечь ID пользователя")
        else:
            bot.reply_to(message, "❌ Это не сообщение с запросом вывода")
            
    except Exception as e:
        bot.reply_to(message, f"❌ Ошибка: {e}")


if __name__ == "__main__":
    print("Бот запущен...")
    print(f"Папка с данными: {DATA_DIR}")
    if os.path.exists(DATA_DIR):
        user_files = len([f for f in os.listdir(DATA_DIR) if f.endswith('.json')])
        print(f"✅ Папка с данными уже существует ({user_files} пользователей)")
    else:
        print("📁 Папка с данными будет создана при первом сохранении")
    
    channels_compact = " • ".join([channel.replace('@', '') for channel in CHANNELS])
    print(f"Отслеживаемые каналы: {channels_compact}")
    
    try:
        bot.infinity_polling(timeout=60, long_polling_timeout=30)
    except Exception as e:
        print(f"Ошибка бота: {e}")