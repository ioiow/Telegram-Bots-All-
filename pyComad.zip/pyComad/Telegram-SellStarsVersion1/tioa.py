# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════════╗
║              ⭐ TELEGRAM STARS BOT v3.1 - TERMUX OPTIMIZED                       ║
║                    Разделённое хранение + Все настройки                          ║
╚══════════════════════════════════════════════════════════════════════════════════╝
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, LabeledPrice
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, PreCheckoutQueryHandler, ContextTypes, filters
from telegram.request import HTTPXRequest

# ╔══════════════════════════════════════════════════════════════════════════════════╗
# ║                           🔧 ВСЕ НАСТРОЙКИ ЗДЕСЬ 🔧                              ║
# ║                      ИЗМЕНИТЕ ЭТИ ЗНАЧЕНИЯ ПОД СЕБЯ                              ║
# ╚══════════════════════════════════════════════════════════════════════════════════╝

# ═══════════════════════ ОСНОВНЫЕ НАСТРОЙКИ ═══════════════════════
BOT_TOKEN = "7411726964:AAGF6NipjdkWPg8KYkbySADPLBYNWq1ffoI"           # 🔑 Токен от @BotFather
CHANNEL_USERNAME = "@StarOfficeOnline"            # 📢 Канал для подписки (с @)
ADMIN_ID = 8550701850                         # 👑 Ваш Telegram ID (число)
WEBSITE_LINK = "https://t.me/StarsTelegramVip_Bot/web"   # 🌐 Ссылка на сайт

# ═══════════════════════ БОТ ДЛЯ ПЛАТЕЖЕЙ ═══════════════════════
# Оставьте пустым — звёзды идут этому боту
# Или укажите username другого бота: "@PaymentBot"
PAYMENT_BOT_USERNAME = ""

# ═══════════════════════ ПУТИ К ФАЙЛАМ ═══════════════════════
# 3 отдельных файла = нет конфликтов = нет лагов!
DATA_DIR = "data"  # Папка для файлов
ADMIN_DATA_FILE = f"{DATA_DIR}/storage/emulated/0/Download/pyComad/Telegram-SellStarsVersion1/admin_settings.json"   # Настройки админа
USERS_DATA_FILE = f"{DATA_DIR}/storage/emulated/0/Download/pyComad/Telegram-SellStarsVersion1/users_data.json"       # Пользователи + транзакции
BUTTONS_DATA_FILE = f"{DATA_DIR}/storage/emulated/0/Download/pyComad/Telegram-SellStarsVersion1/buttons_data.jsonon"   # Кастомные кнопки

# ═══════════════════════ ТАЙМАУТЫ ДЛЯ TERMUX ═══════════════════════
# Увеличенные значения для медленного интернета
CONNECT_TIMEOUT = 30.0   # Время подключения
READ_TIMEOUT = 30.0      # Время чтения
WRITE_TIMEOUT = 30.0     # Время записи
POOL_TIMEOUT = 10.0      # Время пула

# ═══════════════════════ ВАЛЮТЫ ═══════════════════════
CURRENCIES = {
    "RUB": {"symbol": "₽", "name": "Российский рубль"},
    "USD": {"symbol": "$", "name": "Доллар США"},
    "EUR": {"symbol": "€", "name": "Евро"},
    "UAH": {"symbol": "₴", "name": "Гривна"},
    "KZT": {"symbol": "₸", "name": "Тенге"},
    "UZS": {"symbol": "сум", "name": "Сум"},
    "BYN": {"symbol": "Br", "name": "Бел. рубль"},
    "TRY": {"symbol": "₺", "name": "Лира"},
    "GEL": {"symbol": "₾", "name": "Лари"},
    "AMD": {"symbol": "֏", "name": "Драм"},
    "AZN": {"symbol": "₼", "name": "Манат"},
    "USDT": {"symbol": "USDT", "name": "Tether"},
    "TON": {"symbol": "TON", "name": "Toncoin"},
}

# ═══════════════════════ НАСТРОЙКИ ПО УМОЛЧАНИЮ ═══════════════════════
DEFAULT_SETTINGS = {
    "enabled": True,
    "currency": "RUB",
    "rate": 1.5,
    "min_stars": 10,
    "max_stars": 10000,
    "sell_text": "⭐ <b>Продажа Telegram Stars</b>\n\nВы продаёте: <b>{amount} ⭐</b>\n💰 Вы получите: <b>{money} {symbol}</b>\n\n👇 Нажмите кнопку для отправки:",
    "sell_photo": "",
    "success_text": "✅ <b>Оплата получена!</b>\n\n⭐ Звёзд: <b>{amount}</b>\n💰 К выплате: <b>{money} {symbol}</b>\n\nАдмин свяжется с вами!",
    "success_photo": "",
    "cancel_text": "❌ <b>Отменено</b>\n\nВы отменили продажу звёзд.",
    "cancel_photo": "",
}

# ╚══════════════════════════════════════════════════════════════════════════════════╝
#                              КОНЕЦ НАСТРОЕК                                         
# ╚══════════════════════════════════════════════════════════════════════════════════╝

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Глобальные данные
admin_data: Dict[str, Any] = {}
users_data: Dict[str, Any] = {}
buttons_data: Dict[str, Any] = {}
admin_state: Dict[str, Any] = {}
user_dialogs: Dict[int, list] = {}

# ═══════════════════════ РАБОТА С ФАЙЛАМИ ═══════════════════════

def ensure_dir():
    """Создаёт папку для данных"""
    if DATA_DIR and not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)

def load_json(path: str, default: dict) -> dict:
    """Безопасная загрузка JSON"""
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:  # Проверяем что файл не пустой!
                    return json.loads(content)
    except Exception as e:
        logger.warning(f"Загрузка {path}: {e} — используем дефолт")
    return default.copy()

def save_json(path: str, data: dict):
    """Сохранение JSON"""
    try:
        ensure_dir()
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Ошибка сохранения {path}: {e}")

def init_data():
    """Инициализация всех данных"""
    global admin_data, users_data, buttons_data
    ensure_dir()
    
    # Настройки админа
    admin_data = load_json(ADMIN_DATA_FILE, {"settings": DEFAULT_SETTINGS.copy()})
    if "settings" not in admin_data:
        admin_data["settings"] = DEFAULT_SETTINGS.copy()
    # Добавляем недостающие ключи
    for key, val in DEFAULT_SETTINGS.items():
        if key not in admin_data["settings"]:
            admin_data["settings"][key] = val
    
    # Пользователи
    users_data = load_json(USERS_DATA_FILE, {"users": [], "transactions": []})
    if "users" not in users_data:
        users_data["users"] = []
    if "transactions" not in users_data:
        users_data["transactions"] = []
    
    # Кнопки
    buttons_data = load_json(BUTTONS_DATA_FILE, {"buttons": {}})
    if "buttons" not in buttons_data:
        buttons_data["buttons"] = {}

init_data()

# ═══════════════════════ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ═══════════════════════

def s() -> dict:
    """Настройки звёзд"""
    return admin_data.get("settings", DEFAULT_SETTINGS)

def sym() -> str:
    """Символ валюты"""
    cur = s().get("currency", "RUB")
    return CURRENCIES.get(cur, {}).get("symbol", "₽")

def is_admin(uid: int) -> bool:
    """Проверка админа"""
    return str(uid) == str(ADMIN_ID)

def fmt(template: str, amount: int, money: float) -> str:
    """Форматирование текста с переменными"""
    return template.replace("{amount}", str(amount)).replace("{money}", str(money)).replace("{symbol}", sym())

# ═══════════════════════ КЛАВИАТУРЫ ═══════════════════════

def kb_main():
    return ReplyKeyboardMarkup([
        [KeyboardButton("🌐 Сайт"), KeyboardButton("💫 Продать звёзды")],
        [KeyboardButton("📝 Написать админу"), KeyboardButton("ℹ️ Помощь")],
        [KeyboardButton("📢 Проверить подписку")]
    ], resize_keyboard=True)

def kb_admin():
    return ReplyKeyboardMarkup([
        [KeyboardButton("📋 Диалоги"), KeyboardButton("📊 Статистика")],
        [KeyboardButton("➕ Добавить кнопку"), KeyboardButton("🗑 Удалить кнопку")],
        [KeyboardButton("✏️ Помощь"), KeyboardButton("📜 Список кнопок")],
        [KeyboardButton("💫 Настройка звёзд"), KeyboardButton("📈 История продаж")],
        [KeyboardButton("📢 Рассылка"), KeyboardButton("🚫 Отмена")]
    ], resize_keyboard=True)

def kb_cancel():
    return ReplyKeyboardMarkup([[KeyboardButton("🚫 Отмена")]], resize_keyboard=True)

def kb_sub():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Подписаться", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton("✅ Я подписался", callback_data="check_sub")]
    ])

def kb_stars_menu():
    """Меню настроек звёзд"""
    st = s()
    status = "✅ ВКЛ" if st.get("enabled") else "❌ ВЫКЛ"
    cur = st.get("currency", "RUB")
    symbol = CURRENCIES.get(cur, {}).get("symbol", "₽")
    
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Статус: {status}", callback_data="st_toggle")],
        [InlineKeyboardButton(f"💱 Валюта: {cur} ({symbol})", callback_data="st_currency")],
        [InlineKeyboardButton(f"💰 Курс: {st.get('rate', 1.5)} {symbol}/⭐", callback_data="st_rate")],
        [InlineKeyboardButton(f"📊 Лимиты: {st.get('min_stars', 10)} - {st.get('max_stars', 10000)}", callback_data="st_limits")],
        [InlineKeyboardButton("📝 Текст продажи", callback_data="st_sell_text")],
        [InlineKeyboardButton("🖼 Фото продажи", callback_data="st_sell_photo")],
        [InlineKeyboardButton("✅ Текст успеха", callback_data="st_ok_text")],
        [InlineKeyboardButton("🖼 Фото успеха", callback_data="st_ok_photo")],
        [InlineKeyboardButton("❌ Текст отмены", callback_data="st_no_text")],
        [InlineKeyboardButton("🖼 Фото отмены", callback_data="st_no_photo")],
        [InlineKeyboardButton("🔙 Закрыть", callback_data="st_close")]
    ])

def kb_currencies():
    """Выбор валюты"""
    rows = []
    row = []
    for code, info in CURRENCIES.items():
        row.append(InlineKeyboardButton(f"{info['symbol']} {code}", callback_data=f"cur_{code}"))
        if len(row) == 3:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("🔙 Назад", callback_data="st_back")])
    return InlineKeyboardMarkup(rows)

def kb_help_buttons():
    """Кнопки помощи"""
    btns = []
    for bid, b in buttons_data.get("buttons", {}).items():
        if b.get("section") == "help":
            if b.get("type") == "link":
                btns.append([InlineKeyboardButton(b["name"], url=b["content"])])
            else:
                btns.append([InlineKeyboardButton(b["name"], callback_data=bid)])
    return InlineKeyboardMarkup(btns) if btns else None

# ═══════════════════════ ПРОВЕРКА ПОДПИСКИ ═══════════════════════

async def check_sub(uid: int, ctx) -> bool:
    try:
        m = await ctx.bot.get_chat_member(CHANNEL_USERNAME, uid)
        return m.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Проверка подписки: {e}")
        return False

# ═══════════════════════ КОМАНДА /start ═══════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    
    # Сохраняем пользователя
    if uid not in users_data["users"]:
        users_data["users"].append(uid)
        save_json(USERS_DATA_FILE, users_data)
    
    if not await check_sub(uid, ctx):
        await update.message.reply_text(
            f"📢 Для использования бота подпишитесь на канал {CHANNEL_USERNAME}",
            reply_markup=kb_sub()
        )
        return
    
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text(
        f"👋 <b>Добро пожаловать!</b>\n\n"
        f"🌐 <a href='{WEBSITE_LINK}'>Наш сайт</a>\n"
        f"💫 Продавайте Telegram Stars выгодно!\n\n"
        f"Используйте кнопки ниже 👇",
        parse_mode='HTML', disable_web_page_preview=True, reply_markup=kb
    )

async def cb_check_sub(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    
    if await check_sub(uid, ctx):
        kb = kb_admin() if is_admin(uid) else kb_main()
        await q.edit_message_text("✅ Подписка подтверждена!")
        await ctx.bot.send_message(uid, "Выберите действие:", reply_markup=kb)
    else:
        await q.edit_message_text(f"❌ Вы не подписаны на {CHANNEL_USERNAME}", reply_markup=kb_sub())

# ═══════════════════════ ПРОДАЖА ЗВЁЗД ═══════════════════════

async def handle_sell(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    
    if not await check_sub(uid, ctx):
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=kb_sub())
        return
    
    st = s()
    if not st.get("enabled"):
        kb = kb_admin() if is_admin(uid) else kb_main()
        await update.message.reply_text("⚠️ Продажа звёзд временно недоступна", reply_markup=kb)
        return
    
    ctx.user_data['state'] = 'stars_amount'
    
    await update.message.reply_text(
        f"💫 <b>Продажа Telegram Stars</b>\n\n"
        f"💰 Курс: <b>1 ⭐ = {st.get('rate', 1.5)} {sym()}</b>\n"
        f"📊 Лимиты: от <b>{st.get('min_stars', 10)}</b> до <b>{st.get('max_stars', 10000)}</b>\n\n"
        f"Введите количество звёзд:",
        parse_mode='HTML', reply_markup=kb_cancel()
    )

async def process_amount(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    """Обработка количества звёзд"""
    if ctx.user_data.get('state') != 'stars_amount':
        return False
    
    uid = update.effective_user.id
    ctx.user_data['state'] = None
    kb = kb_admin() if is_admin(uid) else kb_main()
    
    try:
        amount = int(update.message.text)
    except ValueError:
        await update.message.reply_text("❌ Введите число!", reply_markup=kb)
        return True
    
    st = s()
    min_s = st.get('min_stars', 10)
    max_s = st.get('max_stars', 10000)
    
    if amount < min_s:
        await update.message.reply_text(f"❌ Минимум: {min_s} звёзд", reply_markup=kb)
        return True
    
    if amount > max_s:
        await update.message.reply_text(f"❌ Максимум: {max_s} звёзд", reply_markup=kb)
        return True
    
    money = round(amount * st.get('rate', 1.5), 2)
    txt = fmt(st.get('sell_text', DEFAULT_SETTINGS['sell_text']), amount, money)
    photo = st.get('sell_photo')
    
    try:
        if photo:
            await ctx.bot.send_photo(uid, photo, caption=txt, parse_mode='HTML')
        
        await ctx.bot.send_invoice(
            chat_id=uid,
            title="Продажа Telegram Stars",
            description=f"Отправка {amount} звёзд для обмена",
            payload=f"sell_{uid}_{amount}_{money}",
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice("Telegram Stars", amount)],
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"⭐ Отправить {amount} звёзд", pay=True)],
                [InlineKeyboardButton("❌ Отмена", callback_data="cancel_pay")]
            ])
        )
    except Exception as e:
        logger.error(f"Ошибка инвойса: {e}")
        await update.message.reply_text(f"❌ Ошибка: {e}", reply_markup=kb)
    
    return True

async def cb_cancel_pay(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    
    st = s()
    kb = kb_admin() if is_admin(uid) else kb_main()
    
    try:
        await q.message.delete()
    except:
        pass
    
    photo = st.get('cancel_photo')
    txt = st.get('cancel_text', '❌ Отменено')
    
    if photo:
        await ctx.bot.send_photo(uid, photo, caption=txt, parse_mode='HTML', reply_markup=kb)
    else:
        await ctx.bot.send_message(uid, txt, parse_mode='HTML', reply_markup=kb)

async def precheckout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.pre_checkout_query
    if q.invoice_payload.startswith("sell_"):
        await q.answer(ok=True)
    else:
        await q.answer(ok=False, error_message="Неизвестный платёж")

async def success_payment(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    payment = update.message.successful_payment
    payload = payment.invoice_payload
    
    if not payload.startswith("sell_"):
        return
    
    parts = payload.split("_")
    amount = int(parts[2])
    money = float(parts[3])
    
    st = s()
    
    # Сохраняем транзакцию
    tx = {
        "user_id": user.id,
        "username": user.username,
        "full_name": user.full_name,
        "amount": amount,
        "money": money,
        "currency": st.get("currency", "RUB"),
        "time": datetime.now().isoformat(),
        "payment_id": payment.telegram_payment_charge_id
    }
    users_data["transactions"].append(tx)
    save_json(USERS_DATA_FILE, users_data)  # Сразу сохраняем!
    
    # Сообщение пользователю
    kb = kb_admin() if is_admin(user.id) else kb_main()
    txt = fmt(st.get('success_text', DEFAULT_SETTINGS['success_text']), amount, money)
    photo = st.get('success_photo')
    
    if photo:
        await ctx.bot.send_photo(user.id, photo, caption=txt, parse_mode='HTML', reply_markup=kb)
    else:
        await update.message.reply_text(txt, parse_mode='HTML', reply_markup=kb)
    
    # Уведомление админу
    try:
        await ctx.bot.send_message(
            ADMIN_ID,
            f"💫 <b>НОВАЯ ПРОДАЖА!</b>\n\n"
            f"👤 {user.full_name} (@{user.username or 'нет'})\n"
            f"🆔 ID: {user.id}\n\n"
            f"⭐ Звёзд: <b>{amount}</b>\n"
            f"💰 К выплате: <b>{money} {sym()}</b>\n\n"
            f"🔑 {payment.telegram_payment_charge_id}",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user.id}")]
            ])
        )
    except Exception as e:
        logger.error(f"Уведомление админу: {e}")

# ═══════════════════════ НАСТРОЙКИ ЗВЁЗД (АДМИН) ═══════════════════════

async def handle_stars_settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    st = s()
    status = "✅ Включено" if st.get("enabled") else "❌ Выключено"
    cur = st.get("currency", "RUB")
    symbol = CURRENCIES.get(cur, {}).get("symbol", "₽")
    
    await update.message.reply_text(
        f"💫 <b>НАСТРОЙКИ ПРОДАЖИ ЗВЁЗД</b>\n\n"
        f"📊 Статус: {status}\n"
        f"💱 Валюта: {cur} ({symbol})\n"
        f"💰 Курс: 1⭐ = {st.get('rate', 1.5)} {symbol}\n"
        f"📉 Мин: {st.get('min_stars', 10)} | Макс: {st.get('max_stars', 10000)}\n\n"
        f"Выберите настройку:",
        parse_mode='HTML', reply_markup=kb_stars_menu()
    )

async def cb_stars(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    
    if not is_admin(q.from_user.id):
        await q.answer("❌ Только для админа!", show_alert=True)
        return
    
    data = q.data
    st = s()
    
    if data == "st_toggle":
        st["enabled"] = not st.get("enabled", True)
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        status = "✅ ВКЛ" if st["enabled"] else "❌ ВЫКЛ"
        await q.edit_message_text(f"Статус изменён: <b>{status}</b>", parse_mode='HTML', reply_markup=kb_stars_menu())
    
    elif data == "st_currency":
        cur = st.get("currency", "RUB")
        await q.edit_message_text(
            f"💱 <b>Выбор валюты</b>\n\nТекущая: {cur} ({sym()})\n\nВыберите новую:",
            parse_mode='HTML', reply_markup=kb_currencies()
        )
    
    elif data == "st_rate":
        admin_state['action'] = 'set_rate'
        await q.edit_message_text(
            f"💰 <b>Изменение курса</b>\n\n"
            f"Текущий: 1⭐ = {st.get('rate', 1.5)} {sym()}\n\n"
            f"Введите новый курс (число):",
            parse_mode='HTML'
        )
    
    elif data == "st_limits":
        admin_state['action'] = 'set_limit_min'
        await q.edit_message_text(
            f"📊 <b>Изменение лимитов</b>\n\n"
            f"Текущие: {st.get('min_stars', 10)} - {st.get('max_stars', 10000)}\n\n"
            f"Введите <b>МИНИМУМ</b> звёзд:",
            parse_mode='HTML'
        )
    
    elif data == "st_sell_text":
        admin_state['action'] = 'set_sell_text'
        await q.edit_message_text(
            f"📝 <b>Текст запроса продажи</b>\n\n"
            f"Переменные: {{amount}}, {{money}}, {{symbol}}\n\n"
            f"Текущий:\n<code>{st.get('sell_text', '')[:300]}</code>\n\n"
            f"Введите новый текст:",
            parse_mode='HTML'
        )
    
    elif data == "st_sell_photo":
        admin_state['action'] = 'set_sell_photo'
        has = "✅ Установлено" if st.get("sell_photo") else "❌ Не установлено"
        await q.edit_message_text(
            f"🖼 <b>Фото запроса продажи</b>\n\nСтатус: {has}\n\n"
            f"Отправьте фото или напишите <b>нет</b> для удаления:",
            parse_mode='HTML'
        )
    
    elif data == "st_ok_text":
        admin_state['action'] = 'set_ok_text'
        await q.edit_message_text(
            f"✅ <b>Текст успешной оплаты</b>\n\n"
            f"Переменные: {{amount}}, {{money}}, {{symbol}}\n\n"
            f"Введите новый текст:",
            parse_mode='HTML'
        )
    
    elif data == "st_ok_photo":
        admin_state['action'] = 'set_ok_photo'
        has = "✅ Установлено" if st.get("success_photo") else "❌ Не установлено"
        await q.edit_message_text(
            f"🖼 <b>Фото успеха</b>\n\nСтатус: {has}\n\n"
            f"Отправьте фото или <b>нет</b>:",
            parse_mode='HTML'
        )
    
    elif data == "st_no_text":
        admin_state['action'] = 'set_no_text'
        await q.edit_message_text(
            f"❌ <b>Текст отмены</b>\n\nВведите новый текст:",
            parse_mode='HTML'
        )
    
    elif data == "st_no_photo":
        admin_state['action'] = 'set_no_photo'
        has = "✅ Установлено" if st.get("cancel_photo") else "❌ Не установлено"
        await q.edit_message_text(
            f"🖼 <b>Фото отмены</b>\n\nСтатус: {has}\n\nОтправьте фото или <b>нет</b>:",
            parse_mode='HTML'
        )
    
    elif data == "st_close":
        admin_state.clear()
        await q.message.delete()
        await ctx.bot.send_message(q.from_user.id, "✅ Настройки закрыты", reply_markup=kb_admin())
    
    elif data == "st_back":
        await q.edit_message_text("💫 <b>Настройки звёзд</b>\n\nВыберите:", parse_mode='HTML', reply_markup=kb_stars_menu())

async def cb_currency(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    
    if not is_admin(q.from_user.id):
        return
    
    currency = q.data.replace("cur_", "")
    if currency in CURRENCIES:
        st = s()
        st["currency"] = currency
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        
        name = CURRENCIES[currency]["name"]
        symbol = CURRENCIES[currency]["symbol"]
        await q.edit_message_text(
            f"✅ Валюта изменена!\n\n<b>{currency}</b> — {name} ({symbol})",
            parse_mode='HTML', reply_markup=kb_stars_menu()
        )

async def handle_admin_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    """Обработка текстового ввода от админа"""
    if not is_admin(update.effective_user.id):
        return False
    
    action = admin_state.get('action')
    if not action:
        return False
    
    text = update.message.text
    st = s()
    
    # Курс
    if action == 'set_rate':
        try:
            rate = float(text.replace(',', '.'))
            if rate <= 0:
                await update.message.reply_text("❌ Курс должен быть > 0")
                return True
            st["rate"] = rate
            admin_data["settings"] = st
            save_json(ADMIN_DATA_FILE, admin_data)
            admin_state.clear()
            await update.message.reply_text(f"✅ Курс: 1⭐ = {rate} {sym()}", reply_markup=kb_admin())
        except:
            await update.message.reply_text("❌ Введите число (например: 1.5)")
        return True
    
    # Минимум
    if action == 'set_limit_min':
        try:
            min_val = int(text)
            if min_val < 1:
                await update.message.reply_text("❌ Минимум должен быть >= 1")
                return True
            admin_state['min_val'] = min_val
            admin_state['action'] = 'set_limit_max'
            await update.message.reply_text(f"✅ Минимум: {min_val}\n\nТеперь введите <b>МАКСИМУМ</b>:", parse_mode='HTML')
        except:
            await update.message.reply_text("❌ Введите целое число!")
        return True
    
    # Максимум
    if action == 'set_limit_max':
        try:
            max_val = int(text)
            min_val = admin_state.get('min_val', 10)
            if max_val < min_val:
                await update.message.reply_text(f"❌ Максимум должен быть >= {min_val}")
                return True
            st["min_stars"] = min_val
            st["max_stars"] = max_val
            admin_data["settings"] = st
            save_json(ADMIN_DATA_FILE, admin_data)
            admin_state.clear()
            await update.message.reply_text(f"✅ Лимиты: {min_val} - {max_val} звёзд", reply_markup=kb_admin())
        except:
            await update.message.reply_text("❌ Введите целое число!")
        return True
    
    # Текст продажи
    if action == 'set_sell_text':
        st["sell_text"] = text
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Текст продажи сохранён!", reply_markup=kb_admin())
        return True
    
    # Текст успеха
    if action == 'set_ok_text':
        st["success_text"] = text
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Текст успеха сохранён!", reply_markup=kb_admin())
        return True
    
    # Текст отмены
    if action == 'set_no_text':
        st["cancel_text"] = text
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Текст отмены сохранён!", reply_markup=kb_admin())
        return True
    
    # Удаление фото
    if action in ['set_sell_photo', 'set_ok_photo', 'set_no_photo']:
        if text.lower() in ['нет', 'no', 'удалить', 'delete']:
            key_map = {
                'set_sell_photo': 'sell_photo',
                'set_ok_photo': 'success_photo',
                'set_no_photo': 'cancel_photo'
            }
            st[key_map[action]] = ""
            admin_data["settings"] = st
            save_json(ADMIN_DATA_FILE, admin_data)
            admin_state.clear()
            await update.message.reply_text("✅ Фото удалено!", reply_markup=kb_admin())
            return True
    
    return False

async def handle_admin_photo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Обработка фото от админа"""
    if not is_admin(update.effective_user.id):
        return False
    
    action = admin_state.get('action')
    if action not in ['set_sell_photo', 'set_ok_photo', 'set_no_photo', 'btn_media']:
        return False
    
    if action == 'btn_media':
        await save_btn_media(update, ctx)
        return True
    
    if update.message.photo:
        file_id = update.message.photo[-1].file_id
        st = s()
        key_map = {
            'set_sell_photo': 'sell_photo',
            'set_ok_photo': 'success_photo',
            'set_no_photo': 'cancel_photo'
        }
        st[key_map[action]] = file_id
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Фото сохранено!", reply_markup=kb_admin())
        return True
    
    return False

# ═══════════════════════ ИСТОРИЯ ПРОДАЖ ═══════════════════════

async def handle_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    txs = users_data.get("transactions", [])
    
    if not txs:
        await update.message.reply_text("📈 Транзакций пока нет", reply_markup=kb_admin())
        return
    
    total_stars = sum(t.get("amount", 0) for t in txs)
    total_money = sum(t.get("money", 0) for t in txs)
    
    text = (
        f"📈 <b>История продаж</b>\n\n"
        f"📊 Всего транзакций: {len(txs)}\n"
        f"⭐ Всего звёзд: {total_stars}\n"
        f"💰 К выплате: {total_money}\n\n"
        f"<b>Последние 10:</b>\n"
    )
    
    for tx in txs[-10:][::-1]:
        cur = tx.get("currency", "RUB")
        symbol = CURRENCIES.get(cur, {}).get("symbol", "₽")
        text += f"• @{tx.get('username', '?')} — {tx['amount']}⭐ = {tx['money']} {symbol}\n"
    
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=kb_admin())

# ═══════════════════════ КНОПКИ МЕНЮ ═══════════════════════

async def handle_website(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_sub(uid, ctx):
        await update.message.reply_text("❌ Подпишитесь на канал!", reply_markup=kb_sub())
        return
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text(
        f"🌐 <a href='{WEBSITE_LINK}'>Перейти на сайт</a>",
        parse_mode='HTML', disable_web_page_preview=True, reply_markup=kb
    )

async def handle_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    kb = kb_admin() if is_admin(uid) else kb_main()
    
    await update.message.reply_text(
        f"⭐ <b>ПОМОЩЬ</b>\n\n"
        f"💫 <b>Продать звёзды</b> — продажа Telegram Stars\n"
        f"🌐 <b>Сайт</b> — переход на наш сервис\n"
        f"📝 <b>Написать админу</b> — связь с поддержкой\n\n"
        f"📢 Канал: {CHANNEL_USERNAME}",
        parse_mode='HTML', reply_markup=kb
    )
    
    help_kb = kb_help_buttons()
    if help_kb:
        await update.message.reply_text("📚 Дополнительные материалы:", reply_markup=help_kb)

async def handle_check_sub_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    kb = kb_admin() if is_admin(uid) else kb_main()
    
    if await check_sub(uid, ctx):
        await update.message.reply_text("✅ Вы подписаны на канал!", reply_markup=kb)
    else:
        await update.message.reply_text(f"❌ Подпишитесь: {CHANNEL_USERNAME}", reply_markup=kb_sub())

async def handle_write_admin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_sub(uid, ctx):
        await update.message.reply_text("❌ Подпишитесь на канал!", reply_markup=kb_sub())
        return
    ctx.user_data['state'] = 'msg_admin'
    await update.message.reply_text("✍️ Напишите сообщение администратору:", reply_markup=kb_cancel())

async def handle_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ctx.user_data['state'] = None
    admin_state.clear()
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text("🚫 Действие отменено", reply_markup=kb)

# ═══════════════════════ ДОБАВЛЕНИЕ КНОПОК ═══════════════════════

async def handle_add_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    admin_state['action'] = 'add_btn'
    admin_state['step'] = 1
    await update.message.reply_text(
        "➕ <b>Добавление кнопки</b>\n\nШаг 1/4: Выберите раздел:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📍 Помощь", callback_data="sec_help")]])
    )

async def cb_section(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    admin_state['section'] = q.data.replace("sec_", "")
    admin_state['step'] = 2
    await q.edit_message_text(
        "Шаг 2/4: Выберите тип:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 Ссылка", callback_data="typ_link")],
            [InlineKeyboardButton("📝 Текст", callback_data="typ_text")],
            [InlineKeyboardButton("📸 Фото", callback_data="typ_photo")],
            [InlineKeyboardButton("🎬 Видео", callback_data="typ_video")],
            [InlineKeyboardButton("📄 Документ", callback_data="typ_document")]
        ])
    )

async def cb_type(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    admin_state['type'] = q.data.replace("typ_", "")
    admin_state['step'] = 3
    await q.edit_message_text("Шаг 3/4: Введите название кнопки:")

async def handle_btn_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    if not is_admin(update.effective_user.id) or admin_state.get('action') != 'add_btn':
        return False
    
    step = admin_state.get('step')
    text = update.message.text
    
    if step == 3:
        admin_state['name'] = text
        admin_state['step'] = 4
        
        btn_type = admin_state.get('type')
        if btn_type in ['photo', 'video', 'document']:
            admin_state['action'] = 'btn_media'
            hints = {'photo': 'фото', 'video': 'видео', 'document': 'документ'}
            await update.message.reply_text(f"Шаг 4/4: Отправьте {hints.get(btn_type, 'файл')}:")
        else:
            hints = {'link': 'ссылку (https://...)', 'text': 'текст'}
            await update.message.reply_text(f"Шаг 4/4: Введите {hints.get(btn_type, 'контент')}:")
        return True
    
    elif step == 4 and admin_state.get('type') in ['text', 'link']:
        btn_id = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        buttons_data.setdefault("buttons", {})[btn_id] = {
            "name": admin_state['name'],
            "section": admin_state['section'],
            "type": admin_state['type'],
            "content": text,
            "caption": ""
        }
        save_json(BUTTONS_DATA_FILE, buttons_data)
        admin_state.clear()
        await update.message.reply_text(f"✅ Кнопка создана!\nID: {btn_id}", reply_markup=kb_admin())
        return True
    
    return False

async def save_btn_media(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    file_id = None
    btn_type = admin_state.get('type')
    
    if update.message.photo and btn_type == 'photo':
        file_id = update.message.photo[-1].file_id
    elif update.message.video and btn_type == 'video':
        file_id = update.message.video.file_id
    elif update.message.document and btn_type == 'document':
        file_id = update.message.document.file_id
    
    if file_id:
        btn_id = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        buttons_data.setdefault("buttons", {})[btn_id] = {
            "name": admin_state['name'],
            "section": admin_state['section'],
            "type": admin_state['type'],
            "content": file_id,
            "caption": ""
        }
        save_json(BUTTONS_DATA_FILE, buttons_data)
        admin_state.clear()
        await update.message.reply_text(f"✅ Кнопка создана!\nID: {btn_id}", reply_markup=kb_admin())

async def handle_del_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    btns = buttons_data.get("buttons", {})
    if not btns:
        await update.message.reply_text("📭 Нет кнопок для удаления", reply_markup=kb_admin())
        return
    keyboard = [[InlineKeyboardButton(f"🗑 {b['name']}", callback_data=f"del_{bid}")] for bid, b in btns.items()]
    await update.message.reply_text("Выберите кнопку для удаления:", reply_markup=InlineKeyboardMarkup(keyboard))

async def cb_del_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    btn_id = q.data.replace("del_", "")
    if btn_id in buttons_data.get("buttons", {}):
        name = buttons_data["buttons"][btn_id]["name"]
        del buttons_data["buttons"][btn_id]
        save_json(BUTTONS_DATA_FILE, buttons_data)
        await q.edit_message_text(f"✅ Кнопка «{name}» удалена!")
    else:
        await q.edit_message_text("❌ Кнопка не найдена")

async def handle_list_btns(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    btns = buttons_data.get("buttons", {})
    if not btns:
        await update.message.reply_text("📭 Кнопок пока нет", reply_markup=kb_admin())
        return
    text = "📜 <b>Список кнопок:</b>\n\n"
    for bid, b in btns.items():
        text += f"• {b['name']} ({b['type']})\n  ID: {bid}\n"
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=kb_admin())

async def handle_edit_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text(
        "✏️ Добавляйте материалы через '➕ Добавить кнопку'\n\nОни появятся в разделе Помощь.",
        reply_markup=kb_admin()
    )

# ═══════════════════════ РАССЫЛКА ═══════════════════════

async def handle_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    admin_state['action'] = 'broadcast'
    await update.message.reply_text(
        f"📢 <b>Рассылка</b>\n\nПользователей в базе: {len(users_data['users'])}\n\nОтправьте сообщение для рассылки:",
        parse_mode='HTML', reply_markup=kb_cancel()
    )

async def do_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    if admin_state.get('action') != 'broadcast':
        return False
    admin_state.clear()
    
    success, failed = 0, 0
    status_msg = await update.message.reply_text("📤 Начинаю рассылку...")
    
    for uid in users_data["users"]:
        if uid == ADMIN_ID:
            continue
        try:
            if update.message.photo:
                await ctx.bot.send_photo(uid, update.message.photo[-1].file_id, caption=update.message.caption or "")
            elif update.message.video:
                await ctx.bot.send_video(uid, update.message.video.file_id, caption=update.message.caption or "")
            else:
                await ctx.bot.send_message(uid, update.message.text)
            success += 1
        except:
            failed += 1
    
    await status_msg.edit_text(f"✅ Рассылка завершена!\n\n✉️ Отправлено: {success}\n❌ Ошибок: {failed}")
    return True

# ═══════════════════════ СТАТИСТИКА И ДИАЛОГИ ═══════════════════════

async def handle_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    txs = users_data.get("transactions", [])
    total_stars = sum(t.get("amount", 0) for t in txs)
    total_money = sum(t.get("money", 0) for t in txs)
    
    await update.message.reply_text(
        f"📊 <b>Статистика бота</b>\n\n"
        f"👥 Пользователей: {len(users_data['users'])}\n"
        f"💬 Диалогов: {len(user_dialogs)}\n"
        f"🔘 Кнопок: {len(buttons_data.get('buttons', {}))}\n\n"
        f"💫 <b>Продажи звёзд:</b>\n"
        f"📈 Транзакций: {len(txs)}\n"
        f"⭐ Звёзд получено: {total_stars}\n"
        f"💰 К выплате: {total_money} {sym()}",
        parse_mode='HTML', reply_markup=kb_admin()
    )

async def handle_dialogs(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    if not user_dialogs:
        await update.message.reply_text("📭 Нет активных диалогов", reply_markup=kb_admin())
        return
    
    text = "📋 <b>Активные диалоги:</b>\n\n"
    for uid, msgs in list(user_dialogs.items())[:10]:
        text += f"• ID {uid}: {len(msgs)} сообщений\n"
    
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=kb_admin())

# ═══════════════════════ КАСТОМНЫЕ КНОПКИ ═══════════════════════

async def cb_custom_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    
    btn_id = q.data
    btns = buttons_data.get("buttons", {})
    
    if btn_id not in btns:
        await q.message.reply_text("❌ Кнопка не найдена")
        return
    
    b = btns[btn_id]
    uid = q.from_user.id
    
    try:
        if b['type'] == 'photo':
            await ctx.bot.send_photo(uid, b['content'], caption=b.get('caption') or None, parse_mode='HTML')
        elif b['type'] == 'video':
            await ctx.bot.send_video(uid, b['content'], caption=b.get('caption') or None, parse_mode='HTML')
        elif b['type'] == 'document':
            await ctx.bot.send_document(uid, b['content'], caption=b.get('caption') or None, parse_mode='HTML')
        elif b['type'] == 'text':
            await q.message.reply_text(b['content'], parse_mode='HTML')
    except Exception as e:
        await q.message.reply_text(f"❌ Ошибка: {e}")

async def cb_reply(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    
    if not is_admin(q.from_user.id):
        return
    
    target_id = int(q.data.split("_")[1])
    ctx.user_data['reply_to'] = target_id
    ctx.user_data['state'] = 'admin_reply'
    
    await q.message.reply_text(f"💬 Ответ пользователю ID: {target_id}\n\nВведите сообщение:", reply_markup=kb_admin())

# ═══════════════════════ ОБРАБОТКА ТЕКСТА ═══════════════════════

async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text
    state = ctx.user_data.get('state')
    
    # Админ
    if is_admin(user.id):
        # Настройки
        if await handle_admin_input(update, ctx):
            return
        # Кнопки
        if await handle_btn_input(update, ctx):
            return
        # Рассылка
        if await do_broadcast(update, ctx):
            return
        
        # Ответ пользователю
        if state == 'admin_reply':
            target = ctx.user_data.get('reply_to')
            if target:
                try:
                    await ctx.bot.send_message(
                        target,
                        f"📨 <b>Ответ от администратора:</b>\n\n{text}",
                        parse_mode='HTML', reply_markup=kb_main()
                    )
                    user_dialogs.setdefault(target, []).append({"from": "admin", "text": text, "time": datetime.now().isoformat()})
                    await update.message.reply_text(f"✅ Сообщение отправлено пользователю {target}", reply_markup=kb_admin())
                except Exception as e:
                    await update.message.reply_text(f"❌ Ошибка: {e}", reply_markup=kb_admin())
                ctx.user_data['state'] = None
                ctx.user_data['reply_to'] = None
            return
        
        # Кнопки админа
        handlers = {
            "📋 Диалоги": handle_dialogs,
            "📊 Статистика": handle_stats,
            "➕ Добавить кнопку": handle_add_btn,
            "🗑 Удалить кнопку": handle_del_btn,
            "✏️ Помощь": handle_edit_help,
            "📜 Список кнопок": handle_list_btns,
            "💫 Настройка звёзд": handle_stars_settings,
            "📈 История продаж": handle_history,
            "📢 Рассылка": handle_broadcast,
        }
        
        if text in handlers:
            await handlers[text](update, ctx)
            return
        
        await update.message.reply_text("Используйте кнопки меню 👇", reply_markup=kb_admin())
        return
    
    # Обычный пользователь
    if await process_amount(update, ctx):
        return
    
    # Кнопки меню
    menu_btns = ["🌐 Сайт", "📝 Написать админу", "ℹ️ Помощь", "📢 Проверить подписку", "🚫 Отмена", "💫 Продать звёзды"]
    if text in menu_btns:
        return
    
    # Сообщение админу
    if state == 'msg_admin':
        user_dialogs.setdefault(user.id, []).append({"from": "user", "text": text, "time": datetime.now().isoformat()})
        
        try:
            await ctx.bot.send_message(
                ADMIN_ID,
                f"📩 <b>Новое сообщение</b>\n\n"
                f"👤 {user.full_name}\n"
                f"🔗 @{user.username or 'нет'}\n"
                f"🆔 {user.id}\n\n"
                f"📝 {text}",
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user.id}")]])
            )
            await update.message.reply_text("✅ Сообщение отправлено администратору!", reply_markup=kb_main())
        except Exception as e:
            logger.error(f"Отправка админу: {e}")
            await update.message.reply_text("❌ Ошибка отправки", reply_markup=kb_main())
        
        ctx.user_data['state'] = None
        return
    
    await update.message.reply_text("Используйте кнопки меню 👇", reply_markup=kb_main())

# ═══════════════════════ ОБРАБОТКА МЕДИА ═══════════════════════

async def handle_media(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    action = admin_state.get('action')
    
    if action in ['set_sell_photo', 'set_ok_photo', 'set_no_photo']:
        await handle_admin_photo(update, ctx)
    elif action == 'btn_media':
        await save_btn_media(update, ctx)
    elif action == 'broadcast':
        await do_broadcast(update, ctx)

# ═══════════════════════ MAIN ═══════════════════════

def main():
    print("=" * 60)
    print("⭐ TELEGRAM STARS BOT v3.1 - TERMUX OPTIMIZED")
    print("=" * 60)
    print(f"👑 Admin ID: {ADMIN_ID}")
    print(f"📢 Channel: {CHANNEL_USERNAME}")
    print(f"🌐 Website: {WEBSITE_LINK}")
    print(f"💳 Payment Bot: {PAYMENT_BOT_USERNAME or 'This bot'}")
    print("-" * 60)
    print("📁 Файлы данных:")
    print(f"   Admin: {ADMIN_DATA_FILE}")
    print(f"   Users: {USERS_DATA_FILE}")
    print(f"   Buttons: {BUTTONS_DATA_FILE}")
    print("-" * 60)
    print(f"⏱ Таймауты: connect={CONNECT_TIMEOUT}s, read={READ_TIMEOUT}s")
    print("=" * 60)
    
    # Увеличенные таймауты для Termux
    request = HTTPXRequest(
        connect_timeout=CONNECT_TIMEOUT,
        read_timeout=READ_TIMEOUT,
        write_timeout=WRITE_TIMEOUT,
        pool_timeout=POOL_TIMEOUT
    )
    
    app = Application.builder().token(BOT_TOKEN).request(request).build()
    
    # Команды
    app.add_handler(CommandHandler("start", cmd_start))
    
    # Платежи
    app.add_handler(PreCheckoutQueryHandler(precheckout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, success_payment))
    
    # Callbacks
    app.add_handler(CallbackQueryHandler(cb_check_sub, pattern="^check_sub$"))
    app.add_handler(CallbackQueryHandler(cb_cancel_pay, pattern="^cancel_pay$"))
    app.add_handler(CallbackQueryHandler(cb_stars, pattern="^st_"))
    app.add_handler(CallbackQueryHandler(cb_currency, pattern="^cur_"))
    app.add_handler(CallbackQueryHandler(cb_section, pattern="^sec_"))
    app.add_handler(CallbackQueryHandler(cb_type, pattern="^typ_"))
    app.add_handler(CallbackQueryHandler(cb_del_btn, pattern="^del_"))
    app.add_handler(CallbackQueryHandler(cb_reply, pattern="^reply_"))
    app.add_handler(CallbackQueryHandler(cb_custom_btn, pattern="^btn_"))
    
    # Кнопки меню
    app.add_handler(MessageHandler(filters.Text(["🌐 Сайт"]), handle_website))
    app.add_handler(MessageHandler(filters.Text(["💫 Продать звёзды"]), handle_sell))
    app.add_handler(MessageHandler(filters.Text(["📝 Написать админу"]), handle_write_admin))
    app.add_handler(MessageHandler(filters.Text(["ℹ️ Помощь"]), handle_help))
    app.add_handler(MessageHandler(filters.Text(["📢 Проверить подписку"]), handle_check_sub_btn))
    app.add_handler(MessageHandler(filters.Text(["🚫 Отмена"]), handle_cancel))
    
    # Медиа
    app.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO | filters.Document.ALL, handle_media))
    
    # Текст
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    
    print("🚀 Бот запущен!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
# -*- coding: utf-8 -*-
"""
⭐ TELEGRAM STARS BOT v3.1 - TERMUX OPTIMIZED
Бот для продажи Telegram Stars
Оптимизирован для Termux с увеличенными таймаутами
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, LabeledPrice
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, PreCheckoutQueryHandler, ContextTypes, filters
from telegram.request import HTTPXRequest

# ╔══════════════════════════════════════════════════════════════════════════════════╗
# ║                           🔧 ВСЕ НАСТРОЙКИ ЗДЕСЬ 🔧                              ║
# ╚══════════════════════════════════════════════════════════════════════════════════╝

# === ОСНОВНЫЕ НАСТРОЙКИ ===
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"           # 🔑 Токен от @BotFather
CHANNEL_USERNAME = "@YourChannel"            # 📢 Канал для подписки
ADMIN_ID = 123456789                         # 👑 Ваш Telegram ID
WEBSITE_LINK = "https://t.me/YourBot/web"   # 🌐 Ссылка на сайт

# === БОТ ДЛЯ ПЛАТЕЖЕЙ ===
PAYMENT_BOT_USERNAME = ""                    # 💳 Оставьте пустым для этого бота

# === ПУТИ К ФАЙЛАМ (3 отдельных файла) ===
ADMIN_DATA_FILE = "data/admin_settings.json"
USERS_DATA_FILE = "data/users_data.json"
BUTTONS_DATA_FILE = "data/buttons_data.json"

# === ТАЙМАУТЫ ДЛЯ TERMUX (увеличенные) ===
CONNECT_TIMEOUT = 30.0
READ_TIMEOUT = 30.0
WRITE_TIMEOUT = 30.0
POOL_TIMEOUT = 10.0

# === ВАЛЮТЫ ===
CURRENCIES = {
    "RUB": {"symbol": "₽", "name": "Рубль"},
    "USD": {"symbol": "$", "name": "Доллар"},
    "EUR": {"symbol": "€", "name": "Евро"},
    "UAH": {"symbol": "₴", "name": "Гривна"},
    "KZT": {"symbol": "₸", "name": "Тенге"},
    "UZS": {"symbol": "сум", "name": "Сум"},
    "BYN": {"symbol": "Br", "name": "Бел.рубль"},
    "TRY": {"symbol": "₺", "name": "Лира"},
    "GEL": {"symbol": "₾", "name": "Лари"},
    "AMD": {"symbol": "֏", "name": "Драм"},
    "AZN": {"symbol": "₼", "name": "Манат"},
    "USDT": {"symbol": "USDT", "name": "Tether"},
    "TON": {"symbol": "TON", "name": "Toncoin"},
}

# === НАСТРОЙКИ ПО УМОЛЧАНИЮ ===
DEFAULT_SETTINGS = {
    "enabled": True,
    "currency": "RUB",
    "rate": 1.5,
    "min_stars": 10,
    "max_stars": 10000,
    "sell_text": "⭐ <b>Продажа Stars</b>\n\nВы продаёте: <b>{amount} ⭐</b>\n💰 Получите: <b>{money} {symbol}</b>\n\n👇 Нажмите кнопку:",
    "sell_photo": "",
    "success_text": "✅ <b>Оплата получена!</b>\n\n⭐ Звёзд: <b>{amount}</b>\n💰 К выплате: <b>{money} {symbol}</b>\n\nАдмин свяжется с вами!",
    "success_photo": "",
    "cancel_text": "❌ <b>Отменено</b>\n\nВы отменили продажу.",
    "cancel_photo": "",
}

# ╚══════════════════════════════════════════════════════════════════════════════════╝

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Глобальные данные
admin_data: Dict[str, Any] = {}
users_data: Dict[str, Any] = {}
buttons_data: Dict[str, Any] = {}
admin_state: Dict[str, Any] = {}
user_dialogs: Dict[int, list] = {}

# ==================== РАБОТА С ФАЙЛАМИ ====================

def ensure_dir():
    for path in [ADMIN_DATA_FILE, USERS_DATA_FILE, BUTTONS_DATA_FILE]:
        d = os.path.dirname(path)
        if d and not os.path.exists(d):
            os.makedirs(d, exist_ok=True)

def load_json(path: str, default: dict) -> dict:
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if content:
                    return json.loads(content)
    except Exception as e:
        logger.warning(f"Не удалось загрузить {path}: {e}")
    return default.copy()

def save_json(path: str, data: dict):
    try:
        ensure_dir()
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Ошибка сохранения {path}: {e}")

def init_data():
    global admin_data, users_data, buttons_data
    ensure_dir()
    admin_data = load_json(ADMIN_DATA_FILE, {"settings": DEFAULT_SETTINGS.copy()})
    if "settings" not in admin_data:
        admin_data["settings"] = DEFAULT_SETTINGS.copy()
    for k, v in DEFAULT_SETTINGS.items():
        if k not in admin_data["settings"]:
            admin_data["settings"][k] = v
    users_data = load_json(USERS_DATA_FILE, {"users": [], "transactions": []})
    buttons_data = load_json(BUTTONS_DATA_FILE, {"buttons": {}})

init_data()

def s() -> dict:
    return admin_data.get("settings", DEFAULT_SETTINGS)

def sym() -> str:
    return CURRENCIES.get(s().get("currency", "RUB"), {}).get("symbol", "₽")

def is_admin(uid: int) -> bool:
    return str(uid) == str(ADMIN_ID)

def fmt(t: str, amt: int, money: float) -> str:
    return t.replace("{amount}", str(amt)).replace("{money}", str(money)).replace("{symbol}", sym())

# ==================== КЛАВИАТУРЫ ====================

def kb_main():
    return ReplyKeyboardMarkup([
        [KeyboardButton("🌐 Сайт"), KeyboardButton("💫 Продать звёзды")],
        [KeyboardButton("📝 Написать админу"), KeyboardButton("ℹ️ Помощь")],
        [KeyboardButton("📢 Проверить подписку")]
    ], resize_keyboard=True)

def kb_admin():
    return ReplyKeyboardMarkup([
        [KeyboardButton("📋 Диалоги"), KeyboardButton("📊 Статистика")],
        [KeyboardButton("➕ Добавить кнопку"), KeyboardButton("🗑 Удалить кнопку")],
        [KeyboardButton("✏️ Помощь"), KeyboardButton("📜 Список кнопок")],
        [KeyboardButton("💫 Настройка звёзд"), KeyboardButton("📈 История продаж")],
        [KeyboardButton("📢 Рассылка"), KeyboardButton("🚫 Отмена")]
    ], resize_keyboard=True)

def kb_cancel():
    return ReplyKeyboardMarkup([[KeyboardButton("🚫 Отмена")]], resize_keyboard=True)

def kb_sub():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Подписаться", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton("✅ Проверить", callback_data="check_sub")]
    ])

def kb_stars_menu():
    st = s()
    status = "✅ ВКЛ" if st.get("enabled") else "❌ ВЫКЛ"
    cur = st.get("currency", "RUB")
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Статус: {status}", callback_data="st_toggle")],
        [InlineKeyboardButton(f"💱 Валюта: {cur} ({sym()})", callback_data="st_currency")],
        [InlineKeyboardButton(f"💰 Курс: {st['rate']} {sym()}", callback_data="st_rate")],
        [InlineKeyboardButton(f"📊 Лимиты: {st['min_stars']}-{st['max_stars']}", callback_data="st_limits")],
        [InlineKeyboardButton("📝 Текст продажи", callback_data="st_sell_text")],
        [InlineKeyboardButton("🖼 Фото продажи", callback_data="st_sell_photo")],
        [InlineKeyboardButton("✅ Текст успеха", callback_data="st_ok_text")],
        [InlineKeyboardButton("🖼 Фото успеха", callback_data="st_ok_photo")],
        [InlineKeyboardButton("❌ Текст отмены", callback_data="st_no_text")],
        [InlineKeyboardButton("🖼 Фото отмены", callback_data="st_no_photo")],
        [InlineKeyboardButton("🔙 Закрыть", callback_data="st_close")]
    ])

def kb_currencies():
    rows = []
    row = []
    for code, info in CURRENCIES.items():
        row.append(InlineKeyboardButton(f"{info['symbol']} {code}", callback_data=f"cur_{code}"))
        if len(row) == 3:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("🔙 Назад", callback_data="st_back")])
    return InlineKeyboardMarkup(rows)

def kb_help_buttons():
    btns = []
    for bid, b in buttons_data.get("buttons", {}).items():
        if b.get("section") == "help":
            if b.get("type") == "link":
                btns.append([InlineKeyboardButton(b["name"], url=b["content"])])
            else:
                btns.append([InlineKeyboardButton(b["name"], callback_data=bid)])
    return InlineKeyboardMarkup(btns) if btns else None

# ==================== ПРОВЕРКА ПОДПИСКИ ====================

async def check_sub(uid: int, ctx) -> bool:
    try:
        m = await ctx.bot.get_chat_member(CHANNEL_USERNAME, uid)
        return m.status in ['member', 'administrator', 'creator']
    except:
        return False

# ==================== КОМАНДЫ ====================

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in users_data["users"]:
        users_data["users"].append(uid)
        save_json(USERS_DATA_FILE, users_data)
    
    if not await check_sub(uid, ctx):
        await update.message.reply_text(f"📢 Подпишитесь на {CHANNEL_USERNAME}", reply_markup=kb_sub())
        return
    
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text(
        f"👋 <b>Добро пожаловать!</b>\n\n🌐 <a href='{WEBSITE_LINK}'>Сайт</a>\n💫 Продавайте Stars выгодно!",
        parse_mode='HTML', disable_web_page_preview=True, reply_markup=kb
    )

async def cb_check_sub(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    
    if await check_sub(uid, ctx):
        kb = kb_admin() if is_admin(uid) else kb_main()
        await q.edit_message_text("✅ Подписка подтверждена!")
        await ctx.bot.send_message(uid, "Выберите:", reply_markup=kb)
    else:
        await q.edit_message_text(f"❌ Подпишитесь: {CHANNEL_USERNAME}", reply_markup=kb_sub())

# ==================== ПРОДАЖА ЗВЁЗД ====================

async def handle_sell(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_sub(uid, ctx):
        await update.message.reply_text("❌ Подпишитесь!", reply_markup=kb_sub())
        return
    
    st = s()
    if not st.get("enabled"):
        kb = kb_admin() if is_admin(uid) else kb_main()
        await update.message.reply_text("⚠️ Продажа временно недоступна", reply_markup=kb)
        return
    
    ctx.user_data['state'] = 'stars_amount'
    await update.message.reply_text(
        f"💫 <b>Продажа Stars</b>\n\n💰 Курс: 1⭐ = {st['rate']} {sym()}\n📊 От {st['min_stars']} до {st['max_stars']}\n\nВведите количество:",
        parse_mode='HTML', reply_markup=kb_cancel()
    )

async def process_amount(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    if ctx.user_data.get('state') != 'stars_amount':
        return False
    
    uid = update.effective_user.id
    ctx.user_data['state'] = None
    kb = kb_admin() if is_admin(uid) else kb_main()
    
    try:
        amt = int(update.message.text)
    except:
        await update.message.reply_text("❌ Введите число!", reply_markup=kb)
        return True
    
    st = s()
    if amt < st['min_stars']:
        await update.message.reply_text(f"❌ Минимум {st['min_stars']}", reply_markup=kb)
        return True
    if amt > st['max_stars']:
        await update.message.reply_text(f"❌ Максимум {st['max_stars']}", reply_markup=kb)
        return True
    
    money = round(amt * st['rate'], 2)
    txt = fmt(st['sell_text'], amt, money)
    photo = st.get('sell_photo')
    
    try:
        if photo:
            await ctx.bot.send_photo(uid, photo, caption=txt, parse_mode='HTML')
        
        await ctx.bot.send_invoice(
            chat_id=uid,
            title="Продажа Stars",
            description=f"Отправка {amt} звёзд",
            payload=f"sell_{uid}_{amt}_{money}",
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice("Stars", amt)],
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"⭐ Отправить {amt} звёзд", pay=True)],
                [InlineKeyboardButton("❌ Отмена", callback_data="cancel_pay")]
            ])
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}", reply_markup=kb)
    
    return True

async def cb_cancel_pay(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    
    st = s()
    kb = kb_admin() if is_admin(uid) else kb_main()
    
    try:
        await q.message.delete()
    except:
        pass
    
    photo = st.get('cancel_photo')
    txt = st.get('cancel_text', '❌ Отменено')
    
    if photo:
        await ctx.bot.send_photo(uid, photo, caption=txt, parse_mode='HTML', reply_markup=kb)
    else:
        await ctx.bot.send_message(uid, txt, parse_mode='HTML', reply_markup=kb)

async def precheckout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.pre_checkout_query
    if q.invoice_payload.startswith("sell_"):
        await q.answer(ok=True)
    else:
        await q.answer(ok=False, error_message="Ошибка")

async def success_payment(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    pay = update.message.successful_payment
    parts = pay.invoice_payload.split("_")
    amt = int(parts[2])
    money = float(parts[3])
    
    st = s()
    tx = {
        "user_id": user.id,
        "username": user.username,
        "name": user.full_name,
        "amount": amt,
        "money": money,
        "currency": st.get("currency", "RUB"),
        "time": datetime.now().isoformat(),
        "pay_id": pay.telegram_payment_charge_id
    }
    users_data["transactions"].append(tx)
    save_json(USERS_DATA_FILE, users_data)
    
    kb = kb_admin() if is_admin(user.id) else kb_main()
    txt = fmt(st['success_text'], amt, money)
    photo = st.get('success_photo')
    
    if photo:
        await ctx.bot.send_photo(user.id, photo, caption=txt, parse_mode='HTML', reply_markup=kb)
    else:
        await update.message.reply_text(txt, parse_mode='HTML', reply_markup=kb)
    
    # Уведомление админу
    try:
        await ctx.bot.send_message(
            ADMIN_ID,
            f"💫 <b>ПРОДАЖА!</b>\n\n👤 {user.full_name} (@{user.username or 'нет'})\n🆔 {user.id}\n\n⭐ {amt} звёзд\n💰 {money} {sym()}\n\n🔑 {pay.telegram_payment_charge_id}",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user.id}")]])
        )
    except:
        pass

# ==================== НАСТРОЙКИ ЗВЁЗД ====================

async def handle_stars_settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    st = s()
    await update.message.reply_text(
        f"💫 <b>Настройки звёзд</b>\n\nСтатус: {'✅ ВКЛ' if st['enabled'] else '❌ ВЫКЛ'}\nВалюта: {st['currency']} ({sym()})\nКурс: 1⭐ = {st['rate']} {sym()}\nЛимиты: {st['min_stars']}-{st['max_stars']}",
        parse_mode='HTML', reply_markup=kb_stars_menu()
    )

async def cb_stars(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    
    d = q.data
    st = s()
    
    if d == "st_toggle":
        st["enabled"] = not st.get("enabled", True)
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        await q.edit_message_text(f"Статус: {'✅ ВКЛ' if st['enabled'] else '❌ ВЫКЛ'}", reply_markup=kb_stars_menu())
    
    elif d == "st_currency":
        await q.edit_message_text(f"💱 Выберите валюту\nТекущая: {st['currency']} ({sym()})", reply_markup=kb_currencies())
    
    elif d == "st_rate":
        admin_state['action'] = 'rate'
        await q.edit_message_text(f"💰 Текущий курс: 1⭐ = {st['rate']} {sym()}\n\nВведите новый:")
    
    elif d == "st_limits":
        admin_state['action'] = 'limit_min'
        await q.edit_message_text(f"📊 Текущие: {st['min_stars']}-{st['max_stars']}\n\nВведите минимум:")
    
    elif d == "st_sell_text":
        admin_state['action'] = 'sell_text'
        await q.edit_message_text("📝 Введите текст продажи\n\nПеременные: {amount}, {money}, {symbol}")
    
    elif d == "st_sell_photo":
        admin_state['action'] = 'sell_photo'
        await q.edit_message_text("🖼 Отправьте фото или напишите 'нет' для удаления")
    
    elif d == "st_ok_text":
        admin_state['action'] = 'ok_text'
        await q.edit_message_text("✅ Введите текст успеха\n\nПеременные: {amount}, {money}, {symbol}")
    
    elif d == "st_ok_photo":
        admin_state['action'] = 'ok_photo'
        await q.edit_message_text("🖼 Отправьте фото успеха или 'нет'")
    
    elif d == "st_no_text":
        admin_state['action'] = 'no_text'
        await q.edit_message_text("❌ Введите текст отмены:")
    
    elif d == "st_no_photo":
        admin_state['action'] = 'no_photo'
        await q.edit_message_text("🖼 Отправьте фото отмены или 'нет'")
    
    elif d == "st_close":
        admin_state.clear()
        await q.message.delete()
        await ctx.bot.send_message(q.from_user.id, "✅ Закрыто", reply_markup=kb_admin())
    
    elif d == "st_back":
        await q.edit_message_text("💫 Настройки:", reply_markup=kb_stars_menu())

async def cb_currency(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    
    cur = q.data.replace("cur_", "")
    if cur in CURRENCIES:
        st = s()
        st["currency"] = cur
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        await q.edit_message_text(f"✅ Валюта: {cur} ({CURRENCIES[cur]['symbol']})", reply_markup=kb_stars_menu())

async def handle_admin_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    if not is_admin(update.effective_user.id):
        return False
    
    act = admin_state.get('action')
    if not act:
        return False
    
    txt = update.message.text
    st = s()
    
    if act == 'rate':
        try:
            st['rate'] = float(txt.replace(',', '.'))
            admin_data["settings"] = st
            save_json(ADMIN_DATA_FILE, admin_data)
            admin_state.clear()
            await update.message.reply_text(f"✅ Курс: 1⭐ = {st['rate']} {sym()}", reply_markup=kb_admin())
        except:
            await update.message.reply_text("❌ Введите число!")
        return True
    
    elif act == 'limit_min':
        try:
            admin_state['min'] = int(txt)
            admin_state['action'] = 'limit_max'
            await update.message.reply_text("Теперь максимум:")
        except:
            await update.message.reply_text("❌ Число!")
        return True
    
    elif act == 'limit_max':
        try:
            st['min_stars'] = admin_state['min']
            st['max_stars'] = int(txt)
            admin_data["settings"] = st
            save_json(ADMIN_DATA_FILE, admin_data)
            admin_state.clear()
            await update.message.reply_text(f"✅ Лимиты: {st['min_stars']}-{st['max_stars']}", reply_markup=kb_admin())
        except:
            await update.message.reply_text("❌ Число!")
        return True
    
    elif act == 'sell_text':
        st['sell_text'] = txt
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Текст сохранён!", reply_markup=kb_admin())
        return True
    
    elif act == 'ok_text':
        st['success_text'] = txt
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Сохранено!", reply_markup=kb_admin())
        return True
    
    elif act == 'no_text':
        st['cancel_text'] = txt
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Сохранено!", reply_markup=kb_admin())
        return True
    
    elif act in ['sell_photo', 'ok_photo', 'no_photo']:
        if txt.lower() == 'нет':
            key = {'sell_photo': 'sell_photo', 'ok_photo': 'success_photo', 'no_photo': 'cancel_photo'}[act]
            st[key] = ""
            admin_data["settings"] = st
            save_json(ADMIN_DATA_FILE, admin_data)
            admin_state.clear()
            await update.message.reply_text("✅ Фото удалено!", reply_markup=kb_admin())
            return True
    
    return False

async def handle_admin_photo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    act = admin_state.get('action')
    if act not in ['sell_photo', 'ok_photo', 'no_photo', 'btn_media']:
        return
    
    if act == 'btn_media':
        await save_btn_media(update, ctx)
        return
    
    if update.message.photo:
        fid = update.message.photo[-1].file_id
        st = s()
        key = {'sell_photo': 'sell_photo', 'ok_photo': 'success_photo', 'no_photo': 'cancel_photo'}[act]
        st[key] = fid
        admin_data["settings"] = st
        save_json(ADMIN_DATA_FILE, admin_data)
        admin_state.clear()
        await update.message.reply_text("✅ Фото сохранено!", reply_markup=kb_admin())

# ==================== ИСТОРИЯ ПРОДАЖ ====================

async def handle_history(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    
    txs = users_data.get("transactions", [])
    if not txs:
        await update.message.reply_text("📈 Нет транзакций", reply_markup=kb_admin())
        return
    
    total = sum(t.get("amount", 0) for t in txs)
    money = sum(t.get("money", 0) for t in txs)
    
    txt = f"📈 <b>История</b>\n\n📊 Всего: {len(txs)}\n⭐ Звёзд: {total}\n💰 К выплате: {money}\n\n<b>Последние:</b>\n"
    for t in txs[-10:][::-1]:
        txt += f"• @{t.get('username', '?')} — {t['amount']}⭐ = {t['money']} {CURRENCIES.get(t.get('currency', 'RUB'), {}).get('symbol', '₽')}\n"
    
    await update.message.reply_text(txt, parse_mode='HTML', reply_markup=kb_admin())

# ==================== ОСТАЛЬНЫЕ ФУНКЦИИ ====================

async def handle_site(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_sub(uid, ctx):
        await update.message.reply_text("❌ Подпишитесь!", reply_markup=kb_sub())
        return
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text(f"🌐 <a href='{WEBSITE_LINK}'>Сайт</a>", parse_mode='HTML', disable_web_page_preview=True, reply_markup=kb)

async def handle_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text(
        f"⭐ <b>ПОМОЩЬ</b>\n\n💫 Продать звёзды — продажа Stars\n🌐 Сайт — переход на сервис\n📝 Написать админу — поддержка\n\n📢 Канал: {CHANNEL_USERNAME}",
        parse_mode='HTML', reply_markup=kb
    )
    hk = kb_help_buttons()
    if hk:
        await update.message.reply_text("📚 Материалы:", reply_markup=hk)

async def handle_check_sub_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    kb = kb_admin() if is_admin(uid) else kb_main()
    if await check_sub(uid, ctx):
        await update.message.reply_text("✅ Подписаны!", reply_markup=kb)
    else:
        await update.message.reply_text(f"❌ Подпишитесь: {CHANNEL_USERNAME}", reply_markup=kb_sub())

async def handle_write_admin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_sub(uid, ctx):
        await update.message.reply_text("❌ Подпишитесь!", reply_markup=kb_sub())
        return
    ctx.user_data['state'] = 'msg_admin'
    await update.message.reply_text("✍️ Напишите сообщение:", reply_markup=kb_cancel())

async def handle_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ctx.user_data['state'] = None
    admin_state.clear()
    kb = kb_admin() if is_admin(uid) else kb_main()
    await update.message.reply_text("🚫 Отменено", reply_markup=kb)

# ==================== КНОПКИ ====================

async def handle_add_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    admin_state['action'] = 'add_btn'
    admin_state['step'] = 1
    await update.message.reply_text(
        "➕ <b>Добавление</b>\n\nШаг 1: Выберите раздел:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📍 Помощь", callback_data="sec_help")]])
    )

async def cb_section(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    admin_state['section'] = q.data.replace("sec_", "")
    admin_state['step'] = 2
    await q.edit_message_text("Шаг 2: Тип:", reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("🔗 Ссылка", callback_data="typ_link")],
        [InlineKeyboardButton("📝 Текст", callback_data="typ_text")],
        [InlineKeyboardButton("📸 Фото", callback_data="typ_photo")],
        [InlineKeyboardButton("🎬 Видео", callback_data="typ_video")],
        [InlineKeyboardButton("📄 Документ", callback_data="typ_document")]
    ]))

async def cb_type(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    admin_state['type'] = q.data.replace("typ_", "")
    admin_state['step'] = 3
    await q.edit_message_text("Шаг 3: Название кнопки:")

async def handle_btn_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    if not is_admin(update.effective_user.id) or admin_state.get('action') != 'add_btn':
        return False
    
    step = admin_state.get('step')
    txt = update.message.text
    
    if step == 3:
        admin_state['name'] = txt
        admin_state['step'] = 4
        if admin_state['type'] in ['photo', 'video', 'document']:
            admin_state['action'] = 'btn_media'
        await update.message.reply_text("Шаг 4: Контент:")
        return True
    
    elif step == 4 and admin_state['type'] in ['text', 'link']:
        bid = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        buttons_data.setdefault("buttons", {})[bid] = {
            "name": admin_state['name'],
            "section": admin_state['section'],
            "type": admin_state['type'],
            "content": txt,
            "caption": ""
        }
        save_json(BUTTONS_DATA_FILE, buttons_data)
        admin_state.clear()
        await update.message.reply_text(f"✅ Создано! ID: {bid}", reply_markup=kb_admin())
        return True
    
    return False

async def save_btn_media(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    fid = None
    t = admin_state.get('type')
    if update.message.photo and t == 'photo':
        fid = update.message.photo[-1].file_id
    elif update.message.video and t == 'video':
        fid = update.message.video.file_id
    elif update.message.document and t == 'document':
        fid = update.message.document.file_id
    
    if fid:
        bid = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        buttons_data.setdefault("buttons", {})[bid] = {
            "name": admin_state['name'],
            "section": admin_state['section'],
            "type": admin_state['type'],
            "content": fid,
            "caption": ""
        }
        save_json(BUTTONS_DATA_FILE, buttons_data)
        admin_state.clear()
        await update.message.reply_text(f"✅ Создано! ID: {bid}", reply_markup=kb_admin())

async def handle_del_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    btns = buttons_data.get("buttons", {})
    if not btns:
        await update.message.reply_text("📭 Нет кнопок", reply_markup=kb_admin())
        return
    kb = [[InlineKeyboardButton(f"🗑 {b['name']}", callback_data=f"del_{bid}")] for bid, b in btns.items()]
    await update.message.reply_text("Удалить:", reply_markup=InlineKeyboardMarkup(kb))

async def cb_del_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    bid = q.data.replace("del_", "")
    if bid in buttons_data.get("buttons", {}):
        n = buttons_data["buttons"][bid]["name"]
        del buttons_data["buttons"][bid]
        save_json(BUTTONS_DATA_FILE, buttons_data)
        await q.edit_message_text(f"✅ «{n}» удалена!")
    else:
        await q.edit_message_text("❌ Не найдена")

async def handle_list_btns(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    btns = buttons_data.get("buttons", {})
    if not btns:
        await update.message.reply_text("📭 Нет кнопок", reply_markup=kb_admin())
        return
    txt = "📜 <b>Кнопки:</b>\n\n"
    for bid, b in btns.items():
        txt += f"• {b['name']} ({b['type']}) — {bid}\n"
    await update.message.reply_text(txt, parse_mode='HTML', reply_markup=kb_admin())

async def handle_edit_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.message.reply_text("✏️ Добавляйте материалы через '➕ Добавить кнопку'", reply_markup=kb_admin())

# ==================== РАССЫЛКА ====================

async def handle_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    admin_state['action'] = 'broadcast'
    await update.message.reply_text(f"📢 Пользователей: {len(users_data['users'])}\n\nОтправьте сообщение:", reply_markup=kb_cancel())

async def do_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    if admin_state.get('action') != 'broadcast':
        return False
    admin_state.clear()
    ok, fail = 0, 0
    for uid in users_data["users"]:
        if uid == ADMIN_ID:
            continue
        try:
            if update.message.photo:
                await ctx.bot.send_photo(uid, update.message.photo[-1].file_id, caption=update.message.caption or "")
            elif update.message.video:
                await ctx.bot.send_video(uid, update.message.video.file_id, caption=update.message.caption or "")
            else:
                await ctx.bot.send_message(uid, update.message.text)
            ok += 1
        except:
            fail += 1
    await update.message.reply_text(f"✅ Отправлено: {ok}\n❌ Ошибок: {fail}", reply_markup=kb_admin())
    return True

# ==================== СТАТИСТИКА ====================

async def handle_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    txs = users_data.get("transactions", [])
    await update.message.reply_text(
        f"📊 <b>Статистика</b>\n\n👥 Пользователей: {len(users_data['users'])}\n💬 Диалогов: {len(user_dialogs)}\n🔘 Кнопок: {len(buttons_data.get('buttons', {}))}\n\n📈 Транзакций: {len(txs)}\n⭐ Звёзд: {sum(t.get('amount', 0) for t in txs)}\n💰 К выплате: {sum(t.get('money', 0) for t in txs)}",
        parse_mode='HTML', reply_markup=kb_admin()
    )

async def handle_dialogs(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not user_dialogs:
        await update.message.reply_text("📭 Нет диалогов", reply_markup=kb_admin())
        return
    txt = "📋 <b>Диалоги:</b>\n\n"
    for uid, msgs in list(user_dialogs.items())[:10]:
        txt += f"• ID {uid}: {len(msgs)} сообщений\n"
    await update.message.reply_text(txt, parse_mode='HTML', reply_markup=kb_admin())

# ==================== CALLBACKS ====================

async def cb_custom_btn(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    bid = q.data
    btns = buttons_data.get("buttons", {})
    if bid not in btns:
        await q.message.reply_text("❌ Не найдено")
        return
    b = btns[bid]
    try:
        if b['type'] == 'photo':
            await ctx.bot.send_photo(q.from_user.id, b['content'], caption=b.get('caption') or None, parse_mode='HTML')
        elif b['type'] == 'video':
            await ctx.bot.send_video(q.from_user.id, b['content'], caption=b.get('caption') or None, parse_mode='HTML')
        elif b['type'] == 'document':
            await ctx.bot.send_document(q.from_user.id, b['content'], caption=b.get('caption') or None, parse_mode='HTML')
        elif b['type'] == 'text':
            await q.message.reply_text(b['content'], parse_mode='HTML')
    except Exception as e:
        await q.message.reply_text(f"❌ Ошибка: {e}")

async def cb_reply(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    target = int(q.data.split("_")[1])
    ctx.user_data['reply_to'] = target
    ctx.user_data['state'] = 'admin_reply'
    await q.message.reply_text(f"💬 Ответ пользователю {target}:", reply_markup=kb_admin())

# ==================== ТЕКСТ ====================

async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    txt = update.message.text
    state = ctx.user_data.get('state')
    
    # Админ
    if is_admin(user.id):
        if await handle_admin_input(update, ctx):
            return
        if await handle_btn_input(update, ctx):
            return
        if await do_broadcast(update, ctx):
            return
        
        if state == 'admin_reply':
            target = ctx.user_data.get('reply_to')
            if target:
                try:
                    await ctx.bot.send_message(target, f"📨 <b>Ответ админа:</b>\n\n{txt}", parse_mode='HTML', reply_markup=kb_main())
                    user_dialogs.setdefault(target, []).append({"from": "admin", "text": txt})
                    await update.message.reply_text(f"✅ Отправлено {target}", reply_markup=kb_admin())
                except Exception as e:
                    await update.message.reply_text(f"❌ {e}", reply_markup=kb_admin())
                ctx.user_data['state'] = None
            return
        
        handlers = {
            "📋 Диалоги": handle_dialogs,
            "📊 Статистика": handle_stats,
            "➕ Добавить кнопку": handle_add_btn,
            "🗑 Удалить кнопку": handle_del_btn,
            "✏️ Помощь": handle_edit_help,
            "📜 Список кнопок": handle_list_btns,
            "💫 Настройка звёзд": handle_stars_settings,
            "📈 История продаж": handle_history,
            "📢 Рассылка": handle_broadcast,
        }
        if txt in handlers:
            await handlers[txt](update, ctx)
            return
        
        await update.message.reply_text("👇", reply_markup=kb_admin())
        return
    
    # Пользователь
    if await process_amount(update, ctx):
        return
    
    menu = ["🌐 Сайт", "📝 Написать админу", "ℹ️ Помощь", "📢 Проверить подписку", "🚫 Отмена", "💫 Продать звёзды"]
    if txt in menu:
        return
    
    if state == 'msg_admin':
        user_dialogs.setdefault(user.id, []).append({"from": "user", "text": txt})
        try:
            await ctx.bot.send_message(
                ADMIN_ID,
                f"📩 <b>Сообщение</b>\n\n👤 {user.full_name}\n🔗 @{user.username or 'нет'}\n🆔 {user.id}\n\n📝 {txt}",
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user.id}")]])
            )
            await update.message.reply_text("✅ Отправлено!", reply_markup=kb_main())
        except:
            await update.message.reply_text("❌ Ошибка", reply_markup=kb_main())
        ctx.user_data['state'] = None
        return
    
    await update.message.reply_text("👇", reply_markup=kb_main())

# ==================== МЕДИА ====================

async def handle_media(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    act = admin_state.get('action')
    if act in ['sell_photo', 'ok_photo', 'no_photo']:
        await handle_admin_photo(update, ctx)
    elif act == 'btn_media':
        await save_btn_media(update, ctx)
    elif act == 'broadcast':
        await do_broadcast(update, ctx)

# ==================== MAIN ====================

def main():
    print("=" * 60)
    print("⭐ TELEGRAM STARS BOT v3.1 - TERMUX OPTIMIZED")
    print("=" * 60)
    print(f"👑 Admin: {ADMIN_ID}")
    print(f"📢 Channel: {CHANNEL_USERNAME}")
    print(f"🌐 Site: {WEBSITE_LINK}")
    print(f"💳 Payment: {PAYMENT_BOT_USERNAME or 'This bot'}")
    print("-" * 60)
    print(f"📁 Admin: {ADMIN_DATA_FILE}")
    print(f"📁 Users: {USERS_DATA_FILE}")
    print(f"📁 Buttons: {BUTTONS_DATA_FILE}")
    print("-" * 60)
    print(f"⏱ Timeouts: connect={CONNECT_TIMEOUT}s, read={READ_TIMEOUT}s")
    print("=" * 60)
    
    # Увеличенные таймауты для Termux
    request = HTTPXRequest(
        connect_timeout=CONNECT_TIMEOUT,
        read_timeout=READ_TIMEOUT,
        write_timeout=WRITE_TIMEOUT,
        pool_timeout=POOL_TIMEOUT
    )
    
    app = Application.builder().token(BOT_TOKEN).request(request).build()
    
    # Команды
    app.add_handler(CommandHandler("start", cmd_start))
    
    # Платежи
    app.add_handler(PreCheckoutQueryHandler(precheckout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, success_payment))
    
    # Callbacks
    app.add_handler(CallbackQueryHandler(cb_check_sub, pattern="^check_sub$"))
    app.add_handler(CallbackQueryHandler(cb_cancel_pay, pattern="^cancel_pay$"))
    app.add_handler(CallbackQueryHandler(cb_stars, pattern="^st_"))
    app.add_handler(CallbackQueryHandler(cb_currency, pattern="^cur_"))
    app.add_handler(CallbackQueryHandler(cb_section, pattern="^sec_"))
    app.add_handler(CallbackQueryHandler(cb_type, pattern="^typ_"))
    app.add_handler(CallbackQueryHandler(cb_del_btn, pattern="^del_"))
    app.add_handler(CallbackQueryHandler(cb_reply, pattern="^reply_"))
    app.add_handler(CallbackQueryHandler(cb_custom_btn, pattern="^btn_"))
    
    # Кнопки меню
    app.add_handler(MessageHandler(filters.Text(["🌐 Сайт"]), handle_site))
    app.add_handler(MessageHandler(filters.Text(["💫 Продать звёзды"]), handle_sell))
    app.add_handler(MessageHandler(filters.Text(["📝 Написать админу"]), handle_write_admin))
    app.add_handler(MessageHandler(filters.Text(["ℹ️ Помощь"]), handle_help))
    app.add_handler(MessageHandler(filters.Text(["📢 Проверить подписку"]), handle_check_sub_btn))
    app.add_handler(MessageHandler(filters.Text(["🚫 Отмена"]), handle_cancel))
    
    # Медиа
    app.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO | filters.Document.ALL, handle_media))
    
    # Текст
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    
    print("🚀 Бот запущен!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
