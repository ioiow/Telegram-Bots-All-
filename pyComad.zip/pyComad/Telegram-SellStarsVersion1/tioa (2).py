import os
import json
import logging
from datetime import datetime
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton, LabeledPrice
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    PreCheckoutQueryHandler,
    ContextTypes,
    filters
)

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                           🔧 НАСТРОЙКИ БОТА 🔧                                ║
# ║                    ВСЕ ВАЖНЫЕ ДАННЫЕ СОБРАНЫ ЗДЕСЬ                           ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# === ОСНОВНЫЕ НАСТРОЙКИ ===
BOT_TOKEN = "7411726964:AAGF6NipjdkWPg8KYkbySADPLBYNWq1ffoI"  # Токен вашего бота
CHANNEL_USERNAME = "@StarOfficeOnline"  # Канал для подписки
ADMIN_ID = 8550701850  # ID администратора
WEBSITE_LINK = "https://t.me/StarsTelegramVip_Bot/web"  # Ссылка на сайт
DATA_FILE = "/storage/emulated/0/Download/pyComad/Telegram-SellStarsVersion1/bot_data.json"  # Файл данных

# === НАСТРОЙКИ ПРОДАЖИ ЗВЁЗД (можно изменить через админ-панель) ===
DEFAULT_STARS_SETTINGS = {
    # Курс обмена: сколько рублей за 1 звезду
    "rate_per_star": 1.5,
    
    # Минимальное количество звёзд для продажи
    "min_stars": 10,
    
    # Максимальное количество звёзд для продажи
    "max_stars": 10000,
    
    # Текст сообщения при запросе продажи (поддерживает {amount} для количества)
    "sell_request_text": "⭐ <b>Продажа Telegram Stars</b>\n\nВы хотите продать: <b>{amount} ⭐</b>\n💰 Вы получите: <b>{money} ₽</b>\n\n👇 Нажмите кнопку ниже для отправки звёзд:",
    
    # Фото для сообщения продажи (file_id или URL, пустая строка = без фото)
    "sell_request_photo": "",
    
    # Текст успешной оплаты
    "success_text": "✅ <b>Оплата получена!</b>\n\n⭐ Получено звёзд: <b>{amount}</b>\n💰 К выплате: <b>{money} ₽</b>\n\nСпасибо за использование нашего сервиса!\nАдминистратор свяжется с вами для выплаты.",
    
    # Фото успешной оплаты (file_id или URL, пустая строка = без фото)
    "success_photo": "",
    
    # Текст отмены
    "cancel_text": "❌ <b>Операция отменена</b>\n\nВы отменили продажу звёзд.\nМожете начать заново в любой момент.",
    
    # Фото отмены (file_id или URL, пустая строка = без фото)
    "cancel_photo": "",
    
    # Включена ли продажа звёзд
    "enabled": True,
    
    # Название платежа
    "payment_title": "Продажа Telegram Stars",
    
    # Описание платежа
    "payment_description": "Отправка звёзд для обмена на рубли"
}

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                         КОНЕЦ БЛОКА НАСТРОЕК                                  ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Глобальное хранилище для диалогов
user_dialogs = {}

# ==================== ХРАНИЛИЩЕ ДАННЫХ ====================
def load_data():
    """Загружает данные из файла"""
    default_data = {
        "custom_buttons": {},
        "help_buttons": [],
        "users": [],
        "stars_settings": DEFAULT_STARS_SETTINGS.copy(),
        "stars_transactions": []  # История транзакций
    }
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for key in default_data:
                    if key not in data:
                        data[key] = default_data[key]
                # Обновляем настройки звёзд если добавились новые
                for key in DEFAULT_STARS_SETTINGS:
                    if key not in data.get("stars_settings", {}):
                        data["stars_settings"][key] = DEFAULT_STARS_SETTINGS[key]
                return data
    except Exception as e:
        logger.error(f"Ошибка загрузки данных: {e}")
    return default_data

def save_data():
    """Сохраняет данные в файл"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(bot_data, f, ensure_ascii=False, indent=2)
        logger.info("Данные сохранены успешно")
    except Exception as e:
        logger.error(f"Ошибка сохранения: {e}")

bot_data = load_data()
admin_state = {}

# ==================== КЛАВИАТУРЫ ====================
def get_main_keyboard():
    """Клавиатура с командами внизу экрана"""
    keyboard = [
        [KeyboardButton("🌐 Сайт"), KeyboardButton("💫 Продать звёзды")],
        [KeyboardButton("📝 Написать админу"), KeyboardButton("ℹ️ Помощь")],
        [KeyboardButton("📢 Проверить подписку")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_admin_keyboard():
    """Клавиатура для администратора"""
    keyboard = [
        [KeyboardButton("📋 Диалоги"), KeyboardButton("📊 Статистика")],
        [KeyboardButton("➕ Добавить кнопку"), KeyboardButton("🗑 Удалить кнопку")],
        [KeyboardButton("✏️ Изменить помощь"), KeyboardButton("📜 Список кнопок")],
        [KeyboardButton("💫 Настройка звёзд"), KeyboardButton("📈 История продаж")],
        [KeyboardButton("📢 Рассылка"), KeyboardButton("🚫 Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_subscription_keyboard():
    """Инлайн-клавиатура для подписки"""
    keyboard = [
        [InlineKeyboardButton("📢 Подписаться на канал", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton("✅ Я подписался", callback_data="check_subscription")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_help_inline_keyboard():
    """Инлайн-кнопки для раздела помощи"""
    buttons = []
    for btn_id, btn_info in bot_data.get("custom_buttons", {}).items():
        if btn_info.get("section") == "help":
            if btn_info.get("type") == "link":
                buttons.append([InlineKeyboardButton(btn_info["name"], url=btn_info["content"])])
            else:
                buttons.append([InlineKeyboardButton(btn_info["name"], callback_data=btn_id)])
    return InlineKeyboardMarkup(buttons) if buttons else None

def get_stars_settings_keyboard():
    """Клавиатура настроек звёзд"""
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    status = "✅ ВКЛ" if settings.get("enabled", True) else "❌ ВЫКЛ"
    
    keyboard = [
        [InlineKeyboardButton(f"Статус: {status}", callback_data="stars_toggle")],
        [InlineKeyboardButton("💰 Изменить курс", callback_data="stars_rate")],
        [InlineKeyboardButton("📊 Мин/Макс звёзд", callback_data="stars_limits")],
        [InlineKeyboardButton("📝 Текст запроса продажи", callback_data="stars_sell_text")],
        [InlineKeyboardButton("🖼 Фото запроса продажи", callback_data="stars_sell_photo")],
        [InlineKeyboardButton("✅ Текст успеха", callback_data="stars_success_text")],
        [InlineKeyboardButton("🖼 Фото успеха", callback_data="stars_success_photo")],
        [InlineKeyboardButton("❌ Текст отмены", callback_data="stars_cancel_text")],
        [InlineKeyboardButton("🖼 Фото отмены", callback_data="stars_cancel_photo")],
        [InlineKeyboardButton("🔙 Назад", callback_data="stars_back")]
    ]
    return InlineKeyboardMarkup(keyboard)

# ==================== ПРОВЕРКА ПОДПИСКИ ====================
async def check_subscription(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    try:
        chat_member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        return chat_member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Ошибка проверки подписки: {e}")
        return False

# ==================== ОБРАБОТЧИК /start ====================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # Сохраняем пользователя для рассылки
    if user_id not in bot_data["users"]:
        bot_data["users"].append(user_id)
        save_data()
    
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        await update.message.reply_text(
            "📢 Для использования бота необходимо подписаться на наш канал!\n"
            f"Канал: {CHANNEL_USERNAME}\n\n"
            "После подписки нажмите кнопку '✅ Я подписался'",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    await show_main_menu(update, context)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает главное меню"""
    user_id = update.effective_user.id
    
    welcome_text = (
        "👋 <b>Приветствую! Здравствуйте!</b>\n\n"
        "Воспользуйтесь нашим сайтом!\n\n"
        f"🌐 - <a href='{WEBSITE_LINK}'>Web</a>\n\n"
        "💫 Также вы можете продать свои Telegram Stars!\n\n"
        "👇 <i>Используйте кнопки ниже для навигации</i>"
    )
    
    if str(user_id) == str(ADMIN_ID):
        await update.message.reply_text(
            welcome_text, 
            reply_markup=get_admin_keyboard(),
            parse_mode='HTML',
            disable_web_page_preview=True
        )
    else:
        await update.message.reply_text(
            welcome_text, 
            reply_markup=get_main_keyboard(),
            parse_mode='HTML',
            disable_web_page_preview=True
        )

# ==================== CALLBACK ПРОВЕРКИ ПОДПИСКИ ====================
async def check_subscription_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    is_subscribed = await check_subscription(user_id, context)
    
    if is_subscribed:
        welcome_text = (
            "✅ <b>Подписка подтверждена!</b>\n\n"
            f"🌐 - <a href='{WEBSITE_LINK}'>Web</a>\n\n"
            "👇 <i>Используйте кнопки ниже для навигации</i>"
        )
        
        await query.edit_message_text(welcome_text, parse_mode='HTML', disable_web_page_preview=True)
        await context.bot.send_message(
            chat_id=user_id,
            text="Теперь вы можете использовать все функции бота:",
            reply_markup=get_main_keyboard()
        )
    else:
        await query.edit_message_text(
            "❌ Вы ещё не подписались на канал!\n"
            f"Пожалуйста, подпишитесь: {CHANNEL_USERNAME}\n"
            "и нажмите кнопку проверки снова.",
            reply_markup=get_subscription_keyboard()
        )

# ==================== ПРОДАЖА ЗВЁЗД ====================
async def handle_sell_stars(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало процесса продажи звёзд"""
    user_id = update.effective_user.id
    
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    
    if not settings.get("enabled", True):
        await update.message.reply_text(
            "⚠️ <b>Продажа звёзд временно недоступна</b>\n\n"
            "Пожалуйста, попробуйте позже или свяжитесь с администратором.",
            parse_mode='HTML',
            reply_markup=get_main_keyboard() if str(user_id) != str(ADMIN_ID) else get_admin_keyboard()
        )
        return
    
    min_stars = settings.get("min_stars", 10)
    max_stars = settings.get("max_stars", 10000)
    rate = settings.get("rate_per_star", 1.5)
    
    context.user_data['awaiting_stars_amount'] = True
    
    await update.message.reply_text(
        f"💫 <b>Продажа Telegram Stars</b>\n\n"
        f"💰 Курс: <b>1 ⭐ = {rate} ₽</b>\n"
        f"📊 Лимиты: от <b>{min_stars}</b> до <b>{max_stars}</b> звёзд\n\n"
        f"Введите количество звёзд, которое хотите продать:",
        parse_mode='HTML',
        reply_markup=ReplyKeyboardMarkup([[KeyboardButton("🚫 Отмена")]], resize_keyboard=True)
    )

async def process_stars_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка введённого количества звёзд"""
    user_id = update.effective_user.id
    text = update.message.text
    
    if not context.user_data.get('awaiting_stars_amount', False):
        return False
    
    context.user_data['awaiting_stars_amount'] = False
    
    try:
        amount = int(text)
    except ValueError:
        keyboard = get_main_keyboard() if str(user_id) != str(ADMIN_ID) else get_admin_keyboard()
        await update.message.reply_text(
            "❌ Пожалуйста, введите число!",
            reply_markup=keyboard
        )
        return True
    
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    min_stars = settings.get("min_stars", 10)
    max_stars = settings.get("max_stars", 10000)
    rate = settings.get("rate_per_star", 1.5)
    
    keyboard = get_main_keyboard() if str(user_id) != str(ADMIN_ID) else get_admin_keyboard()
    
    if amount < min_stars:
        await update.message.reply_text(
            f"❌ Минимальное количество: <b>{min_stars}</b> звёзд",
            parse_mode='HTML',
            reply_markup=keyboard
        )
        return True
    
    if amount > max_stars:
        await update.message.reply_text(
            f"❌ Максимальное количество: <b>{max_stars}</b> звёзд",
            parse_mode='HTML',
            reply_markup=keyboard
        )
        return True
    
    money = round(amount * rate, 2)
    
    # Формируем текст
    sell_text = settings.get("sell_request_text", DEFAULT_STARS_SETTINGS["sell_request_text"])
    sell_text = sell_text.replace("{amount}", str(amount)).replace("{money}", str(money))
    
    # Создаём инвойс для оплаты звёздами
    invoice_keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"⭐ Отправить {amount} звёзд", pay=True)],
        [InlineKeyboardButton("❌ Отмена", callback_data="cancel_stars_payment")]
    ])
    
    sell_photo = settings.get("sell_request_photo", "")
    
    try:
        if sell_photo:
            await context.bot.send_photo(
                chat_id=user_id,
                photo=sell_photo,
                caption=sell_text,
                parse_mode='HTML'
            )
        
        # Отправляем инвойс для Telegram Stars
        await context.bot.send_invoice(
            chat_id=user_id,
            title=settings.get("payment_title", "Продажа Telegram Stars"),
            description=settings.get("payment_description", "Отправка звёзд для обмена"),
            payload=f"stars_sell_{user_id}_{amount}_{money}",
            provider_token="",  # Пустой для Telegram Stars
            currency="XTR",  # Telegram Stars
            prices=[LabeledPrice(label="Telegram Stars", amount=amount)],
            reply_markup=invoice_keyboard
        )
        
    except Exception as e:
        logger.error(f"Ошибка создания инвойса: {e}")
        await update.message.reply_text(
            f"❌ Ошибка: {str(e)}",
            reply_markup=keyboard
        )
    
    return True

async def cancel_stars_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена оплаты звёздами"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    
    cancel_text = settings.get("cancel_text", DEFAULT_STARS_SETTINGS["cancel_text"])
    cancel_photo = settings.get("cancel_photo", "")
    
    keyboard = get_main_keyboard() if str(user_id) != str(ADMIN_ID) else get_admin_keyboard()
    
    try:
        await query.message.delete()
    except:
        pass
    
    if cancel_photo:
        await context.bot.send_photo(
            chat_id=user_id,
            photo=cancel_photo,
            caption=cancel_text,
            parse_mode='HTML',
            reply_markup=keyboard
        )
    else:
        await context.bot.send_message(
            chat_id=user_id,
            text=cancel_text,
            parse_mode='HTML',
            reply_markup=keyboard
        )

async def precheckout_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Подтверждение перед оплатой"""
    query = update.pre_checkout_query
    
    if query.invoice_payload.startswith("stars_sell_"):
        await query.answer(ok=True)
    else:
        await query.answer(ok=False, error_message="Неизвестный тип платежа")

async def successful_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка успешного платежа"""
    user_id = update.effective_user.id
    user = update.effective_user
    payment = update.message.successful_payment
    
    payload = payment.invoice_payload
    
    if payload.startswith("stars_sell_"):
        parts = payload.split("_")
        amount = int(parts[3])
        money = float(parts[4])
        
        settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
        
        # Сохраняем транзакцию
        transaction = {
            "user_id": user_id,
            "username": user.username,
            "full_name": user.full_name,
            "amount": amount,
            "money": money,
            "timestamp": datetime.now().isoformat(),
            "telegram_payment_charge_id": payment.telegram_payment_charge_id,
            "status": "completed"
        }
        
        if "stars_transactions" not in bot_data:
            bot_data["stars_transactions"] = []
        bot_data["stars_transactions"].append(transaction)
        save_data()
        
        # Отправляем сообщение пользователю
        success_text = settings.get("success_text", DEFAULT_STARS_SETTINGS["success_text"])
        success_text = success_text.replace("{amount}", str(amount)).replace("{money}", str(money))
        success_photo = settings.get("success_photo", "")
        
        keyboard = get_main_keyboard() if str(user_id) != str(ADMIN_ID) else get_admin_keyboard()
        
        if success_photo:
            await context.bot.send_photo(
                chat_id=user_id,
                photo=success_photo,
                caption=success_text,
                parse_mode='HTML',
                reply_markup=keyboard
            )
        else:
            await update.message.reply_text(
                success_text,
                parse_mode='HTML',
                reply_markup=keyboard
            )
        
        # Уведомляем админа
        admin_notification = (
            f"💫 <b>НОВАЯ ПРОДАЖА ЗВЁЗД!</b>\n\n"
            f"👤 Пользователь: {user.full_name}\n"
            f"🔗 Username: @{user.username if user.username else 'нет'}\n"
            f"🆔 ID: {user_id}\n\n"
            f"⭐ Звёзд: <b>{amount}</b>\n"
            f"💰 К выплате: <b>{money} ₽</b>\n\n"
            f"🔑 Payment ID: {payment.telegram_payment_charge_id}"
        )
        
        reply_keyboard = [[InlineKeyboardButton("💬 Написать пользователю", callback_data=f"reply_{user_id}")]]
        
        try:
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_notification,
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup(reply_keyboard)
            )
        except Exception as e:
            logger.error(f"Ошибка уведомления админа: {e}")

# ==================== НАСТРОЙКИ ЗВЁЗД (АДМИН) ====================
async def handle_stars_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает настройки звёзд"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    
    status = "✅ Включено" if settings.get("enabled", True) else "❌ Выключено"
    
    text = (
        f"💫 <b>НАСТРОЙКИ ПРОДАЖИ ЗВЁЗД</b>\n\n"
        f"📊 <b>Статус:</b> {status}\n"
        f"💰 <b>Курс:</b> 1 ⭐ = {settings.get('rate_per_star', 1.5)} ₽\n"
        f"📉 <b>Мин. звёзд:</b> {settings.get('min_stars', 10)}\n"
        f"📈 <b>Макс. звёзд:</b> {settings.get('max_stars', 10000)}\n\n"
        f"👇 Выберите что настроить:"
    )
    
    await update.message.reply_text(
        text,
        parse_mode='HTML',
        reply_markup=get_stars_settings_keyboard()
    )

async def handle_stars_settings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка настроек звёзд"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    data = query.data
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    
    if data == "stars_toggle":
        settings["enabled"] = not settings.get("enabled", True)
        bot_data["stars_settings"] = settings
        save_data()
        
        status = "✅ Включено" if settings["enabled"] else "❌ Выключено"
        await query.edit_message_text(
            f"💫 Продажа звёзд: <b>{status}</b>\n\nВыберите настройку:",
            parse_mode='HTML',
            reply_markup=get_stars_settings_keyboard()
        )
    
    elif data == "stars_rate":
        admin_state['action'] = 'set_stars_rate'
        await query.edit_message_text(
            f"💰 <b>Изменение курса</b>\n\n"
            f"Текущий курс: 1 ⭐ = {settings.get('rate_per_star', 1.5)} ₽\n\n"
            f"Введите новый курс (число):",
            parse_mode='HTML'
        )
    
    elif data == "stars_limits":
        admin_state['action'] = 'set_stars_limits'
        admin_state['step'] = 'min'
        await query.edit_message_text(
            f"📊 <b>Изменение лимитов</b>\n\n"
            f"Текущие лимиты: {settings.get('min_stars', 10)} - {settings.get('max_stars', 10000)}\n\n"
            f"Введите минимальное количество звёзд:",
            parse_mode='HTML'
        )
    
    elif data == "stars_sell_text":
        admin_state['action'] = 'set_stars_sell_text'
        await query.edit_message_text(
            f"📝 <b>Текст запроса продажи</b>\n\n"
            f"Текущий текст:\n{settings.get('sell_request_text', '')}\n\n"
            f"Используйте {{amount}} для количества и {{money}} для суммы.\n\n"
            f"Введите новый текст:",
            parse_mode='HTML'
        )
    
    elif data == "stars_sell_photo":
        admin_state['action'] = 'set_stars_sell_photo'
        await query.edit_message_text(
            "🖼 <b>Фото запроса продажи</b>\n\n"
            "Отправьте фото или напишите 'нет' для удаления:",
            parse_mode='HTML'
        )
    
    elif data == "stars_success_text":
        admin_state['action'] = 'set_stars_success_text'
        await query.edit_message_text(
            f"✅ <b>Текст успешной оплаты</b>\n\n"
            f"Текущий текст:\n{settings.get('success_text', '')}\n\n"
            f"Используйте {{amount}} для количества и {{money}} для суммы.\n\n"
            f"Введите новый текст:",
            parse_mode='HTML'
        )
    
    elif data == "stars_success_photo":
        admin_state['action'] = 'set_stars_success_photo'
        await query.edit_message_text(
            "🖼 <b>Фото успешной оплаты</b>\n\n"
            "Отправьте фото или напишите 'нет' для удаления:",
            parse_mode='HTML'
        )
    
    elif data == "stars_cancel_text":
        admin_state['action'] = 'set_stars_cancel_text'
        await query.edit_message_text(
            f"❌ <b>Текст отмены</b>\n\n"
            f"Текущий текст:\n{settings.get('cancel_text', '')}\n\n"
            f"Введите новый текст:",
            parse_mode='HTML'
        )
    
    elif data == "stars_cancel_photo":
        admin_state['action'] = 'set_stars_cancel_photo'
        await query.edit_message_text(
            "🖼 <b>Фото отмены</b>\n\n"
            "Отправьте фото или напишите 'нет' для удаления:",
            parse_mode='HTML'
        )
    
    elif data == "stars_back":
        admin_state.clear()
        await query.delete()
        await context.bot.send_message(
            chat_id=query.from_user.id,
            text="🔙 Возврат в меню",
            reply_markup=get_admin_keyboard()
        )

async def handle_stars_settings_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ввода настроек звёзд"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    action = admin_state.get('action', '')
    text = update.message.text
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    
    if action == 'set_stars_rate':
        try:
            rate = float(text.replace(',', '.'))
            settings["rate_per_star"] = rate
            bot_data["stars_settings"] = settings
            save_data()
            admin_state.clear()
            
            await update.message.reply_text(
                f"✅ Курс изменён: 1 ⭐ = {rate} ₽",
                reply_markup=get_admin_keyboard()
            )
            return True
        except:
            await update.message.reply_text("❌ Введите корректное число!")
            return True
    
    elif action == 'set_stars_limits':
        try:
            value = int(text)
            step = admin_state.get('step', 'min')
            
            if step == 'min':
                admin_state['min_value'] = value
                admin_state['step'] = 'max'
                await update.message.reply_text("Введите максимальное количество звёзд:")
                return True
            else:
                min_val = admin_state.get('min_value', 10)
                settings["min_stars"] = min_val
                settings["max_stars"] = value
                bot_data["stars_settings"] = settings
                save_data()
                admin_state.clear()
                
                await update.message.reply_text(
                    f"✅ Лимиты изменены: {min_val} - {value}",
                    reply_markup=get_admin_keyboard()
                )
                return True
        except:
            await update.message.reply_text("❌ Введите целое число!")
            return True
    
    elif action == 'set_stars_sell_text':
        settings["sell_request_text"] = text
        bot_data["stars_settings"] = settings
        save_data()
        admin_state.clear()
        
        await update.message.reply_text(
            "✅ Текст запроса продажи обновлён!",
            reply_markup=get_admin_keyboard()
        )
        return True
    
    elif action == 'set_stars_success_text':
        settings["success_text"] = text
        bot_data["stars_settings"] = settings
        save_data()
        admin_state.clear()
        
        await update.message.reply_text(
            "✅ Текст успеха обновлён!",
            reply_markup=get_admin_keyboard()
        )
        return True
    
    elif action == 'set_stars_cancel_text':
        settings["cancel_text"] = text
        bot_data["stars_settings"] = settings
        save_data()
        admin_state.clear()
        
        await update.message.reply_text(
            "✅ Текст отмены обновлён!",
            reply_markup=get_admin_keyboard()
        )
        return True
    
    elif action in ['set_stars_sell_photo', 'set_stars_success_photo', 'set_stars_cancel_photo']:
        if text.lower() == 'нет':
            key_map = {
                'set_stars_sell_photo': 'sell_request_photo',
                'set_stars_success_photo': 'success_photo',
                'set_stars_cancel_photo': 'cancel_photo'
            }
            settings[key_map[action]] = ""
            bot_data["stars_settings"] = settings
            save_data()
            admin_state.clear()
            
            await update.message.reply_text(
                "✅ Фото удалено!",
                reply_markup=get_admin_keyboard()
            )
            return True
    
    return False

async def handle_stars_photo_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка фото для настроек звёзд"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    action = admin_state.get('action', '')
    settings = bot_data.get("stars_settings", DEFAULT_STARS_SETTINGS)
    
    if action in ['set_stars_sell_photo', 'set_stars_success_photo', 'set_stars_cancel_photo']:
        if update.message.photo:
            file_id = update.message.photo[-1].file_id
            
            key_map = {
                'set_stars_sell_photo': 'sell_request_photo',
                'set_stars_success_photo': 'success_photo',
                'set_stars_cancel_photo': 'cancel_photo'
            }
            
            settings[key_map[action]] = file_id
            bot_data["stars_settings"] = settings
            save_data()
            admin_state.clear()
            
            await update.message.reply_text(
                "✅ Фото сохранено!",
                reply_markup=get_admin_keyboard()
            )

# ==================== ИСТОРИЯ ПРОДАЖ ====================
async def handle_sales_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает историю продаж"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    transactions = bot_data.get("stars_transactions", [])
    
    if not transactions:
        await update.message.reply_text(
            "📈 <b>История продаж</b>\n\n"
            "Пока нет транзакций.",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )
        return
    
    # Последние 10 транзакций
    recent = transactions[-10:][::-1]
    
    total_stars = sum(t.get("amount", 0) for t in transactions)
    total_money = sum(t.get("money", 0) for t in transactions)
    
    text = (
        f"📈 <b>История продаж звёзд</b>\n\n"
        f"📊 Всего транзакций: {len(transactions)}\n"
        f"⭐ Всего звёзд: {total_stars}\n"
        f"💰 Всего к выплате: {total_money} ₽\n\n"
        f"<b>Последние транзакции:</b>\n"
    )
    
    for i, t in enumerate(recent, 1):
        text += f"\n{i}. @{t.get('username', 'нет')} - {t.get('amount')} ⭐ = {t.get('money')} ₽"
    
    await update.message.reply_text(
        text,
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )

# ==================== ОБРАБОТКА КНОПКИ "НАПИСАТЬ АДМИНУ" ====================
async def handle_write_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    context.user_data['awaiting_admin_message'] = True
    
    await update.message.reply_text(
        "✍️ Напишите своё сообщение Администратору:\n\n"
        "Просто напишите текст сообщения и отправьте его.",
        parse_mode='HTML',
        reply_markup=ReplyKeyboardMarkup([[KeyboardButton("🚫 Отмена")]], resize_keyboard=True)
    )

# ==================== ОБРАБОТКА КНОПКИ "САЙТ" ====================
async def handle_website(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    keyboard = get_admin_keyboard() if str(user_id) == str(ADMIN_ID) else get_main_keyboard()
    
    await update.message.reply_text(
        f"🌐 <b>Наш сайт:</b>\n\n"
        f"Перейдите по ссылке: <a href='{WEBSITE_LINK}'>Web</a>",
        parse_mode='HTML',
        disable_web_page_preview=True,
        reply_markup=keyboard
    )

# ==================== ОБРАБОТКА КНОПКИ "ПОМОЩЬ" ====================
async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    help_text = (
        "⭐ ПОМОЩЬ ПО ИСПОЛЬЗОВАНИЮ БОТА\n\n"
        "Данный бот предназначен для работы с системой Telegram Stars и предоставляет "
        "пользователям доступ к официальному сервису покупки и продажи звёзд Telegram. "
        "Все операции осуществляются через официальный сайт сервиса.\n\n"
        
        "📋 КАК ПОЛЬЗОВАТЬСЯ БОТОМ:\n"
        "1. Нажмите кнопку START для начала работы\n"
        "2. После запуска бота используйте кнопку 🌐 - Сайт на клавиатуре\n"
        "3. Перейдите по ссылке на официальный сайт сервиса\n"
        "4. Выберите необходимое количество Telegram Stars\n"
        "5. Следуйте инструкциям на сайте для завершения операции\n\n"
        
        "💫 ПРОДАЖА ЗВЁЗД:\n"
        "• Нажмите кнопку 'Продать звёзды'\n"
        "• Введите количество звёзд\n"
        "• Нажмите кнопку оплаты\n"
        "• Дождитесь связи с администратором для выплаты\n\n"
        
        "⚠️ ВАЖНАЯ ИНФОРМАЦИЯ:\n"
        "• Бот работает в рамках официального сервиса Telegram Stars\n"
        "• Бот не запрашивает и не хранит персональные данные пользователей\n"
        "• Все действия совершаются пользователем добровольно\n"
        "• Ответственность за использование сервиса лежит на пользователе\n\n"
        
        "🆘 ОСНОВНЫЕ ФУНКЦИИ:\n"
        "• Сайт - получить ссылку на официальный сайт сервиса\n"
        "• Продать звёзды - обменять звёзды на рубли\n"
        "• Написать админу - связь с администратором\n"
        "• Проверить подписку - проверить статус подписки на канал\n\n"
        "Все функции доступны после подписки на наш канал!\n"
        f"Канал: {CHANNEL_USERNAME}"
    )
    
    keyboard = get_admin_keyboard() if str(user_id) == str(ADMIN_ID) else get_main_keyboard()
    
    await update.message.reply_text(
        help_text,
        parse_mode='HTML',
        reply_markup=keyboard
    )
    
    help_inline = get_help_inline_keyboard()
    if help_inline:
        await update.message.reply_text(
            "👇 Дополнительные материалы:",
            parse_mode='HTML',
            reply_markup=help_inline
        )

# ==================== ОБРАБОТКА КНОПКИ "ПРОВЕРИТЬ ПОДПИСКУ" ====================
async def handle_check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    is_subscribed = await check_subscription(user_id, context)
    
    keyboard = get_admin_keyboard() if str(user_id) == str(ADMIN_ID) else get_main_keyboard()
    
    if is_subscribed:
        await update.message.reply_text(
            "✅ Вы подписаны на канал!\n\nВы можете использовать все функции бота.",
            parse_mode='HTML',
            reply_markup=keyboard
        )
    else:
        await update.message.reply_text(
            f"❌ Вы не подписаны на канал!\n\nПожалуйста, подпишитесь: {CHANNEL_USERNAME}",
            reply_markup=get_subscription_keyboard()
        )

# ==================== ОБРАБОТКА КНОПКИ "ОТМЕНА" ====================
async def handle_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if 'awaiting_admin_message' in context.user_data:
        context.user_data['awaiting_admin_message'] = False
    if 'awaiting_stars_amount' in context.user_data:
        context.user_data['awaiting_stars_amount'] = False
    
    if str(user_id) == str(ADMIN_ID):
        admin_state.clear()
        if 'admin_reply_mode' in context.user_data:
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
        await update.message.reply_text("🚫 Действие отменено", reply_markup=get_admin_keyboard())
    else:
        await update.message.reply_text("🚫 Действие отменено", reply_markup=get_main_keyboard())

# ==================== ДОБАВЛЕНИЕ КНОПКИ ====================
async def handle_add_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начинает процесс добавления кнопки"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    admin_state['action'] = 'add_button'
    admin_state['step'] = 1
    
    keyboard = [
        [InlineKeyboardButton("📍 В раздел Помощь", callback_data="section_help")],
    ]
    
    await update.message.reply_text(
        "➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
        "Шаг 1/4: Выберите раздел для кнопки:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_section_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора раздела"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    section = query.data.replace("section_", "")
    admin_state['section'] = section
    admin_state['step'] = 2
    
    keyboard = [
        [InlineKeyboardButton("🔗 Ссылка", callback_data="type_link")],
        [InlineKeyboardButton("📝 Текст", callback_data="type_text")],
        [InlineKeyboardButton("📸 Фото", callback_data="type_photo")],
        [InlineKeyboardButton("🎬 Видео", callback_data="type_video")],
        [InlineKeyboardButton("📄 Документ", callback_data="type_document")],
    ]
    
    await query.edit_message_text(
        f"➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
        f"✅ Раздел: {section}\n\n"
        "Шаг 2/4: Выберите тип контента:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_type_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора типа"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    btn_type = query.data.replace("type_", "")
    admin_state['type'] = btn_type
    admin_state['step'] = 3
    
    await query.edit_message_text(
        f"➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
        f"✅ Раздел: {admin_state['section']}\n"
        f"✅ Тип: {btn_type}\n\n"
        "Шаг 3/4: Введите название кнопки:\n"
        "(Например: 📹 Видео-туториал)",
        parse_mode='HTML'
    )

async def handle_admin_add_button_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ввода при добавлении кнопки"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    if admin_state.get('action') != 'add_button':
        return False
    
    step = admin_state.get('step', 0)
    text = update.message.text
    
    if step == 3:
        admin_state['name'] = text
        admin_state['step'] = 4
        
        type_hints = {
            "link": "Введите ссылку (https://...)",
            "text": "Введите текст сообщения",
            "photo": "Отправьте фото",
            "video": "Отправьте видео",
            "document": "Отправьте файл/документ"
        }
        
        await update.message.reply_text(
            f"➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
            f"✅ Раздел: {admin_state['section']}\n"
            f"✅ Тип: {admin_state['type']}\n"
            f"✅ Название: {admin_state['name']}\n\n"
            f"Шаг 4/4: {type_hints.get(admin_state['type'], 'Отправьте контент')}",
            parse_mode='HTML'
        )
        return True
    
    elif step == 4 and admin_state.get('type') in ['text', 'link']:
        await save_button(update, text)
        return True
    
    return False

async def handle_admin_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка медиа от админа"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    # Проверяем настройки звёзд
    action = admin_state.get('action', '')
    if action in ['set_stars_sell_photo', 'set_stars_success_photo', 'set_stars_cancel_photo']:
        await handle_stars_photo_input(update, context)
        return
    
    if admin_state.get('action') != 'add_button' or admin_state.get('step') != 4:
        return
    
    file_id = None
    btn_type = admin_state.get('type')
    
    if update.message.photo and btn_type == 'photo':
        file_id = update.message.photo[-1].file_id
    elif update.message.video and btn_type == 'video':
        file_id = update.message.video.file_id
    elif update.message.document and btn_type == 'document':
        file_id = update.message.document.file_id
    
    if file_id:
        admin_state['content'] = file_id
        admin_state['step'] = 5
        
        keyboard = [[InlineKeyboardButton("⏭ Без подписи", callback_data="skip_caption")]]
        
        await update.message.reply_text(
            "📝 Введите подпись к медиа (или нажмите 'Без подписи'):",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def handle_caption_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка подписи к медиа"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    if admin_state.get('action') == 'add_button' and admin_state.get('step') == 5:
        await save_button(update, admin_state['content'], update.message.text)
        return True
    
    return False

async def skip_caption_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Пропуск подписи"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    if admin_state.get('action') == 'add_button' and admin_state.get('step') == 5:
        btn_id = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        bot_data["custom_buttons"][btn_id] = {
            "name": admin_state['name'],
            "section": admin_state['section'],
            "type": admin_state['type'],
            "content": admin_state['content'],
            "caption": ""
        }
        save_data()
        
        await query.edit_message_text(
            f"✅ КНОПКА СОЗДАНА!\n\n"
            f"📌 Название: {admin_state['name']}\n"
            f"📍 Раздел: {admin_state['section']}\n"
            f"📦 Тип: {admin_state['type']}\n"
            f"🆔 ID: {btn_id}",
            parse_mode='HTML'
        )
        
        admin_state.clear()
        
        await context.bot.send_message(
            chat_id=query.from_user.id,
            text="Используйте панель управления:",
            reply_markup=get_admin_keyboard()
        )

async def save_button(update: Update, content: str, caption: str = ""):
    """Сохраняет кнопку"""
    btn_id = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    bot_data["custom_buttons"][btn_id] = {
        "name": admin_state['name'],
        "section": admin_state['section'],
        "type": admin_state['type'],
        "content": content,
        "caption": caption
    }
    save_data()
    
    await update.message.reply_text(
        f"✅ КНОПКА СОЗДАНА!\n\n"
        f"📌 Название: {admin_state['name']}\n"
        f"📍 Раздел: {admin_state['section']}\n"
        f"📦 Тип: {admin_state['type']}\n"
        f"🆔 ID: {btn_id}",
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )
    
    admin_state.clear()

# ==================== УДАЛЕНИЕ КНОПКИ ====================
async def handle_delete_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает список кнопок для удаления"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    buttons = bot_data.get("custom_buttons", {})
    
    if not buttons:
        await update.message.reply_text("📭 Нет кнопок для удаления", reply_markup=get_admin_keyboard())
        return
    
    keyboard = []
    for btn_id, btn_info in buttons.items():
        keyboard.append([InlineKeyboardButton(
            f"🗑 {btn_info['name']} ({btn_info['type']})",
            callback_data=f"delete_{btn_id}"
        )])
    
    await update.message.reply_text(
        "🗑 УДАЛЕНИЕ КНОПКИ\n\nВыберите кнопку для удаления:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_delete_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Удаляет кнопку"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    btn_id = query.data.replace("delete_", "")
    
    if btn_id in bot_data.get("custom_buttons", {}):
        btn_name = bot_data["custom_buttons"][btn_id]["name"]
        del bot_data["custom_buttons"][btn_id]
        save_data()
        
        await query.edit_message_text(f"✅ Кнопка «{btn_name}» удалена!", parse_mode='HTML')
    else:
        await query.edit_message_text("❌ Кнопка не найдена")

# ==================== СПИСОК КНОПОК ====================
async def handle_list_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает список всех кнопок"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    buttons = bot_data.get("custom_buttons", {})
    
    if not buttons:
        await update.message.reply_text("📭 Кнопок пока нет", reply_markup=get_admin_keyboard())
        return
    
    text = "📜 СПИСОК КНОПОК:\n\n"
    
    for btn_id, btn_info in buttons.items():
        text += f"🔘 {btn_info['name']}\n"
        text += f"   📍 Раздел: {btn_info['section']}\n"
        text += f"   📦 Тип: {btn_info['type']}\n"
        text += f"   🆔 {btn_id}\n\n"
    
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=get_admin_keyboard())

# ==================== ИЗМЕНИТЬ ПОМОЩЬ ====================
async def handle_edit_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Информация о редактировании помощи"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    await update.message.reply_text(
        "✏️ РЕДАКТИРОВАНИЕ ПОМОЩИ\n\n"
        "⚠️ Текст помощи задан в коде бота.\n"
        "Но вы можете добавить кнопки с дополнительными материалами!\n\n"
        "Используйте ➕ Добавить кнопку чтобы добавить:\n"
        "• Видео-туториалы\n"
        "• Фото-инструкции\n"
        "• Ссылки на материалы\n"
        "• Документы",
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )

# ==================== РАССЫЛКА ====================
async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начинает рассылку"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    admin_state['action'] = 'broadcast'
    
    await update.message.reply_text(
        f"📢 РАССЫЛКА\n\n"
        f"Пользователей в базе: {len(bot_data['users'])}\n\n"
        "Отправьте сообщение для рассылки (текст, фото или видео):\n\n"
        "Для отмены нажмите 🚫 Отмена",
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )

async def handle_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправляет рассылку"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    if admin_state.get('action') != 'broadcast':
        return False
    
    admin_state.clear()
    
    success = 0
    failed = 0
    
    status_msg = await update.message.reply_text("📤 Начинаю рассылку...")
    
    for user_id in bot_data["users"]:
        if user_id == ADMIN_ID:
            continue
        try:
            if update.message.photo:
                await context.bot.send_photo(
                    chat_id=user_id,
                    photo=update.message.photo[-1].file_id,
                    caption=update.message.caption or ""
                )
            elif update.message.video:
                await context.bot.send_video(
                    chat_id=user_id,
                    video=update.message.video.file_id,
                    caption=update.message.caption or ""
                )
            else:
                await context.bot.send_message(chat_id=user_id, text=update.message.text)
            success += 1
        except Exception as e:
            logger.error(f"Ошибка рассылки {user_id}: {e}")
            failed += 1
    
    await status_msg.edit_text(
        f"✅ Рассылка завершена!\n\n"
        f"✉️ Отправлено: {success}\n"
        f"❌ Ошибок: {failed}",
        parse_mode='HTML'
    )
    
    return True

# ==================== ОБРАБОТКА КАСТОМНЫХ КНОПОК ====================
async def handle_custom_button_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие на кастомную кнопку"""
    query = update.callback_query
    await query.answer()
    
    btn_id = query.data
    
    logger.info(f"Нажата кнопка: {btn_id}")
    
    if btn_id not in bot_data.get("custom_buttons", {}):
        await query.message.reply_text(f"❌ Кнопка не найдена: {btn_id}")
        return
    
    btn_info = bot_data["custom_buttons"][btn_id]
    btn_type = btn_info.get("type")
    content = btn_info.get("content")
    caption = btn_info.get("caption", "")
    
    try:
        if btn_type == "photo":
            await context.bot.send_photo(
                chat_id=query.from_user.id, 
                photo=content, 
                caption=caption if caption else None,
                parse_mode='HTML'
            )
        elif btn_type == "video":
            await context.bot.send_video(
                chat_id=query.from_user.id, 
                video=content, 
                caption=caption if caption else None,
                parse_mode='HTML'
            )
        elif btn_type == "document":
            await context.bot.send_document(
                chat_id=query.from_user.id, 
                document=content, 
                caption=caption if caption else None,
                parse_mode='HTML'
            )
        elif btn_type == "text":
            await query.message.reply_text(content, parse_mode='HTML')
        
    except Exception as e:
        logger.error(f"Ошибка отправки контента: {e}")
        await query.message.reply_text(f"❌ Ошибка загрузки контента: {str(e)}")

# ==================== ОБРАБОТКА ТЕКСТА ====================
async def handle_user_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    message_text = update.message.text
    
    # Если это админ
    if str(user_id) == str(ADMIN_ID):
        if await handle_admin_add_button_input(update, context):
            return
        if await handle_caption_input(update, context):
            return
        if await handle_broadcast_message(update, context):
            return
        if await handle_stars_settings_input(update, context):
            return
        await handle_admin_message(update, context)
        return
    
    # Проверяем ожидание количества звёзд
    if await process_stars_amount(update, context):
        return
    
    # Пропускаем команды кнопок
    if message_text in ["🌐 Сайт", "📝 Написать админу", "ℹ️ Помощь", "📢 Проверить подписку", "🚫 Отмена", "💫 Продать звёзды"]:
        return
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    # Если ожидает отправки сообщения админу
    if context.user_data.get('awaiting_admin_message', False):
        admin_message = (
            f"📩 Новое сообщение от пользователя:\n\n"
            f"👤 ID: {user_id}\n"
            f"📛 Имя: {user.full_name}\n"
            f"🔗 Username: @{user.username if user.username else 'нет'}\n"
            f"📝 Сообщение:\n───────\n{message_text}\n───────"
        )
        
        if user_id not in user_dialogs:
            user_dialogs[user_id] = []
        
        user_dialogs[user_id].append({
            "from_user": True,
            "text": message_text,
            "timestamp": str(update.message.date)
        })
        
        keyboard = [[InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user_id}")]]
        
        try:
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
            
            await update.message.reply_text(
                "✅ Ваше сообщение отправлено администратору!\n\nОжидайте ответа в этом чате.",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки админу: {e}")
            await update.message.reply_text("❌ Ошибка отправки сообщения.", reply_markup=get_main_keyboard())
        
        context.user_data['awaiting_admin_message'] = False
    else:
        await update.message.reply_text(
            "ℹ️ Используйте кнопки для навигации:\n\n"
            "• Нажмите 'Написать админу' для обращения\n"
            "• Нажмите 'Сайт' для перехода на сайт\n"
            "• Нажмите 'Продать звёзды' для обмена звёзд\n"
            "• Нажмите 'Помощь' для справки",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )

# ==================== ОБРАБОТКА СООБЩЕНИЙ АДМИНА ====================
async def handle_admin_reply_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        await query.answer("❌ Только администратор может отвечать!", show_alert=True)
        return
    
    data = query.data
    if data.startswith("reply_"):
        target_user_id = int(data.split("_")[1])
        
        context.user_data['admin_reply_mode'] = True
        context.user_data['target_user_id'] = target_user_id
        
        await query.message.reply_text(
            f"💬 Вы отвечаете пользователю (ID: {target_user_id})\n\nВведите ваш ответ:",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if str(user_id) != str(ADMIN_ID):
        return
    
    text = update.message.text
    
    # Обработка кнопок админа
    if text == "📋 Диалоги":
        await show_admin_dialogs(update, context)
        return
    elif text == "📊 Статистика":
        await show_admin_stats(update, context)
        return
    elif text == "➕ Добавить кнопку":
        await handle_add_button(update, context)
        return
    elif text == "🗑 Удалить кнопку":
        await handle_delete_button(update, context)
        return
    elif text == "✏️ Изменить помощь":
        await handle_edit_help(update, context)
        return
    elif text == "📜 Список кнопок":
        await handle_list_buttons(update, context)
        return
    elif text == "💫 Настройка звёзд":
        await handle_stars_settings(update, context)
        return
    elif text == "📈 История продаж":
        await handle_sales_history(update, context)
        return
    elif text == "📢 Рассылка":
        await handle_broadcast(update, context)
        return
    elif text == "🚫 Отмена":
        admin_state.clear()
        context.user_data['admin_reply_mode'] = False
        context.user_data['target_user_id'] = None
        await update.message.reply_text("🚫 Действие отменено", reply_markup=get_admin_keyboard())
        return
    
    # Режим ответа пользователю
    if context.user_data.get('admin_reply_mode', False):
        target_user_id = context.user_data.get('target_user_id')
        
        if not target_user_id:
            await update.message.reply_text("❌ Ошибка: не найден пользователь")
            context.user_data['admin_reply_mode'] = False
            return
        
        try:
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"📨 Ответ от администратора:\n\n{text}",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            
            if target_user_id not in user_dialogs:
                user_dialogs[target_user_id] = []
            
            user_dialogs[target_user_id].append({
                "from_user": False,
                "text": text,
                "timestamp": str(update.message.date)
            })
            
            await update.message.reply_text(
                f"✅ Ответ отправлен пользователю (ID: {target_user_id})!",
                reply_markup=get_admin_keyboard()
            )
            
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
            
        except Exception as e:
            logger.error(f"Ошибка отправки: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}", reply_markup=get_admin_keyboard())
    else:
        await update.message.reply_text(
            "ℹ️ Вы администратор!\n\n"
            "Используйте кнопки для управления ботом.",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )

# ==================== ФУНКЦИИ АДМИНА ====================
async def show_admin_dialogs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not user_dialogs:
        await update.message.reply_text("📭 Нет активных диалогов", reply_markup=get_admin_keyboard())
        return
    
    message = "📋 Активные диалоги:\n\n"
    count = 1
    for uid, messages in user_dialogs.items():
        try:
            user_info = await context.bot.get_chat(uid)
            username = f"@{user_info.username}" if user_info.username else "нет"
            message += f"{count}. 👤 {user_info.full_name} ({username})\n"
            message += f"   🔹 ID: {uid}\n"
            message += f"   🔹 Сообщений: {len(messages)}\n\n"
            count += 1
        except:
            message += f"{count}. 👤 ID: {uid} - {len(messages)} сообщений\n\n"
            count += 1
    
    await update.message.reply_text(message, parse_mode='HTML', reply_markup=get_admin_keyboard())

async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    total_dialogs = len(user_dialogs)
    total_messages = sum(len(m) for m in user_dialogs.values())
    total_users = len(bot_data.get("users", []))
    total_buttons = len(bot_data.get("custom_buttons", {}))
    
    # Статистика звёзд
    transactions = bot_data.get("stars_transactions", [])
    total_stars = sum(t.get("amount", 0) for t in transactions)
    total_money = sum(t.get("money", 0) for t in transactions)
    
    stats_text = (
        f"📊 Статистика бота:\n\n"
        f"👥 Пользователей в базе: {total_users}\n"
        f"💬 Активных диалогов: {total_dialogs}\n"
        f"✉️ Всего сообщений: {total_messages}\n"
        f"🔘 Кастомных кнопок: {total_buttons}\n\n"
        f"💫 <b>Статистика звёзд:</b>\n"
        f"📈 Транзакций: {len(transactions)}\n"
        f"⭐ Получено звёзд: {total_stars}\n"
        f"💰 К выплате: {total_money} ₽"
    )
    
    await update.message.reply_text(stats_text, parse_mode='HTML', reply_markup=get_admin_keyboard())

# ==================== ОБРАБОТКА МЕДИА ====================
async def handle_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if str(user_id) == str(ADMIN_ID):
        action = admin_state.get('action', '')
        
        # Проверяем настройки звёзд
        if action in ['set_stars_sell_photo', 'set_stars_success_photo', 'set_stars_cancel_photo']:
            await handle_stars_photo_input(update, context)
            return
        
        if action == 'add_button' and admin_state.get('step') == 4:
            await handle_admin_media(update, context)
            return
        
        if action == 'broadcast':
            await handle_broadcast_message(update, context)
            return

# ==================== ОСНОВНАЯ ФУНКЦИЯ ====================
def main():
    print("=" * 60)
    print("🤖 Бот запущен!")
    print(f"👑 ID администратора: {ADMIN_ID}")
    print(f"📢 Канал для подписки: {CHANNEL_USERNAME}")
    print(f"📁 Файл данных: {DATA_FILE}")
    print("=" * 60)
    print("\n👑 Функции админа:")
    print("• ➕ Добавить кнопку")
    print("• 🗑 Удалить кнопку")
    print("• ✏️ Изменить помощь")
    print("• 📜 Список кнопок")
    print("• 💫 Настройка звёзд")
    print("• 📈 История продаж")
    print("• 📢 Рассылка")
    print("=" * 60)
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Команды
    application.add_handler(CommandHandler("start", start))
    
    # Платежи
    application.add_handler(PreCheckoutQueryHandler(precheckout_callback))
    application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment_callback))
    
    # Callbacks
    application.add_handler(CallbackQueryHandler(check_subscription_callback, pattern="^check_subscription$"))
    application.add_handler(CallbackQueryHandler(handle_admin_reply_button, pattern="^reply_"))
    application.add_handler(CallbackQueryHandler(handle_section_selection, pattern="^section_"))
    application.add_handler(CallbackQueryHandler(handle_type_selection, pattern="^type_"))
    application.add_handler(CallbackQueryHandler(handle_delete_callback, pattern="^delete_"))
    application.add_handler(CallbackQueryHandler(skip_caption_callback, pattern="^skip_caption$"))
    application.add_handler(CallbackQueryHandler(cancel_stars_payment_callback, pattern="^cancel_stars_payment$"))
    application.add_handler(CallbackQueryHandler(handle_stars_settings_callback, pattern="^stars_"))
    application.add_handler(CallbackQueryHandler(handle_custom_button_click, pattern="^btn_"))
    
    # Кнопки клавиатуры
    application.add_handler(MessageHandler(filters.Text(["🌐 Сайт"]), handle_website))
    application.add_handler(MessageHandler(filters.Text(["📝 Написать админу"]), handle_write_to_admin))
    application.add_handler(MessageHandler(filters.Text(["ℹ️ Помощь"]), handle_help))
    application.add_handler(MessageHandler(filters.Text(["📢 Проверить подписку"]), handle_check_subscription))
    application.add_handler(MessageHandler(filters.Text(["🚫 Отмена"]), handle_cancel))
    application.add_handler(MessageHandler(filters.Text(["💫 Продать звёзды"]), handle_sell_stars))
    
    # Медиа
    application.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO | filters.Document.ALL, handle_media))
    
    # Текст
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_user_text))
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
