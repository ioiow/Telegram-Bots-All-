# -*- coding: utf-8 -*-
import telebot
from telebot import types
import json
import os
import time

# ==================== НАСТРОЙКИ ====================
BOT_TOKEN = "8315085436:AAEJ0CDREYXBrcONUpRznuG1pk6OSozro34"
ADMIN_ID = 8550701850

# ==================== ПУТИ К ФАЙЛАМ ====================
# ИЗМЕНИТЕ ЭТИ ПУТИ НА СВОИ:
DATA_FOLDER = "/storage/emulated/0/Download/pyComad/Telegram-ChityMoreForgame/date"  # <-- УКАЖИТЕ СВОЙ ПУТЬ К ПАПКЕ
PRODUCTS_FILE = os.path.join(DATA_FOLDER, "/storage/emulated/0/Download/pyComad/Telegram-ChityMoreForgame/date/products.json")
CHANNELS_FILE = os.path.join(DATA_FOLDER, "/storage/emulated/0/Download/pyComad/Telegram-ChityMoreForgame/date/required_channels.json")
USERS_FILE = os.path.join(DATA_FOLDER, "/storage/emulated/0/Download/pyComad/Telegram-ChityMoreForgame/date/users.json")

# ==================== СОЗДАНИЕ ПАПКИ ====================
if not os.path.exists(DATA_FOLDER):
    os.makedirs(DATA_FOLDER)

# ==================== ИНИЦИАЛИЗАЦИЯ БОТА ====================
bot = telebot.TeleBot(BOT_TOKEN)

# ==================== КАНАЛЫ ПО ИГРАМ ====================
GAME_CHANNELS = {
    "delta": [
        {"name": "🎮 Delta Executor", "url": "https://t.me/Delta_executrOrKtnl"},
        {"name": "⚔️ Delta Armia", "url": "https://t.me/Deltaarmia"},
        {"name": "🔥 Читы Delta", "url": "https://t.me/chitii_delta"},
        {"name": "🎯 Delta Force Cheat", "url": "https://t.me/deltaforce_cheat"},
        {"name": "🇷🇺 Delta Force RU", "url": "https://t.me/deltaforce_ru"},
        {"name": "📱 Easy APK", "url": "https://t.me/EasyAPK"}
    ],
    "standoff": [
        {"name": "🤖 S2 CheatX Bot", "url": "https://t.me/S2CheatX_Bot"},
        {"name": "😈 Iruma Standoff2", "url": "https://t.me/Iruma_Standoff2"},
        {"name": "🔫 Читы FG", "url": "https://t.me/chityfgfq"},
        {"name": "⬇️ Скачать читы SO2", "url": "https://t.me/skachat_chity_standoff2"},
        {"name": "🎮 Standoff2 TG Читы", "url": "https://t.me/Stendoff2_tg_Chity"},
        {"name": "💥 Standoff Читы", "url": "https://t.me/standoff_chity"}
    ],
    "pubg": [
        {"name": "🔥 Читы PUBG", "url": "https://t.me/chityfhrc"},
        {"name": "🎯 GFB Читы", "url": "https://t.me/gfb_chitybfdc"},
        {"name": "⚡ Sory Hacks", "url": "https://t.me/sorysnjsjx"},
        {"name": "💻 ChatSoft PUBG", "url": "https://t.me/Chatsoftpybg"},
        {"name": "🐕 Kutta Cheats", "url": "https://t.me/kuttavaiterr"},
        {"name": "📱 ПАБГ Читы", "url": "https://t.me/pabg_chity"}
    ]
}

GAME_NAMES = {"delta": "Delta Force Mobile", "pubg": "PUBG Mobile", "standoff": "Standoff 2"}

# ==================== ЗАГРУЗКА/СОХРАНЕНИЕ ДАННЫХ ====================
def load_json(file_path, default=None):
    if default is None:
        default = []
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return default

def save_json(file_path, data):
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_products():
    return load_json(PRODUCTS_FILE, {"delta": [], "standoff": [], "pubg": []})

def save_products(products):
    save_json(PRODUCTS_FILE, products)

def get_required_channels():
    return load_json(CHANNELS_FILE, [])

def save_required_channels(channels):
    save_json(CHANNELS_FILE, channels)

def get_users():
    return load_json(USERS_FILE, [])

def save_user(user_id):
    users = get_users()
    if user_id not in users:
        users.append(user_id)
        save_json(USERS_FILE, users)

# ==================== ПРОВЕРКА ПОДПИСКИ ====================
def check_subscription(user_id):
    channels = get_required_channels()
    if not channels:
        return True
    
    for channel in channels:
        try:
            member = bot.get_chat_member(channel['id'], user_id)
            if member.status in ['left', 'kicked']:
                return False
        except:
            pass
    return True

def get_subscription_keyboard():
    channels = get_required_channels()
    markup = types.InlineKeyboardMarkup(row_width=1)
    for channel in channels:
        markup.add(types.InlineKeyboardButton(f"📢 {channel['name']}", url=channel['url']))
    markup.add(types.InlineKeyboardButton("✅ Проверить подписку", callback_data="check_sub"))
    return markup

# ==================== ГЛАВНОЕ МЕНЮ ====================
def main_menu():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🔒 Приват-группы и каналы", callback_data="private_channels"),
        types.InlineKeyboardButton("🛒 Товары", callback_data="products"),
        types.InlineKeyboardButton("👤 Связаться с админом", callback_data="contact_admin")
    )
    return markup

def admin_menu():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("➕ Создать товар", callback_data="admin_add_product"),
        types.InlineKeyboardButton("✏️ Редактировать товар", callback_data="admin_edit_product"),
        types.InlineKeyboardButton("📢 Рассылка", callback_data="admin_broadcast"),
        types.InlineKeyboardButton("📌 Добавить канал для подписки", callback_data="admin_add_channel"),
        types.InlineKeyboardButton("🗑 Удалить канал подписки", callback_data="admin_del_channel"),
        types.InlineKeyboardButton("📋 Список каналов подписки", callback_data="admin_list_channels"),
        types.InlineKeyboardButton("🗑 Удалить товар", callback_data="admin_del_product"),
        types.InlineKeyboardButton("🔙 Назад", callback_data="back_main")
    )
    return markup

def games_menu(prefix="game"):
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🎮 Delta Force Mobile 📱", callback_data=f"{prefix}_delta"),
        types.InlineKeyboardButton("🔫 PUBG Mobile 📱", callback_data=f"{prefix}_pubg"),
        types.InlineKeyboardButton("⚔️ Standoff 2 📱", callback_data=f"{prefix}_standoff"),
        types.InlineKeyboardButton("🔙 Назад", callback_data="back_main")
    )
    return markup

# ==================== СОСТОЯНИЯ ====================
admin_states = {}
user_states = {}

# ==================== ОТПРАВКА ГЛАВНОГО МЕНЮ ====================
def send_main_menu(chat_id):
    welcome_text = """
🎮 <b>Главное меню</b> 🎮

⬇️ Выбирай что тебе нужно:
"""
    bot.send_message(
        chat_id,
        welcome_text,
        parse_mode="HTML",
        reply_markup=main_menu()
    )

# ==================== ПОКАЗАТЬ ТОВАРЫ ИГРЫ ====================
def show_game_products(chat_id, game, message_id=None):
    products = get_products()
    game_products = products.get(game, [])
    
    if not game_products:
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="products"))
        text = f"📱 <b>{GAME_NAMES.get(game, game)}</b>\n\n⏳ Товаров пока нет...\n\n🔜 Ожидайте выход новых товаров!\nМы работаем над этим! 💪"
    else:
        markup = types.InlineKeyboardMarkup(row_width=1)
        for i, prod in enumerate(game_products):
            markup.add(types.InlineKeyboardButton(f"📦 {prod['name']}", callback_data=f"view_{game}_{i}"))
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="products"))
        text = f"📱 <b>{GAME_NAMES.get(game, game)}</b>\n\n🛒 Доступные товары:"
    
    if message_id:
        try:
            bot.edit_message_text(
                text,
                chat_id,
                message_id,
                parse_mode="HTML",
                reply_markup=markup
            )
        except:
            bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)
    else:
        bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)

# ==================== ОБРАБОТЧИКИ ====================
@bot.message_handler(commands=['start'])
def start_handler(message):
    user_id = message.from_user.id
    save_user(user_id)
    
    if user_id in user_states:
        del user_states[user_id]
    if user_id in admin_states:
        del admin_states[user_id]
    
    if not check_subscription(user_id):
        bot.send_message(
            message.chat.id,
            "❌ <b>Для использования бота необходимо подписаться на каналы:</b>",
            parse_mode="HTML",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    welcome_text = """
🎮 <b>Добро пожаловать, юный пользователь!</b> 🎮

🌟 Ты попал в самое крутое место для геймеров!
Здесь тебе точно не будет скучно! 

🔥 У нас ты найдёшь:
• Приватные каналы и группы
• Эксклюзивные товары для игр
• Топовый контент для настоящих игроков

⬇️ <b>Выбирай что тебе нужно:</b>
"""
    bot.send_message(
        message.chat.id,
        welcome_text,
        parse_mode="HTML",
        reply_markup=main_menu()
    )

@bot.message_handler(commands=['admin'])
def admin_handler(message):
    if message.from_user.id != ADMIN_ID:
        bot.send_message(message.chat.id, "❌ У вас нет прав администратора!")
        return
    
    bot.send_message(
        message.chat.id,
        "🔐 <b>Панель администратора</b>\n\nВыберите действие:",
        parse_mode="HTML",
        reply_markup=admin_menu()
    )

# ==================== CALLBACK ОБРАБОТЧИКИ ====================
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    message_id = call.message.message_id
    
    # Проверка подписки
    if call.data == "check_sub":
        if check_subscription(user_id):
            bot.answer_callback_query(call.id, "✅ Подписка подтверждена!")
            try:
                bot.delete_message(chat_id, message_id)
            except:
                pass
            start_handler(call.message)
        else:
            bot.answer_callback_query(call.id, "❌ Вы не подписаны на все каналы!", show_alert=True)
        return
    
    if not check_subscription(user_id) and user_id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Сначала подпишитесь на каналы!")
        return
    
    # ==================== ГЛАВНОЕ МЕНЮ ====================
    if call.data == "back_main":
        if user_id in user_states:
            del user_states[user_id]
        if user_id in admin_states:
            del admin_states[user_id]
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
        send_main_menu(chat_id)
        return
    
    # ==================== СВЯЗЬ С АДМИНОМ ====================
    elif call.data == "contact_admin":
        user_states[user_id] = {"action": "write_to_admin"}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Отмена", callback_data="back_main"))
        
        bot.edit_message_text(
            "👤 <b>Связь с администратором</b>\n\n"
            "📝 Напишите ваше сообщение, и оно будет отправлено администратору.\n\n"
            "💬 Просто отправьте текст сообщения:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    # Админ отвечает пользователю
    elif call.data.startswith("reply_to_"):
        if user_id != ADMIN_ID:
            return
        target_user_id = int(call.data.replace("reply_to_", ""))
        admin_states[user_id] = {"action": "reply_to_user", "target_user": target_user_id}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel"))
        
        bot.send_message(
            chat_id,
            f"📝 <b>Ответ пользователю {target_user_id}</b>\n\nНапишите ваш ответ:",
            parse_mode="HTML",
            reply_markup=markup
        )
    
    # ==================== ПРИВАТ КАНАЛЫ ====================
    elif call.data == "private_channels":
        bot.edit_message_text(
            "🔒 <b>Приватные группы и каналы</b>\n\n🎮 Выбери игру:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=games_menu("channel")
        )
    
    elif call.data.startswith("channel_"):
        game = call.data.replace("channel_", "")
        channels = GAME_CHANNELS.get(game, [])
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        for ch in channels:
            markup.add(types.InlineKeyboardButton(ch['name'], url=ch['url']))
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="private_channels"))
        
        bot.edit_message_text(
            f"📱 <b>{GAME_NAMES.get(game, game)}</b>\n\n🔥 Вот топовые каналы для тебя:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    # ==================== ТОВАРЫ ====================
    elif call.data == "products":
        text = """
🛒 <b>МАГАЗИН ТОВАРОВ</b> 🛒

🔥 Йоу, геймер! Ты попал в самое крутое место!

💎 Здесь ты сможешь заполучить:
• ЭКСКЛЮЗИВНЫЕ читы
• РАБОЧИЕ моды
• СВЕЖИЕ обновления

⚡ Все товары проверены и работают!
🎁 Новинки добавляются регулярно!

🎮 <b>Выбирай свою игру:</b>
"""
        try:
            bot.edit_message_text(
                text,
                chat_id,
                message_id,
                parse_mode="HTML",
                reply_markup=games_menu("product")
            )
        except:
            try:
                bot.delete_message(chat_id, message_id)
            except:
                pass
            bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=games_menu("product"))
    
    elif call.data.startswith("product_"):
        game = call.data.replace("product_", "")
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
        show_game_products(chat_id, game)
    
    # Просмотр товара
    elif call.data.startswith("view_"):
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        products = get_products()
        
        if game in products and idx < len(products[game]):
            prod = products[game][idx]
            
            markup = types.InlineKeyboardMarkup(row_width=1)
            if prod.get('button_text') and prod.get('button_url'):
                markup.add(types.InlineKeyboardButton(prod['button_text'], url=prod['button_url']))
            markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data=f"backprod_{game}"))
            
            try:
                bot.delete_message(chat_id, message_id)
            except:
                pass
            
            caption = f"📦 <b>{prod['name']}</b>\n\n{prod['description']}"
            
            if prod.get('photo'):
                bot.send_photo(chat_id, prod['photo'], caption=caption, parse_mode="HTML", reply_markup=markup)
            elif prod.get('video'):
                bot.send_video(chat_id, prod['video'], caption=caption, parse_mode="HTML", reply_markup=markup)
            else:
                bot.send_message(chat_id, caption, parse_mode="HTML", reply_markup=markup)
    
    # Кнопка назад из товара (ИСПРАВЛЕНО)
    elif call.data.startswith("backprod_"):
        game = call.data.replace("backprod_", "")
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
        show_game_products(chat_id, game)
    
    # ==================== АДМИН: ДОБАВИТЬ ТОВАР ====================
    elif call.data == "admin_add_product":
        if user_id != ADMIN_ID:
            return
        admin_states[user_id] = {"action": "add_product", "step": "game"}
        bot.edit_message_text(
            "➕ <b>Создание товара</b>\n\nВыберите игру:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=games_menu("addprod")
        )
    
    elif call.data.startswith("addprod_"):
        if user_id != ADMIN_ID:
            return
        game = call.data.replace("addprod_", "")
        admin_states[user_id] = {"action": "add_product", "step": "name", "game": game}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel"))
        
        bot.edit_message_text(
            f"➕ <b>Создание товара для {GAME_NAMES.get(game, game)}</b>\n\n📝 Введите название товара:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    # ==================== АДМИН: РЕДАКТИРОВАТЬ ТОВАР ====================
    elif call.data == "admin_edit_product":
        if user_id != ADMIN_ID:
            return
        bot.edit_message_text(
            "✏️ <b>Редактирование товара</b>\n\nВыберите игру:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=games_menu("editgame")
        )
    
    elif call.data.startswith("editgame_"):
        if user_id != ADMIN_ID:
            return
        game = call.data.replace("editgame_", "")
        products = get_products()
        game_products = products.get(game, [])
        
        if not game_products:
            bot.answer_callback_query(call.id, "Нет товаров для редактирования", show_alert=True)
            return
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        for i, prod in enumerate(game_products):
            markup.add(types.InlineKeyboardButton(f"✏️ {prod['name']}", callback_data=f"editprod_{game}_{i}"))
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="admin_edit_product"))
        
        bot.edit_message_text(
            f"✏️ <b>Выберите товар для редактирования</b>\n\n🎮 {GAME_NAMES.get(game, game)}:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    elif call.data.startswith("editprod_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        
        products = get_products()
        if game in products and idx < len(products[game]):
            prod = products[game][idx]
            
            markup = types.InlineKeyboardMarkup(row_width=1)
            markup.add(
                types.InlineKeyboardButton("📝 Изменить название", callback_data=f"editname_{game}_{idx}"),
                types.InlineKeyboardButton("📄 Изменить описание", callback_data=f"editdesc_{game}_{idx}"),
                types.InlineKeyboardButton("📷 Изменить фото/видео", callback_data=f"editmedia_{game}_{idx}"),
                types.InlineKeyboardButton("🔗 Изменить кнопку", callback_data=f"editbtn_{game}_{idx}"),
                types.InlineKeyboardButton("🔔 Уведомить всех об этом товаре", callback_data=f"notifyprod_{game}_{idx}"),
                types.InlineKeyboardButton("🔙 Назад", callback_data=f"editgame_{game}")
            )
            
            text = f"✏️ <b>Редактирование товара</b>\n\n"
            text += f"📦 Название: {prod['name']}\n"
            text += f"📄 Описание: {prod['description'][:100]}...\n" if len(prod.get('description', '')) > 100 else f"📄 Описание: {prod.get('description', 'Нет')}\n"
            text += f"📷 Медиа: {'Есть фото' if prod.get('photo') else 'Есть видео' if prod.get('video') else 'Нет'}\n"
            text += f"🔗 Кнопка: {prod.get('button_text', 'Нет')}\n\nВыберите что изменить:"
            
            bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=markup)
    
    # Изменить название
    elif call.data.startswith("editname_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        admin_states[user_id] = {"action": "edit_name", "game": game, "idx": idx}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data=f"editprod_{game}_{idx}"))
        
        bot.edit_message_text("📝 Введите новое название товара:", chat_id, message_id, reply_markup=markup)
    
    # Изменить описание
    elif call.data.startswith("editdesc_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        admin_states[user_id] = {"action": "edit_desc", "game": game, "idx": idx}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data=f"editprod_{game}_{idx}"))
        
        bot.edit_message_text("📄 Введите новое описание товара:", chat_id, message_id, reply_markup=markup)
    
    # Изменить медиа
    elif call.data.startswith("editmedia_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        admin_states[user_id] = {"action": "edit_media", "game": game, "idx": idx}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(
            types.InlineKeyboardButton("🗑 Удалить медиа", callback_data=f"delmedia_{game}_{idx}"),
            types.InlineKeyboardButton("❌ Отмена", callback_data=f"editprod_{game}_{idx}")
        )
        
        bot.edit_message_text("📷 Отправьте новое фото или видео:", chat_id, message_id, reply_markup=markup)
    
    # Удалить медиа
    elif call.data.startswith("delmedia_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        
        products = get_products()
        if game in products and idx < len(products[game]):
            products[game][idx]['photo'] = None
            products[game][idx]['video'] = None
            save_products(products)
            bot.answer_callback_query(call.id, "✅ Медиа удалено!")
        
        if user_id in admin_states:
            del admin_states[user_id]
        
        # Вернуться к редактированию товара
        callback_handler(type('obj', (object,), {'data': f'editprod_{game}_{idx}', 'from_user': call.from_user, 'message': call.message, 'id': call.id})())
    
    # Изменить кнопку
    elif call.data.startswith("editbtn_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        admin_states[user_id] = {"action": "edit_button", "game": game, "idx": idx}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(
            types.InlineKeyboardButton("🗑 Удалить кнопку", callback_data=f"delbtn_{game}_{idx}"),
            types.InlineKeyboardButton("❌ Отмена", callback_data=f"editprod_{game}_{idx}")
        )
        
        bot.edit_message_text(
            "🔗 Введите текст кнопки и ссылку через |\nПример: Купить|https://example.com",
            chat_id, message_id, reply_markup=markup
        )
    
    # Удалить кнопку
    elif call.data.startswith("delbtn_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        
        products = get_products()
        if game in products and idx < len(products[game]):
            products[game][idx]['button_text'] = None
            products[game][idx]['button_url'] = None
            save_products(products)
            bot.answer_callback_query(call.id, "✅ Кнопка удалена!")
        
        if user_id in admin_states:
            del admin_states[user_id]
        
        callback_handler(type('obj', (object,), {'data': f'editprod_{game}_{idx}', 'from_user': call.from_user, 'message': call.message, 'id': call.id})())
    
    # УВЕДОМИТЬ ВСЕХ О ТОВАРЕ
    elif call.data.startswith("notifyprod_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        
        products = get_products()
        if game in products and idx < len(products[game]):
            prod = products[game][idx]
            users = get_users()
            success = 0
            
            notify_text = f"🆕 <b>НОВЫЙ ТОВАР!</b>\n\n"
            notify_text += f"🎮 Игра: {GAME_NAMES.get(game, game)}\n"
            notify_text += f"📦 Название: {prod['name']}\n\n"
            notify_text += f"🔥 Заходи в бота и смотри!"
            
            for uid in users:
                try:
                    if prod.get('photo'):
                        bot.send_photo(uid, prod['photo'], caption=notify_text, parse_mode="HTML")
                    elif prod.get('video'):
                        bot.send_video(uid, prod['video'], caption=notify_text, parse_mode="HTML")
                    else:
                        bot.send_message(uid, notify_text, parse_mode="HTML")
                    success += 1
                    time.sleep(0.05)
                except:
                    pass
            
            bot.answer_callback_query(call.id, f"✅ Уведомление отправлено {success} пользователям!", show_alert=True)
    
    # Выбор уведомления при создании
    elif call.data == "notify_yes":
        if user_id != ADMIN_ID or user_id not in admin_states:
            return
        save_product_from_state(user_id, admin_states[user_id], notify=True)
        bot.answer_callback_query(call.id, "✅ Товар создан и отправлено уведомление!")
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
    
    elif call.data == "notify_no":
        if user_id != ADMIN_ID or user_id not in admin_states:
            return
        save_product_from_state(user_id, admin_states[user_id], notify=False)
        bot.answer_callback_query(call.id, "✅ Товар создан без уведомления!")
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
    
    # ==================== РАССЫЛКА ====================
    elif call.data == "admin_broadcast":
        if user_id != ADMIN_ID:
            return
        admin_states[user_id] = {"action": "broadcast"}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel"))
        
        bot.edit_message_text(
            "📢 <b>Рассылка</b>\n\nОтправьте сообщение (текст, фото или видео) для рассылки всем пользователям:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    # ==================== КАНАЛЫ ПОДПИСКИ ====================
    elif call.data == "admin_add_channel":
        if user_id != ADMIN_ID:
            return
        admin_states[user_id] = {"action": "add_channel", "step": "id"}
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel"))
        
        bot.edit_message_text(
            "📌 <b>Добавление канала для обязательной подписки</b>\n\nОтправьте ID канала (например: -1001234567890)\n\n⚠️ Бот должен быть администратором канала!",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    elif call.data == "admin_del_channel":
        if user_id != ADMIN_ID:
            return
        channels = get_required_channels()
        
        if not channels:
            bot.answer_callback_query(call.id, "Нет каналов для удаления", show_alert=True)
            return
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        for i, ch in enumerate(channels):
            markup.add(types.InlineKeyboardButton(f"🗑 {ch['name']}", callback_data=f"delch_{i}"))
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="admin_back"))
        
        bot.edit_message_text(
            "🗑 <b>Удаление канала</b>\n\nВыберите канал для удаления:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )
    
    elif call.data.startswith("delch_"):
        if user_id != ADMIN_ID:
            return
        idx = int(call.data.replace("delch_", ""))
        channels = get_required_channels()
        
        if idx < len(channels):
            deleted = channels.pop(idx)
            save_required_channels(channels)
            bot.answer_callback_query(call.id, f"✅ Канал {deleted['name']} удалён!")
        
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
        admin_handler(call.message)
    
    elif call.data == "admin_list_channels":
        if user_id != ADMIN_ID:
            return
        channels = get_required_channels()
        
        if not channels:
            text = "📋 <b>Каналы для подписки</b>\n\nСписок пуст"
        else:
            text = "📋 <b>Каналы для обязательной подписки:</b>\n\n"
            for i, ch in enumerate(channels, 1):
                text += f"{i}. {ch['name']}\n   ID: {ch['id']}\n   URL: {ch['url']}\n\n"
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="admin_back"))
        
        bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=markup)
    
    # ==================== УДАЛИТЬ ТОВАР ====================
    elif call.data == "admin_del_product":
        if user_id != ADMIN_ID:
            return
        bot.edit_message_text(
            "🗑 <b>Удаление товара</b>\n\nВыберите игру:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=games_menu("delprod")
        )
    
    elif call.data.startswith("delprod_"):
        if user_id != ADMIN_ID:
            return
        game = call.data.replace("delprod_", "")
        products = get_products()
        game_products = products.get(game, [])
        
        if not game_products:
            bot.answer_callback_query(call.id, "Нет товаров для удаления", show_alert=True)
            return
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        for i, prod in enumerate(game_products):
            markup.add(types.InlineKeyboardButton(f"🗑 {prod['name']}", callback_data=f"rmprod_{game}_{i}"))
        markup.add(types.InlineKeyboardButton("🔙 Назад", callback_data="admin_del_product"))
        
        bot.edit_message_text(
            "🗑 Выберите товар для удаления:",
            chat_id,
            message_id,
            reply_markup=markup
        )
    
    elif call.data.startswith("rmprod_"):
        if user_id != ADMIN_ID:
            return
        parts = call.data.split("_")
        game = parts[1]
        idx = int(parts[2])
        
        products = get_products()
        if game in products and idx < len(products[game]):
            deleted = products[game].pop(idx)
            save_products(products)
            bot.answer_callback_query(call.id, f"✅ Товар {deleted['name']} удалён!")
        
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
        admin_handler(call.message)
    
    # ==================== ОТМЕНА И НАЗАД ====================
    elif call.data == "admin_cancel":
        if user_id in admin_states:
            del admin_states[user_id]
        try:
            bot.delete_message(chat_id, message_id)
        except:
            pass
        admin_handler(call.message)
    
    elif call.data == "admin_back":
        bot.edit_message_text(
            "🔐 <b>Панель администратора</b>\n\nВыберите действие:",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=admin_menu()
        )
    
    # Пропуск медиа
    elif call.data == "skip_media":
        if user_id not in admin_states:
            return
        state = admin_states[user_id]
        state['step'] = 'button'
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("⏭ Пропустить", callback_data="skip_button"))
        
        bot.edit_message_text(
            "🔗 Введите текст кнопки и ссылку через |\nПример: Купить|https://example.com\n\n(или нажмите Пропустить):",
            chat_id,
            message_id,
            reply_markup=markup
        )
    
    # Пропуск кнопки
    elif call.data == "skip_button":
        if user_id not in admin_states:
            return
        state = admin_states[user_id]
        state['step'] = 'notify'
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("✅ Да, уведомить всех", callback_data="notify_yes"),
            types.InlineKeyboardButton("❌ Нет, добавить тихо", callback_data="notify_no")
        )
        
        bot.edit_message_text(
            "🔔 <b>Уведомление</b>\n\nОтправить уведомление всем пользователям о новом товаре?",
            chat_id,
            message_id,
            parse_mode="HTML",
            reply_markup=markup
        )

# ==================== ОБРАБОТКА СООБЩЕНИЙ ====================
@bot.message_handler(content_types=['text', 'photo', 'video'])
def message_handler(message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    # Сообщение от пользователя к админу
    if user_id in user_states and user_states[user_id].get('action') == 'write_to_admin':
        del user_states[user_id]
        
        username = message.from_user.username
        first_name = message.from_user.first_name or ""
        last_name = message.from_user.last_name or ""
        full_name = f"{first_name} {last_name}".strip()
        
        user_info = f"👤 <b>Сообщение от пользователя</b>\n\n"
        user_info += f"📛 Имя: {full_name}\n"
        if username:
            user_info += f"📧 Username: @{username}\n"
        user_info += f"🆔 ID: <code>{user_id}</code>\n\n"
        user_info += f"💬 <b>Сообщение:</b>\n"
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("📝 Ответить", callback_data=f"reply_to_{user_id}"))
        
        try:
            if message.photo:
                bot.send_photo(
                    ADMIN_ID,
                    message.photo[-1].file_id,
                    caption=user_info + (message.caption or "[Фото без текста]"),
                    parse_mode="HTML",
                    reply_markup=markup
                )
            elif message.video:
                bot.send_video(
                    ADMIN_ID,
                    message.video.file_id,
                    caption=user_info + (message.caption or "[Видео без текста]"),
                    parse_mode="HTML",
                    reply_markup=markup
                )
            else:
                bot.send_message(
                    ADMIN_ID,
                    user_info + message.text,
                    parse_mode="HTML",
                    reply_markup=markup
                )
            
            bot.send_message(
                chat_id,
                "✅ <b>Сообщение отправлено администратору!</b>\n\nОжидайте ответа.",
                parse_mode="HTML",
                reply_markup=main_menu()
            )
        except:
            bot.send_message(chat_id, "❌ Ошибка при отправке. Попробуйте позже.", reply_markup=main_menu())
        return
    
    # Ответ админа пользователю
    if user_id == ADMIN_ID and user_id in admin_states:
        state = admin_states[user_id]
        
        if state.get('action') == 'reply_to_user':
            target_user = state['target_user']
            del admin_states[user_id]
            
            try:
                reply_text = "📩 <b>Ответ от администратора:</b>\n\n"
                
                if message.photo:
                    bot.send_photo(target_user, message.photo[-1].file_id, caption=reply_text + (message.caption or ""), parse_mode="HTML")
                elif message.video:
                    bot.send_video(target_user, message.video.file_id, caption=reply_text + (message.caption or ""), parse_mode="HTML")
                else:
                    bot.send_message(target_user, reply_text + message.text, parse_mode="HTML")
                
                bot.send_message(chat_id, f"✅ Ответ отправлен пользователю {target_user}!")
            except Exception as e:
                bot.send_message(chat_id, f"❌ Не удалось отправить: {e}")
            return
        
        # Редактирование названия
        if state.get('action') == 'edit_name':
            game = state['game']
            idx = state['idx']
            products = get_products()
            
            if game in products and idx < len(products[game]):
                products[game][idx]['name'] = message.text
                save_products(products)
                bot.send_message(chat_id, "✅ Название обновлено!")
            
            del admin_states[user_id]
            return
        
        # Редактирование описания
        if state.get('action') == 'edit_desc':
            game = state['game']
            idx = state['idx']
            products = get_products()
            
            if game in products and idx < len(products[game]):
                products[game][idx]['description'] = message.text
                save_products(products)
                bot.send_message(chat_id, "✅ Описание обновлено!")
            
            del admin_states[user_id]
            return
        
        # Редактирование медиа
        if state.get('action') == 'edit_media':
            game = state['game']
            idx = state['idx']
            products = get_products()
            
            if game in products and idx < len(products[game]):
                if message.photo:
                    products[game][idx]['photo'] = message.photo[-1].file_id
                    products[game][idx]['video'] = None
                elif message.video:
                    products[game][idx]['video'] = message.video.file_id
                    products[game][idx]['photo'] = None
                save_products(products)
                bot.send_message(chat_id, "✅ Медиа обновлено!")
            
            del admin_states[user_id]
            return
        
        # Редактирование кнопки
        if state.get('action') == 'edit_button':
            game = state['game']
            idx = state['idx']
            products = get_products()
            
            if '|' in message.text and game in products and idx < len(products[game]):
                parts = message.text.split('|', 1)
                products[game][idx]['button_text'] = parts[0].strip()
                products[game][idx]['button_url'] = parts[1].strip()
                save_products(products)
                bot.send_message(chat_id, "✅ Кнопка обновлена!")
            else:
                bot.send_message(chat_id, "❌ Неверный формат. Используйте: Текст|Ссылка")
            
            del admin_states[user_id]
            return
    
    # Обработка админских действий
    if user_id not in admin_states:
        return
    
    state = admin_states[user_id]
    
    # Добавление товара
    if state.get('action') == 'add_product':
        if state['step'] == 'name':
            state['name'] = message.text
            state['step'] = 'description'
            bot.send_message(chat_id, "📝 Введите описание товара:")
        
        elif state['step'] == 'description':
            state['description'] = message.text
            state['step'] = 'media'
            
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("⏭ Пропустить", callback_data="skip_media"))
            
            bot.send_message(chat_id, "📷 Отправьте фото или видео товара (или нажмите Пропустить):", reply_markup=markup)
        
        elif state['step'] == 'media':
            if message.photo:
                state['photo'] = message.photo[-1].file_id
            elif message.video:
                state['video'] = message.video.file_id
            
            state['step'] = 'button'
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("⏭ Пропустить", callback_data="skip_button"))
            
            bot.send_message(chat_id, "🔗 Введите текст кнопки и ссылку через |\nПример: Купить|https://example.com\n\n(или нажмите Пропустить):", reply_markup=markup)
        
        elif state['step'] == 'button':
            if '|' in message.text:
                parts = message.text.split('|', 1)
                state['button_text'] = parts[0].strip()
                state['button_url'] = parts[1].strip()
            
            state['step'] = 'notify'
            markup = types.InlineKeyboardMarkup(row_width=1)
            markup.add(
                types.InlineKeyboardButton("✅ Да, уведомить всех", callback_data="notify_yes"),
                types.InlineKeyboardButton("❌ Нет, добавить тихо", callback_data="notify_no")
            )
            
            bot.send_message(chat_id, "🔔 <b>Уведомление</b>\n\nОтправить уведомление всем пользователям о новом товаре?", parse_mode="HTML", reply_markup=markup)
    
    # Добавление канала
    elif state.get('action') == 'add_channel':
        if state['step'] == 'id':
            try:
                channel_id = int(message.text)
                state['channel_id'] = channel_id
                state['step'] = 'name'
                bot.send_message(chat_id, "📝 Введите название канала:")
            except:
                bot.send_message(chat_id, "❌ Неверный ID. Введите числовой ID канала:")
        
        elif state['step'] == 'name':
            state['channel_name'] = message.text
            state['step'] = 'url'
            bot.send_message(chat_id, "🔗 Введите ссылку на канал (например: https://t.me/channel):")
        
        elif state['step'] == 'url':
            channels = get_required_channels()
            channels.append({
                'id': state['channel_id'],
                'name': state['channel_name'],
                'url': message.text
            })
            save_required_channels(channels)
            
            del admin_states[user_id]
            bot.send_message(chat_id, "✅ Канал добавлен для обязательной подписки!")
            admin_handler(message)
    
    # Рассылка
    elif state.get('action') == 'broadcast':
        users = get_users()
        success = 0
        fail = 0
        
        for uid in users:
            try:
                if message.photo:
                    bot.send_photo(uid, message.photo[-1].file_id, caption=message.caption)
                elif message.video:
                    bot.send_video(uid, message.video.file_id, caption=message.caption)
                else:
                    bot.send_message(uid, message.text)
                success += 1
                time.sleep(0.05)
            except:
                fail += 1
        
        del admin_states[user_id]
        bot.send_message(chat_id, f"📢 <b>Рассылка завершена!</b>\n\n✅ Успешно: {success}\n❌ Ошибок: {fail}", parse_mode="HTML")

# ==================== СОХРАНЕНИЕ ТОВАРА ====================
def save_product_from_state(user_id, state, notify=False):
    products = get_products()
    game = state['game']
    
    if game not in products:
        products[game] = []
    
    product = {
        'name': state.get('name', 'Без названия'),
        'description': state.get('description', ''),
        'photo': state.get('photo'),
        'video': state.get('video'),
        'button_text': state.get('button_text'),
        'button_url': state.get('button_url')
    }
    
    products[game].append(product)
    save_products(products)
    
    if notify:
        users = get_users()
        notify_text = f"🆕 <b>НОВЫЙ ТОВАР!</b>\n\n"
        notify_text += f"🎮 Игра: {GAME_NAMES.get(game, game)}\n"
        notify_text += f"📦 Название: {product['name']}\n\n"
        notify_text += f"🔥 Заходи в бота и смотри!"
        
        for uid in users:
            try:
                if product.get('photo'):
                    bot.send_photo(uid, product['photo'], caption=notify_text, parse_mode="HTML")
                elif product.get('video'):
                    bot.send_video(uid, product['video'], caption=notify_text, parse_mode="HTML")
                else:
                    bot.send_message(uid, notify_text, parse_mode="HTML")
                time.sleep(0.05)
            except:
                pass
    
    if user_id in admin_states:
        del admin_states[user_id]
    
    bot.send_message(user_id, "✅ Товар успешно создан!")

# ==================== ЗАПУСК БОТА ====================
if __name__ == "__main__":
    print("🤖 Бот запущен!")
    print(f"📁 Данные сохраняются в: {DATA_FOLDER}")
    bot.infinity_polling()
