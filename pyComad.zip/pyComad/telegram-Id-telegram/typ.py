import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext, CallbackQueryHandler
import re

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Ваш ID для отладки
YOUR_USER_ID = 8550701850  # Замените на ваш реальный ID

# Хранилище для пользователей (в реальном приложении используйте базу данных)
users_database = {}

async def start(update: Update, context: CallbackContext) -> None:
    """Обработчик команды /start"""
    user = update.effective_user
    
    # Сохраняем пользователя в "базу данных"
    users_database[user.id] = {
        'username': user.username,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'chat_id': update.effective_chat.id
    }
    
    welcome_text = (
        f"👋 Привет, {user.first_name}!\n\n"
        "Я бот для поиска и начала чата с пользователями.\n\n"
        "📋 Доступные команды:\n"
        "/start - Начать работу\n"
        "/find - Найти пользователя\n"
        "/help - Помощь\n\n"
        "🔍 Чтобы найти пользователя:\n"
        "1. Используйте /find username\n"
        "2. Или просто отправьте username/ID пользователя"
    )
    
    await update.message.reply_text(welcome_text)

async def help_command(update: Update, context: CallbackContext) -> None:
    """Обработчик команды /help"""
    help_text = (
        "🤖 **Как использовать бота:**\n\n"
        "**Поиск пользователей:**\n"
        "• Отправьте `/find username` (например: `/find @username` или `/find username`)\n"
        "• Или просто отправьте username (например: `@username` или `username`)\n"
        "• Можно искать по ID пользователя (например: `123456789`)\n\n"
        "**Формат username:**\n"
        "• Без @ (можно с @ - бот сам уберет)\n"
        "• Только латинские буквы, цифры и подчеркивание\n\n"
        "**Важно:** Пользователь должен был хотя бы раз запустить этого бота (/start)"
    )
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def find_user(update: Update, context: CallbackContext) -> None:
    """Обработчик команды /find"""
    if not context.args:
        await update.message.reply_text(
            "Введите username после команды:\n"
            "Пример: `/find username` или `/find @username`",
            parse_mode='Markdown'
        )
        return
    
    search_query = context.args[0]
    await search_and_show_users(update, search_query, context)

async def handle_message(update: Update, context: CallbackContext) -> None:
    """Обработчик текстовых сообщений (для поиска по username/ID)"""
    text = update.message.text.strip()
    
    # Если сообщение похоже на username или ID
    if re.match(r'^(@?[a-zA-Z0-9_]{5,32})$|^(\d+)$', text):
        # Убираем @ если есть
        if text.startswith('@'):
            search_query = text[1:]
        else:
            search_query = text
        
        await search_and_show_users(update, search_query, context)
    else:
        # Если это не поиск, показываем подсказку
        await update.message.reply_text(
            "Для поиска пользователя отправьте:\n"
            "• Username (например: `username` или `@username`)\n"
            "• ID пользователя (только цифры)\n"
            "• Или используйте команду `/find username`",
            parse_mode='Markdown'
        )

async def search_and_show_users(update: Update, search_query: str, context: CallbackContext) -> None:
    """Поиск пользователей и отображение результатов"""
    found_users = []
    
    # Поиск по username (без учета регистра)
    for user_id, user_data in users_database.items():
        if user_data['username'] and search_query.lower() in user_data['username'].lower():
            found_users.append((user_id, user_data))
    
    # Если не нашли по username, пробуем поиск по ID
    if not found_users and search_query.isdigit():
        user_id = int(search_query)
        if user_id in users_database:
            found_users.append((user_id, users_database[user_id]))
    
    if not found_users:
        await update.message.reply_text(
            f"❌ Пользователь `{search_query}` не найден.\n\n"
            "Возможные причины:\n"
            "1. Пользователь еще не запускал этого бота\n"
            "2. Неправильный username/ID\n"
            "3. Пользователь не имеет username",
            parse_mode='Markdown'
        )
        return
    
    # Отображаем найденных пользователей
    if len(found_users) == 1:
        user_id, user_data = found_users[0]
        await show_user_profile(update, user_id, user_data, context)
    else:
        # Если найдено несколько пользователей
        keyboard = []
        for user_id, user_data in found_users[:10]:  # Ограничиваем 10 результатами
            display_name = user_data['username'] or f"User {user_id}"
            keyboard.append([
                InlineKeyboardButton(
                    f"👤 {display_name}",
                    callback_data=f"profile_{user_id}"
                )
            ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            f"🔍 Найдено пользователей: {len(found_users)}\n"
            "Выберите одного из списка:",
            reply_markup=reply_markup
        )

async def show_user_profile(update: Update, user_id: int, user_data: dict, context: CallbackContext) -> None:
    """Показать профиль пользователя и кнопку для начала чата"""
    # Формируем информацию о пользователе
    profile_text = (
        f"👤 **Найден пользователь:**\n\n"
        f"🆔 ID: `{user_id}`\n"
        f"📛 Username: @{user_data['username'] if user_data['username'] else 'Нет username'}\n"
        f"👨‍💼 Имя: {user_data['first_name'] or 'Не указано'}\n"
        f"👨‍💼 Фамилия: {user_data['last_name'] or 'Не указано'}\n"
    )
    
    # Создаем кнопки
    keyboard = [
        [
            InlineKeyboardButton("💬 Начать чат", callback_data=f"chat_{user_id}"),
            InlineKeyboardButton("📋 Информация", callback_data=f"info_{user_id}")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отправляем сообщение с профилем
    if update.callback_query:
        await update.callback_query.edit_message_text(
            profile_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(
            profile_text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )

async def button_callback(update: Update, context: CallbackContext) -> None:
    """Обработчик нажатий на кнопки"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data.startswith('profile_'):
        user_id = int(data.split('_')[1])
        if user_id in users_database:
            await show_user_profile(update, user_id, users_database[user_id], context)
    
    elif data.startswith('chat_'):
        user_id = int(data.split('_')[1])
        if user_id in users_database:
            target_user = users_database[user_id]
            chat_link = f"tg://user?id={user_id}"
            
            # Информация для начала чата
            chat_info = (
                f"✅ Готово! Вы можете начать чат с пользователем:\n\n"
                f"👤 Имя: {target_user['first_name'] or 'Не указано'}\n"
                f"📛 Username: @{target_user['username'] if target_user['username'] else 'Нет username'}\n"
                f"🆔 ID: `{user_id}`\n\n"
                f"🔗 **Ссылка для начала чата:**\n"
                f"[Нажмите здесь, чтобы написать]({chat_link})\n\n"
                f"📝 **Или используйте:**\n"
                f"• Нажмите на ссылку выше\n"
                f"• Или найдите в Telegram: @{target_user['username']}" if target_user['username'] else "• Или используйте ID для поиска"
            )
            
            await query.edit_message_text(
                chat_info,
                parse_mode='Markdown',
                disable_web_page_preview=False
            )
    
    elif data.startswith('info_'):
        user_id = int(data.split('_')[1])
        if user_id in users_database:
            user_data = users_database[user_id]
            info_text = (
                f"📊 **Дополнительная информация:**\n\n"
                f"🆔 ID: `{user_id}`\n"
                f"💬 Chat ID: `{user_data['chat_id']}`\n"
                f"📛 Username: @{user_data['username'] if user_data['username'] else 'Нет username'}\n"
                f"👨‍💼 Имя: {user_data['first_name'] or 'Не указано'}\n"
                f"👨‍💼 Фамилия: {user_data['last_name'] or 'Не указано'}\n\n"
                f"📅 Пользователь начал работу с ботом"
            )
            await query.edit_message_text(info_text, parse_mode='Markdown')

async def error_handler(update: Update, context: CallbackContext) -> None:
    """Обработчик ошибок"""
    logger.error(f"Ошибка: {context.error}", exc_info=context.error)
    
    if update and update.effective_message:
        await update.effective_message.reply_text(
            "❌ Произошла ошибка. Пожалуйста, попробуйте еще раз."
        )

def main() -> None:
    """Запуск бота"""
    # Токен вашего бота (замените на реальный)
    TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"
    
    # Создаем Application
    application = Application.builder().token(TOKEN).build()
    
    # Регистрируем обработчики команд
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("find", find_user))
    
    # Регистрируем обработчики сообщений
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Регистрируем обработчики кнопок
    application.add_handler(CallbackQueryHandler(button_callback))
    
    # Регистрируем обработчик ошибок
    application.add_error_handler(error_handler)
    
    # Запускаем бота
    print("Бот запущен...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()