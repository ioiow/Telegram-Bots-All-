import os
import json
import logging
from datetime import datetime
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)

# ==================== НАСТРОЙКИ ====================
BOT_TOKEN = "8148646095:AAGxn4EKl_5NCXMiLG2roRRrldAzSq5pOmw"
CHANNEL_USERNAME = "@StarOfficeOnline"
ADMIN_ID = 8550701850
WEBSITE_LINK = "https://t.me/StarsTelegramVip_Bot/web"
DATA_FILE = "/storage/emulated/0/Download/pyComad/Telegram-SellStarsVersion2/bot_data.json"  # Файл для хранения кнопок

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Глобальное хранилище для диалогов
user_dialogs = {}

# ==================== ХРАНИЛИЩЕ ДАННЫХ ====================
def load_data():
    """Загружает данные из файла"""
    default_data = {
        "custom_buttons": {},
        "help_buttons": [],
        "users": []
    }
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for key in default_data:
                    if key not in data:
                        data[key] = default_data[key]
                return data
    except Exception as e:
        logger.error(f"Ошибка загрузки данных: {e}")
    return default_data

def save_data():
    """Сохраняет данные в файл"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(bot_data, f, ensure_ascii=False, indent=2)
        logger.info("Данные сохранены успешно")
    except Exception as e:
        logger.error(f"Ошибка сохранения: {e}")

bot_data = load_data()
admin_state = {}

# ==================== КЛАВИАТУРЫ ====================
def get_main_keyboard():
    """Клавиатура с командами внизу экрана"""
    keyboard = [
        [KeyboardButton("🌐 Сайт")],
        [KeyboardButton("📝 Написать админу"), KeyboardButton("ℹ️ Помощь")],
        [KeyboardButton("📢 Проверить подписку")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_admin_keyboard():
    """Клавиатура для администратора"""
    keyboard = [
        [KeyboardButton("📋 Диалоги"), KeyboardButton("📊 Статистика")],
        [KeyboardButton("➕ Добавить кнопку"), KeyboardButton("🗑 Удалить кнопку")],
        [KeyboardButton("✏️ Изменить помощь"), KeyboardButton("📜 Список кнопок")],
        [KeyboardButton("📢 Рассылка"), KeyboardButton("🚫 Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_subscription_keyboard():
    """Инлайн-клавиатура для подписки"""
    keyboard = [
        [InlineKeyboardButton("📢 Подписаться на канал", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton("✅ Я подписался", callback_data="check_subscription")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_help_inline_keyboard():
    """Инлайн-кнопки для раздела помощи - ИСПРАВЛЕНО!"""
    buttons = []
    for btn_id, btn_info in bot_data.get("custom_buttons", {}).items():
        if btn_info.get("section") == "help":
            if btn_info.get("type") == "link":
                buttons.append([InlineKeyboardButton(btn_info["name"], url=btn_info["content"])])
            else:
                # ИСПРАВЛЕНО: используем btn_id напрямую, без добавления btn_
                buttons.append([InlineKeyboardButton(btn_info["name"], callback_data=btn_id)])
    return InlineKeyboardMarkup(buttons) if buttons else None

# ==================== ПРОВЕРКА ПОДПИСКИ ====================
async def check_subscription(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    try:
        chat_member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        return chat_member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Ошибка проверки подписки: {e}")
        return False

# ==================== ОБРАБОТЧИК /start ====================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # Сохраняем пользователя для рассылки
    if user_id not in bot_data["users"]:
        bot_data["users"].append(user_id)
        save_data()
    
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        await update.message.reply_text(
            "📢 Для использования бота необходимо подписаться на наш канал!\n"
            f"Канал: {CHANNEL_USERNAME}\n\n"
            "После подписки нажмите кнопку '✅ Я подписался'",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    await show_main_menu(update, context)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает главное меню"""
    user_id = update.effective_user.id
    
    # ИСПРАВЛЕНО: это должна быть строка, а не tuple
    welcome_text = (
        "👋 <b>Приветствую! Здравствуйте!</b>\n\n"
        "Воспользуйтесь нашим сайтом!\n\n"
        f"🌐 - <a href='{WEBSITE_LINK}'>Web</a>\n\n"
        "👇 <i>Используйте кнопки ниже для навигации</i>"
    )
    
    if str(user_id) == str(ADMIN_ID):
        await update.message.reply_text(
            welcome_text, 
            reply_markup=get_admin_keyboard(),
            parse_mode='HTML',
            disable_web_page_preview=True
        )
    else:
        await update.message.reply_text(
            welcome_text, 
            reply_markup=get_main_keyboard(),
            parse_mode='HTML',
            disable_web_page_preview=True
        )

# ==================== CALLBACK ПРОВЕРКИ ПОДПИСКИ ====================
async def check_subscription_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    is_subscribed = await check_subscription(user_id, context)
    
    if is_subscribed:
        # ИСПРАВЛЕНО: строка вместо tuple
        welcome_text = (
            "✅ <b>Подписка подтверждена!</b>\n\n"
            f"🌐 - <a href='{WEBSITE_LINK}'>Web</a>\n\n"
            "👇 <i>Используйте кнопки ниже для навигации</i>"
        )
        
        await query.edit_message_text(welcome_text, parse_mode='HTML', disable_web_page_preview=True)
        await context.bot.send_message(
            chat_id=user_id,
            text="Теперь вы можете использовать все функции бота:",
            reply_markup=get_main_keyboard()
        )
    else:
        await query.edit_message_text(
            "❌ Вы ещё не подписались на канал!\n"
            f"Пожалуйста, подпишитесь: {CHANNEL_USERNAME}\n"
            "и нажмите кнопку проверки снова.",
            reply_markup=get_subscription_keyboard()
        )

# ==================== ОБРАБОТКА КНОПКИ "НАПИСАТЬ АДМИНУ" ====================
async def handle_write_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    context.user_data['awaiting_admin_message'] = True
    
    await update.message.reply_text(
        "✍️ Напишите своё сообщение Администратору:\n\n"
        "Просто напишите текст сообщения и отправьте его.",
        parse_mode='HTML',
        reply_markup=ReplyKeyboardMarkup([[KeyboardButton("🚫 Отмена")]], resize_keyboard=True)
    )

# ==================== ОБРАБОТКА КНОПКИ "САЙТ" ====================
async def handle_website(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    keyboard = get_admin_keyboard() if str(user_id) == str(ADMIN_ID) else get_main_keyboard()
    
    await update.message.reply_text(
    f"🌐 <b>Наш сайт:</b>\n\n"
    f"Перейдите по ссылке: <a href='{WEBSITE_LINK}'>Web</a>",
    parse_mode='HTML',
    disable_web_page_preview=True,
    reply_markup=keyboard
)

# ==================== ОБРАБОТКА КНОПКИ "ПОМОЩЬ" ====================
async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    help_text = (
        "⭐ ПОМОЩЬ ПО ИСПОЛЬЗОВАНИЮ БОТА\n\n"
        "Данный бот предназначен для работы с системой Telegram Stars и предоставляет "
        "пользователям доступ к официальному сервису покупки и продажи звёзд Telegram. "
        "Все операции осуществляются через официальный сайт сервиса.\n\n"
        
        "📋 КАК ПОЛЬЗОВАТЬСЯ БОТОМ:\n"
        "1. Нажмите кнопку START для начала работы\n"
        "2. После запуска бота используйте кнопку 🌐 - Сайт на клавиатуре\n"
        "3. Перейдите по ссылке на официальный сайт сервиса\n"
        "4. Выберите необходимое количество Telegram Stars\n"
        "5. Следуйте инструкциям на сайте для завершения операции\n\n"
        
        "⚠️ ВАЖНАЯ ИНФОРМАЦИЯ:\n"
        "• Бот работает в рамках официального сервиса Telegram Stars\n"
        "• Бот не запрашивает и не хранит персональные данные пользователей\n"
        "• Все действия совершаются пользователем добровольно\n"
        "• Ответственность за использование сервиса лежит на пользователе\n\n"
        
        "🆘 ОСНОВНЫЕ ФУНКЦИИ:\n"
        "• Сайт - получить ссылку на официальный сайт сервиса\n"
        "• Написать админу - связь с администратором\n"
        "• Проверить подписку - проверить статус подписки на канал\n\n"
        "Все функции доступны после подписки на наш канал!\n"
        f"Канал: {CHANNEL_USERNAME}"
    )
    
    keyboard = get_admin_keyboard() if str(user_id) == str(ADMIN_ID) else get_main_keyboard()
    
    await update.message.reply_text(
        help_text,
        parse_mode='HTML',
        reply_markup=keyboard
    )
    
    # Добавляем инлайн-кнопки если они есть
    help_inline = get_help_inline_keyboard()
    if help_inline:
        await update.message.reply_text(
            "👇 Дополнительные материалы:",
            parse_mode='HTML',
            reply_markup=help_inline
        )

# ==================== ОБРАБОТКА КНОПКИ "ПРОВЕРИТЬ ПОДПИСКУ" ====================
async def handle_check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    is_subscribed = await check_subscription(user_id, context)
    
    keyboard = get_admin_keyboard() if str(user_id) == str(ADMIN_ID) else get_main_keyboard()
    
    if is_subscribed:
        await update.message.reply_text(
            "✅ Вы подписаны на канал!\n\nВы можете использовать все функции бота.",
            parse_mode='HTML',
            reply_markup=keyboard
        )
    else:
        await update.message.reply_text(
            f"❌ Вы не подписаны на канал!\n\nПожалуйста, подпишитесь: {CHANNEL_USERNAME}",
            reply_markup=get_subscription_keyboard()
        )

# ==================== ОБРАБОТКА КНОПКИ "ОТМЕНА" ====================
async def handle_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if 'awaiting_admin_message' in context.user_data:
        context.user_data['awaiting_admin_message'] = False
    
    if str(user_id) == str(ADMIN_ID):
        admin_state.clear()
        if 'admin_reply_mode' in context.user_data:
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
        await update.message.reply_text("🚫 Действие отменено", reply_markup=get_admin_keyboard())
    else:
        await update.message.reply_text("🚫 Действие отменено", reply_markup=get_main_keyboard())

# ==================== ДОБАВЛЕНИЕ КНОПКИ ====================
async def handle_add_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начинает процесс добавления кнопки"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    admin_state['action'] = 'add_button'
    admin_state['step'] = 1
    
    keyboard = [
        [InlineKeyboardButton("📍 В раздел Помощь", callback_data="section_help")],
    ]
    
    await update.message.reply_text(
        "➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
        "Шаг 1/4: Выберите раздел для кнопки:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_section_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора раздела"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    section = query.data.replace("section_", "")
    admin_state['section'] = section
    admin_state['step'] = 2
    
    keyboard = [
        [InlineKeyboardButton("🔗 Ссылка", callback_data="type_link")],
        [InlineKeyboardButton("📝 Текст", callback_data="type_text")],
        [InlineKeyboardButton("📸 Фото", callback_data="type_photo")],
        [InlineKeyboardButton("🎬 Видео", callback_data="type_video")],
        [InlineKeyboardButton("📄 Документ", callback_data="type_document")],
    ]
    
    await query.edit_message_text(
        f"➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
        f"✅ Раздел: {section}\n\n"
        "Шаг 2/4: Выберите тип контента:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_type_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора типа"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    btn_type = query.data.replace("type_", "")
    admin_state['type'] = btn_type
    admin_state['step'] = 3
    
    await query.edit_message_text(
        f"➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
        f"✅ Раздел: {admin_state['section']}\n"
        f"✅ Тип: {btn_type}\n\n"
        "Шаг 3/4: Введите название кнопки:\n"
        "(Например: 📹 Видео-туториал)",
        parse_mode='HTML'
    )

async def handle_admin_add_button_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ввода при добавлении кнопки"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    if admin_state.get('action') != 'add_button':
        return False
    
    step = admin_state.get('step', 0)
    text = update.message.text
    
    if step == 3:
        admin_state['name'] = text
        admin_state['step'] = 4
        
        type_hints = {
            "link": "Введите ссылку (https://...)",
            "text": "Введите текст сообщения",
            "photo": "Отправьте фото",
            "video": "Отправьте видео",
            "document": "Отправьте файл/документ"
        }
        
        await update.message.reply_text(
            f"➕ ДОБАВЛЕНИЕ КНОПКИ\n\n"
            f"✅ Раздел: {admin_state['section']}\n"
            f"✅ Тип: {admin_state['type']}\n"
            f"✅ Название: {admin_state['name']}\n\n"
            f"Шаг 4/4: {type_hints.get(admin_state['type'], 'Отправьте контент')}",
            parse_mode='HTML'
        )
        return True
    
    elif step == 4 and admin_state.get('type') in ['text', 'link']:
        await save_button(update, text)
        return True
    
    return False

async def handle_admin_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка медиа от админа"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    if admin_state.get('action') != 'add_button' or admin_state.get('step') != 4:
        return
    
    file_id = None
    btn_type = admin_state.get('type')
    
    if update.message.photo and btn_type == 'photo':
        file_id = update.message.photo[-1].file_id
    elif update.message.video and btn_type == 'video':
        file_id = update.message.video.file_id
    elif update.message.document and btn_type == 'document':
        file_id = update.message.document.file_id
    
    if file_id:
        admin_state['content'] = file_id
        admin_state['step'] = 5
        
        keyboard = [[InlineKeyboardButton("⏭ Без подписи", callback_data="skip_caption")]]
        
        await update.message.reply_text(
            "📝 Введите подпись к медиа (или нажмите 'Без подписи'):",
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def handle_caption_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка подписи к медиа"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    if admin_state.get('action') == 'add_button' and admin_state.get('step') == 5:
        await save_button(update, admin_state['content'], update.message.text)
        return True
    
    return False

async def skip_caption_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Пропуск подписи"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    if admin_state.get('action') == 'add_button' and admin_state.get('step') == 5:
        # ИСПРАВЛЕНО: генерируем ID с префиксом btn_
        btn_id = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        bot_data["custom_buttons"][btn_id] = {
            "name": admin_state['name'],
            "section": admin_state['section'],
            "type": admin_state['type'],
            "content": admin_state['content'],
            "caption": ""
        }
        save_data()
        
        await query.edit_message_text(
            f"✅ КНОПКА СОЗДАНА!\n\n"
            f"📌 Название: {admin_state['name']}\n"
            f"📍 Раздел: {admin_state['section']}\n"
            f"📦 Тип: {admin_state['type']}\n"
            f"🆔 ID: {btn_id}",
            parse_mode='HTML'
        )
        
        admin_state.clear()
        
        await context.bot.send_message(
            chat_id=query.from_user.id,
            text="Используйте панель управления:",
            reply_markup=get_admin_keyboard()
        )

async def save_button(update: Update, content: str, caption: str = ""):
    """Сохраняет кнопку"""
    # ID кнопки с префиксом btn_
    btn_id = f"btn_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    bot_data["custom_buttons"][btn_id] = {
        "name": admin_state['name'],
        "section": admin_state['section'],
        "type": admin_state['type'],
        "content": content,
        "caption": caption
    }
    save_data()
    
    await update.message.reply_text(
        f"✅ КНОПКА СОЗДАНА!\n\n"
        f"📌 Название: {admin_state['name']}\n"
        f"📍 Раздел: {admin_state['section']}\n"
        f"📦 Тип: {admin_state['type']}\n"
        f"🆔 ID: {btn_id}",
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )
    
    admin_state.clear()

# ==================== УДАЛЕНИЕ КНОПКИ ====================
async def handle_delete_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает список кнопок для удаления"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    buttons = bot_data.get("custom_buttons", {})
    
    if not buttons:
        await update.message.reply_text("📭 Нет кнопок для удаления", reply_markup=get_admin_keyboard())
        return
    
    keyboard = []
    for btn_id, btn_info in buttons.items():
        keyboard.append([InlineKeyboardButton(
            f"🗑 {btn_info['name']} ({btn_info['type']})",
            callback_data=f"delete_{btn_id}"
        )])
    
    await update.message.reply_text(
        "🗑 УДАЛЕНИЕ КНОПКИ\n\nВыберите кнопку для удаления:",
        parse_mode='HTML',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_delete_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Удаляет кнопку"""
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        return
    
    btn_id = query.data.replace("delete_", "")
    
    if btn_id in bot_data.get("custom_buttons", {}):
        btn_name = bot_data["custom_buttons"][btn_id]["name"]
        del bot_data["custom_buttons"][btn_id]
        save_data()
        
        await query.edit_message_text(f"✅ Кнопка «{btn_name}» удалена!", parse_mode='HTML')
    else:
        await query.edit_message_text("❌ Кнопка не найдена")

# ==================== СПИСОК КНОПОК ====================
async def handle_list_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает список всех кнопок"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    buttons = bot_data.get("custom_buttons", {})
    
    if not buttons:
        await update.message.reply_text("📭 Кнопок пока нет", reply_markup=get_admin_keyboard())
        return
    
    text = "📜 СПИСОК КНОПОК:\n\n"
    
    for btn_id, btn_info in buttons.items():
        text += f"🔘 {btn_info['name']}\n"
        text += f"   📍 Раздел: {btn_info['section']}\n"
        text += f"   📦 Тип: {btn_info['type']}\n"
        text += f"   🆔 {btn_id}\n\n"
    
    await update.message.reply_text(text, parse_mode='HTML', reply_markup=get_admin_keyboard())

# ==================== ИЗМЕНИТЬ ПОМОЩЬ ====================
async def handle_edit_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Информация о редактировании помощи"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    await update.message.reply_text(
        "✏️ РЕДАКТИРОВАНИЕ ПОМОЩИ\n\n"
        "⚠️ Текст помощи задан в коде бота.\n"
        "Но вы можете добавить кнопки с дополнительными материалами!\n\n"
        "Используйте ➕ Добавить кнопку чтобы добавить:\n"
        "• Видео-туториалы\n"
        "• Фото-инструкции\n"
        "• Ссылки на материалы\n"
        "• Документы",
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )

# ==================== РАССЫЛКА ====================
async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начинает рассылку"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    
    admin_state['action'] = 'broadcast'
    
    await update.message.reply_text(
        f"📢 РАССЫЛКА\n\n"
        f"Пользователей в базе: {len(bot_data['users'])}\n\n"
        "Отправьте сообщение для рассылки (текст, фото или видео):\n\n"
        "Для отмены нажмите 🚫 Отмена",
        parse_mode='HTML',
        reply_markup=get_admin_keyboard()
    )

async def handle_broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправляет рассылку"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        return False
    
    if admin_state.get('action') != 'broadcast':
        return False
    
    admin_state.clear()
    
    success = 0
    failed = 0
    
    status_msg = await update.message.reply_text("📤 Начинаю рассылку...")
    
    for user_id in bot_data["users"]:
        if user_id == ADMIN_ID:
            continue
        try:
            if update.message.photo:
                await context.bot.send_photo(
                    chat_id=user_id,
                    photo=update.message.photo[-1].file_id,
                    caption=update.message.caption or ""
                )
            elif update.message.video:
                await context.bot.send_video(
                    chat_id=user_id,
                    video=update.message.video.file_id,
                    caption=update.message.caption or ""
                )
            else:
                await context.bot.send_message(chat_id=user_id, text=update.message.text)
            success += 1
        except Exception as e:
            logger.error(f"Ошибка рассылки {user_id}: {e}")
            failed += 1
    
    await status_msg.edit_text(
        f"✅ Рассылка завершена!\n\n"
        f"✉️ Отправлено: {success}\n"
        f"❌ Ошибок: {failed}",
        parse_mode='HTML'
    )
    
    return True

# ==================== ОБРАБОТКА КАСТОМНЫХ КНОПОК - ИСПРАВЛЕНО! ====================
async def handle_custom_button_click(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие на кастомную кнопку"""
    query = update.callback_query
    await query.answer()
    
    # ИСПРАВЛЕНО: используем query.data напрямую как btn_id
    btn_id = query.data
    
    logger.info(f"Нажата кнопка: {btn_id}")
    logger.info(f"Доступные кнопки: {list(bot_data.get('custom_buttons', {}).keys())}")
    
    if btn_id not in bot_data.get("custom_buttons", {}):
        await query.message.reply_text(f"❌ Кнопка не найдена: {btn_id}")
        return
    
    btn_info = bot_data["custom_buttons"][btn_id]
    btn_type = btn_info.get("type")
    content = btn_info.get("content")
    caption = btn_info.get("caption", "")
    
    try:
        if btn_type == "photo":
            await context.bot.send_photo(
                chat_id=query.from_user.id, 
                photo=content, 
                caption=caption if caption else None,
                parse_mode='HTML'
            )
        elif btn_type == "video":
            await context.bot.send_video(
                chat_id=query.from_user.id, 
                video=content, 
                caption=caption if caption else None,
                parse_mode='HTML'
            )
        elif btn_type == "document":
            await context.bot.send_document(
                chat_id=query.from_user.id, 
                document=content, 
                caption=caption if caption else None,
                parse_mode='HTML'
            )
        elif btn_type == "text":
            await query.message.reply_text(content, parse_mode='HTML')
        
        logger.info(f"Контент отправлен успешно: {btn_type}")
        
    except Exception as e:
        logger.error(f"Ошибка отправки контента: {e}")
        await query.message.reply_text(f"❌ Ошибка загрузки контента: {str(e)}")

# ==================== ОБРАБОТКА ТЕКСТА ====================
async def handle_user_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    message_text = update.message.text
    
    # Если это админ
    if str(user_id) == str(ADMIN_ID):
        if await handle_admin_add_button_input(update, context):
            return
        if await handle_caption_input(update, context):
            return
        if await handle_broadcast_message(update, context):
            return
        await handle_admin_message(update, context)
        return
    
    # Пропускаем команды кнопок
    if message_text in ["🌐 Сайт", "📝 Написать админу", "ℹ️ Помощь", "📢 Проверить подписку", "🚫 Отмена"]:
        return
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text("❌ Сначала подпишитесь на канал!", reply_markup=get_subscription_keyboard())
        return
    
    # Если ожидает отправки сообщения админу
    if context.user_data.get('awaiting_admin_message', False):
        admin_message = (
            f"📩 Новое сообщение от пользователя:\n\n"
            f"👤 ID: {user_id}\n"
            f"📛 Имя: {user.full_name}\n"
            f"🔗 Username: @{user.username if user.username else 'нет'}\n"
            f"📝 Сообщение:\n───────\n{message_text}\n───────"
        )
        
        if user_id not in user_dialogs:
            user_dialogs[user_id] = []
        
        user_dialogs[user_id].append({
            "from_user": True,
            "text": message_text,
            "timestamp": str(update.message.date)
        })
        
        keyboard = [[InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user_id}")]]
        
        try:
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
            
            await update.message.reply_text(
                "✅ Ваше сообщение отправлено администратору!\n\nОжидайте ответа в этом чате.",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки админу: {e}")
            await update.message.reply_text("❌ Ошибка отправки сообщения.", reply_markup=get_main_keyboard())
        
        context.user_data['awaiting_admin_message'] = False
    else:
        await update.message.reply_text(
            "ℹ️ Используйте кнопки для навигации:\n\n"
            "• Нажмите 'Написать админу' для обращения\n"
            "• Нажмите 'Сайт' для перехода на сайт\n"
            "• Нажмите 'Помощь' для справки",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )

# ==================== ОБРАБОТКА СООБЩЕНИЙ АДМИНА ====================
async def handle_admin_reply_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if str(query.from_user.id) != str(ADMIN_ID):
        await query.answer("❌ Только администратор может отвечать!", show_alert=True)
        return
    
    data = query.data
    if data.startswith("reply_"):
        target_user_id = int(data.split("_")[1])
        
        context.user_data['admin_reply_mode'] = True
        context.user_data['target_user_id'] = target_user_id
        
        await query.message.reply_text(
            f"💬 Вы отвечаете пользователю (ID: {target_user_id})\n\nВведите ваш ответ:",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if str(user_id) != str(ADMIN_ID):
        return
    
    text = update.message.text
    
    # Обработка кнопок админа
    if text == "📋 Диалоги":
        await show_admin_dialogs(update, context)
        return
    elif text == "📊 Статистика":
        await show_admin_stats(update, context)
        return
    elif text == "➕ Добавить кнопку":
        await handle_add_button(update, context)
        return
    elif text == "🗑 Удалить кнопку":
        await handle_delete_button(update, context)
        return
    elif text == "✏️ Изменить помощь":
        await handle_edit_help(update, context)
        return
    elif text == "📜 Список кнопок":
        await handle_list_buttons(update, context)
        return
    elif text == "📢 Рассылка":
        await handle_broadcast(update, context)
        return
    elif text == "🚫 Отмена":
        admin_state.clear()
        context.user_data['admin_reply_mode'] = False
        context.user_data['target_user_id'] = None
        await update.message.reply_text("🚫 Действие отменено", reply_markup=get_admin_keyboard())
        return
    
    # Режим ответа пользователю
    if context.user_data.get('admin_reply_mode', False):
        target_user_id = context.user_data.get('target_user_id')
        
        if not target_user_id:
            await update.message.reply_text("❌ Ошибка: не найден пользователь")
            context.user_data['admin_reply_mode'] = False
            return
        
        try:
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"📨 Ответ от администратора:\n\n{text}",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            
            if target_user_id not in user_dialogs:
                user_dialogs[target_user_id] = []
            
            user_dialogs[target_user_id].append({
                "from_user": False,
                "text": text,
                "timestamp": str(update.message.date)
            })
            
            await update.message.reply_text(
                f"✅ Ответ отправлен пользователю (ID: {target_user_id})!",
                reply_markup=get_admin_keyboard()
            )
            
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
            
        except Exception as e:
            logger.error(f"Ошибка отправки: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}", reply_markup=get_admin_keyboard())
    else:
        await update.message.reply_text(
            "ℹ️ Вы администратор!\n\n"
            "Используйте кнопки для управления ботом.",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )

# ==================== ФУНКЦИИ АДМИНА ====================
async def show_admin_dialogs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not user_dialogs:
        await update.message.reply_text("📭 Нет активных диалогов", reply_markup=get_admin_keyboard())
        return
    
    message = "📋 Активные диалоги:\n\n"
    count = 1
    for uid, messages in user_dialogs.items():
        try:
            user_info = await context.bot.get_chat(uid)
            username = f"@{user_info.username}" if user_info.username else "нет"
            message += f"{count}. 👤 {user_info.full_name} ({username})\n"
            message += f"   🔹 ID: {uid}\n"
            message += f"   🔹 Сообщений: {len(messages)}\n\n"
            count += 1
        except:
            message += f"{count}. 👤 ID: {uid} - {len(messages)} сообщений\n\n"
            count += 1
    
    await update.message.reply_text(message, parse_mode='HTML', reply_markup=get_admin_keyboard())

async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    total_dialogs = len(user_dialogs)
    total_messages = sum(len(m) for m in user_dialogs.values())
    total_users = len(bot_data.get("users", []))
    total_buttons = len(bot_data.get("custom_buttons", {}))
    
    stats_text = (
        f"📊 Статистика бота:\n\n"
        f"👥 Пользователей в базе: {total_users}\n"
        f"💬 Активных диалогов: {total_dialogs}\n"
        f"✉️ Всего сообщений: {total_messages}\n"
        f"🔘 Кастомных кнопок: {total_buttons}"
    )
    
    await update.message.reply_text(stats_text, parse_mode='HTML', reply_markup=get_admin_keyboard())

# ==================== ОБРАБОТКА МЕДИА ====================
async def handle_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if str(user_id) == str(ADMIN_ID):
        if admin_state.get('action') == 'add_button' and admin_state.get('step') == 4:
            await handle_admin_media(update, context)
            return
        
        if admin_state.get('action') == 'broadcast':
            await handle_broadcast_message(update, context)
            return

# ==================== ОСНОВНАЯ ФУНКЦИЯ ====================
def main():
    print("=" * 50)
    print("🤖 Бот запущен!")
    print(f"👑 ID администратора: {ADMIN_ID}")
    print(f"📢 Канал для подписки: {CHANNEL_USERNAME}")
    print(f"📁 Файл данных: {DATA_FILE}")
    print("=" * 50)
    print("\n👑 Функции админа:")
    print("• ➕ Добавить кнопку")
    print("• 🗑 Удалить кнопку")
    print("• ✏️ Изменить помощь")
    print("• 📜 Список кнопок")
    print("• 📢 Рассылка")
    print("=" * 50)
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Команды
    application.add_handler(CommandHandler("start", start))
    
    # Callbacks - ВАЖНО: порядок имеет значение!
    application.add_handler(CallbackQueryHandler(check_subscription_callback, pattern="^check_subscription$"))
    application.add_handler(CallbackQueryHandler(handle_admin_reply_button, pattern="^reply_"))
    application.add_handler(CallbackQueryHandler(handle_section_selection, pattern="^section_"))
    application.add_handler(CallbackQueryHandler(handle_type_selection, pattern="^type_"))
    application.add_handler(CallbackQueryHandler(handle_delete_callback, pattern="^delete_"))
    application.add_handler(CallbackQueryHandler(skip_caption_callback, pattern="^skip_caption$"))
    # ИСПРАВЛЕНО: pattern для кастомных кнопок
    application.add_handler(CallbackQueryHandler(handle_custom_button_click, pattern="^btn_"))
    
    # Кнопки клавиатуры
    application.add_handler(MessageHandler(filters.Text(["🌐 Сайт"]), handle_website))
    application.add_handler(MessageHandler(filters.Text(["📝 Написать админу"]), handle_write_to_admin))
    application.add_handler(MessageHandler(filters.Text(["ℹ️ Помощь"]), handle_help))
    application.add_handler(MessageHandler(filters.Text(["📢 Проверить подписку"]), handle_check_subscription))
    application.add_handler(MessageHandler(filters.Text(["🚫 Отмена"]), handle_cancel))
    
    # Медиа
    application.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO | filters.Document.ALL, handle_media))
    
    # Текст
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_user_text))
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()