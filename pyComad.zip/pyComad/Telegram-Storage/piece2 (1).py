import os
import json
import hashlib
import random
import time
import logging
import asyncio
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional
import threading

from telegram import (
    Update, 
    ReplyKeyboardMarkup, 
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardRemove
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes,
    ConversationHandler
)
from telegram.constants import ParseMode

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('storage_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Конфигурация
BOT_TOKEN = "8570765506:AAG6y0oIkhVdfIb3pc5oILcF94crvyWS2nQ"
CHANNEL_USERNAME = "@StorageOffical"  # Ваш канал
ADMIN_IDS = [7633663691]  # Ваш ID для админки (должен быть списком!)

# Директории
BASE_DIR = "/storage/emulated/0/Download/pyComad/Telegram-Storage"
DATA_DIR = os.path.join(BASE_DIR, "Information")
FILES_DIR = os.path.join(BASE_DIR, "Files")
LOGS_DIR = os.path.join(BASE_DIR, "Logs")

# Создаем директории
for directory in [BASE_DIR, DATA_DIR, FILES_DIR, LOGS_DIR]:
    try:
        os.makedirs(directory, exist_ok=True)
        logger.info(f"Директория создана/проверена: {directory}")
    except Exception as e:
        logger.error(f"Ошибка создания директории {directory}: {e}")

# Состояния ConversationHandler
START, CHECK_CHANNEL, CREATE_STORAGE, ENTER_PASSWORD, LOGIN, MAIN_MENU, UPLOAD_FILE, VIEW_FILES, SETTINGS = range(9)

# Глобальные переменные для хранения сессий
active_sessions = {}
user_data_cache = {}

class SecureStorage:
    """Класс для безопасного хранения данных"""
    
    @staticmethod
    def encrypt_data(data: str, key: str) -> str:
        """Простое шифрование данных"""
        salt = os.urandom(16)
        key_hash = hashlib.pbkdf2_hmac('sha256', key.encode(), salt, 100000)
        return salt.hex() + ":" + hashlib.sha256((data + key_hash.hex()).encode()).hexdigest()
    
    @staticmethod
    def generate_user_id() -> str:
        """Генерация 5-значного ID"""
        return str(random.randint(10000, 99999))
    
    @staticmethod
    def generate_strong_password() -> str:
        """Генерация сильного пароля"""
        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
        return ''.join(random.choice(chars) for _ in range(12))
    
    @staticmethod
    def hash_password(password: str) -> str:
        """Хеширование пароля"""
        salt = os.urandom(32)
        key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
        return salt.hex() + ":" + key.hex()
    
    @staticmethod
    def verify_password(stored_password: str, provided_password: str) -> bool:
        """Проверка пароля"""
        salt_hex, key_hex = stored_password.split(":")
        salt = bytes.fromhex(salt_hex)
        stored_key = bytes.fromhex(key_hex)
        new_key = hashlib.pbkdf2_hmac('sha256', provided_password.encode(), salt, 100000)
        return stored_key == new_key

class UserStorage:
    """Класс для управления хранилищем пользователя"""
    
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.user_dir = os.path.join(DATA_DIR, user_id)
        self.files_dir = os.path.join(FILES_DIR, user_id)
        self.data_file = os.path.join(self.user_dir, "info.json")
        self.log_file = os.path.join(LOGS_DIR, f"{user_id}.log")
        
        # Создаем директории пользователя
        os.makedirs(self.user_dir, exist_ok=True)
        os.makedirs(self.files_dir, exist_ok=True)
    
    def save_user_data(self, data: dict, password: str):
        """Сохранение данных пользователя"""
        try:
            # Хешируем пароль
            hashed_password = SecureStorage.hash_password(password)
            data['password_hash'] = hashed_password
            data['created_at'] = datetime.now().isoformat()
            data['last_login'] = datetime.now().isoformat()
            
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            # Логирование
            self.log_action("DATA_SAVE", "User data saved")
            return True
        except Exception as e:
            logger.error(f"Error saving user data: {e}")
            return False
    
    def load_user_data(self) -> Optional[dict]:
        """Загрузка данных пользователя"""
        if not os.path.exists(self.data_file):
            return None
        
        try:
            with open(self.data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data
        except Exception as e:
            logger.error(f"Error loading user data: {e}")
            return None
    
    def verify_user_password(self, password: str) -> bool:
        """Проверка пароля пользователя"""
        user_data = self.load_user_data()
        if not user_data or 'password_hash' not in user_data:
            return False
        
        stored_password = user_data['password_hash']
        return SecureStorage.verify_password(stored_password, password)
    
    def save_file(self, file_id: str, file_data: bytes, filename: str):
        """Сохранение файла"""
        # Очищаем имя файла от небезопасных символов
        safe_filename = "".join(c for c in filename if c.isalnum() or c in '._- ').rstrip()
        
        # Если имя файла пустое, генерируем
        if not safe_filename:
            safe_filename = f"file_{int(time.time())}"
        
        file_path = os.path.join(self.files_dir, f"{file_id}_{safe_filename}")
        
        try:
            with open(file_path, 'wb') as f:
                f.write(file_data)
            
            # Сохраняем метаданные
            meta_path = os.path.join(self.files_dir, f"{file_id}.meta")
            metadata = {
                'filename': safe_filename,
                'original_filename': filename,
                'saved_at': datetime.now().isoformat(),
                'file_path': file_path,
                'file_size': len(file_data),
                'file_id': file_id
            }
            
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, ensure_ascii=False)
            
            self.log_action("FILE_SAVE", f"File saved: {filename}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving file: {e}")
            return False
    
    def get_file_list(self):
        """Получение списка файлов"""
        files = []
        if os.path.exists(self.files_dir):
            for file in os.listdir(self.files_dir):
                if file.endswith('.meta'):
                    meta_path = os.path.join(self.files_dir, file)
                    try:
                        with open(meta_path, 'r', encoding='utf-8') as f:
                            metadata = json.load(f)
                            files.append(metadata)
                    except Exception as e:
                        logger.error(f"Error loading metadata {meta_path}: {e}")
        return sorted(files, key=lambda x: x.get('saved_at', ''), reverse=True)
    
    def get_file_by_id(self, file_id: str):
        """Получение файла по ID"""
        meta_path = os.path.join(self.files_dir, f"{file_id}.meta")
        if os.path.exists(meta_path):
            try:
                with open(meta_path, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                return metadata
            except:
                return None
        return None
    
    def log_action(self, action: str, details: str):
        """Логирование действий"""
        log_entry = f"{datetime.now().isoformat()} | {self.user_id} | {action} | {details}\n"
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(log_entry)
        except:
            pass

class SessionManager:
    """Менеджер сессий"""
    
    @staticmethod
    def create_session(user_telegram_id: int, storage_id: str) -> str:
        """Создание новой сессии"""
        session_id = hashlib.sha256(f"{user_telegram_id}{time.time()}".encode()).hexdigest()[:16]
        active_sessions[session_id] = {
            'user_telegram_id': user_telegram_id,
            'storage_id': storage_id,
            'created_at': datetime.now(),
            'last_activity': datetime.now(),
            'files': []
        }
        
        # Запускаем таймер авто-выхода
        SessionManager._start_session_timer(session_id)
        
        logger.info(f"Session created: {session_id} for user {user_telegram_id}")
        return session_id
    
    @staticmethod
    def _start_session_timer(session_id: str):
        """Таймер автоматического выхода через 5 минут"""
        def timer_callback():
            time.sleep(300)  # 5 минут
            if session_id in active_sessions:
                logger.info(f"Auto-logout session {session_id}")
                SessionManager.end_session(session_id)
        
        thread = threading.Thread(target=timer_callback, daemon=True)
        thread.start()
    
    @staticmethod
    def update_activity(session_id: str):
        """Обновление времени активности"""
        if session_id in active_sessions:
            active_sessions[session_id]['last_activity'] = datetime.now()
    
    @staticmethod
    def end_session(session_id: str):
        """Завершение сессии"""
        if session_id in active_sessions:
            # Очищаем данные сессии
            del active_sessions[session_id]
            logger.info(f"Session {session_id} ended")

# Клавиатуры
def get_reply_keyboard():
    """Обычная клавиатура с командами"""
    keyboard = [
        [KeyboardButton("/start"), KeyboardButton("/login")],
        [KeyboardButton("/help"), KeyboardButton("/admin")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_start_keyboard():
    keyboard = [
        [InlineKeyboardButton("🔐 Создать хранилище", callback_data="create_storage")],
        [InlineKeyboardButton("🔑 Войти в хранилище", callback_data="login_storage")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_main_menu_keyboard():
    keyboard = [
        [InlineKeyboardButton("📁 Загрузить файл", callback_data="upload_file")],
        [InlineKeyboardButton("📂 Мои файлы", callback_data="my_files")],
        [InlineKeyboardButton("⚙️ Настройки", callback_data="settings")],
        [InlineKeyboardButton("🚪 Выйти из хранилища", callback_data="logout")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_back_keyboard():
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]]
    return InlineKeyboardMarkup(keyboard)

def get_file_list_keyboard(files, page=0, items_per_page=5):
    """Клавиатура для списка файлов с пагинацией"""
    keyboard = []
    
    # Показываем файлы на текущей странице
    start_idx = page * items_per_page
    end_idx = start_idx + items_per_page
    current_files = files[start_idx:end_idx]
    
    for i, file_meta in enumerate(current_files, 1):
        filename = file_meta.get('filename', 'Unknown')
        if len(filename) > 30:
            filename = filename[:27] + "..."
        keyboard.append([InlineKeyboardButton(f"📄 {filename}", callback_data=f"file_{file_meta.get('file_id', '')}")])
    
    # Кнопки пагинации
    pagination_buttons = []
    if page > 0:
        pagination_buttons.append(InlineKeyboardButton("◀️ Назад", callback_data=f"page_{page-1}"))
    
    if end_idx < len(files):
        pagination_buttons.append(InlineKeyboardButton("Вперед ▶️", callback_data=f"page_{page+1}"))
    
    if pagination_buttons:
        keyboard.append(pagination_buttons)
    
    keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")])
    
    return InlineKeyboardMarkup(keyboard)

# Проверка подписки на канал
async def check_channel_subscription(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Проверка подписки на канал"""
    try:
        chat_member = await context.bot.get_chat_member(
            chat_id=CHANNEL_USERNAME,
            user_id=user_id
        )
        return chat_member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Error checking subscription: {e}")
        return False

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user = update.effective_user
    
    welcome_text = """
🔒 *Секретное Хранилище*

Привет! Это максимально приватное хранилище для ваших файлов и сообщений.

📌 *Особенности:*
• Полная анонимность - даже если кто-то зайдет в ваш Telegram
• Шифрование всех данных
• Автоматическое удаление истории чата
• Хранение любых файлов

⚠️ *Важно:* Для использования бота требуется подписка на наш канал развития.

Выберите действие:
    """
    
    await update.message.reply_text(
        welcome_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=get_start_keyboard()
    )
    
    return START

# Команда /login
async def login_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Команда для входа в хранилище"""
    await update.message.reply_text(
        "🔑 *Вход в хранилище*\n\n"
        "Введите ваш ID хранилища (5 цифр):",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=ReplyKeyboardRemove()
    )
    return LOGIN

# Команда /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Справка по командам"""
    help_text = """
🤖 *Команды бота:*

/start - Начать работу с ботом
/login - Войти в существующее хранилище
/help - Показать эту справку

🔒 *Как пользоваться:*
1. Подпишитесь на канал @StorageOffical
2. Создайте хранилище (получите ID и пароль)
3. Сохраняйте файлы и текст
4. Не забывайте пароль - без него доступ невозможен

📌 *Важно:* Рекомендуем очищать историю чата после выхода для максимальной приватности.
    """
    
    await update.message.reply_text(
        help_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=get_reply_keyboard()
    )

# Обработка нажатия кнопок
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    user_data = context.user_data
    
    if query.data == "create_storage":
        # Проверяем подписку на канал
        is_subscribed = await check_channel_subscription(user_id, context)
        
        if not is_subscribed:
            await query.edit_message_text(
                "📢 *Требуется подписка!*\n\n"
                "Для использования хранилища необходимо подписаться на наш канал:\n"
                f"{CHANNEL_USERNAME}\n\n"
                "После подписки нажмите кнопку ниже для проверки.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Я подписался", callback_data="check_subscription")
                ]])
            )
            return CHECK_CHANNEL
        else:
            await query.edit_message_text(
                "✅ Отлично! Вы подписаны на канал.\n\n"
                "Теперь создадим ваше приватное хранилище...\n\n"
                "📝 *Шаг 1/2:* Придумайте надежный пароль\n"
                "• Минимум 8 символов\n"
                "• Цифры и буквы\n"
                "• Рекомендуем использовать сгенерированный пароль\n\n"
                "Введите пароль:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🎲 Сгенерировать пароль", callback_data="generate_password"),
                    InlineKeyboardButton("🔙 Назад", callback_data="back_to_start")
                ]])
            )
            return CREATE_STORAGE
    
    elif query.data == "login_storage":
        await query.edit_message_text(
            "🔑 *Вход в хранилище*\n\n"
            "Введите ваш ID хранилища (5 цифр):",
            parse_mode=ParseMode.MARKDOWN
        )
        return LOGIN
    
    elif query.data == "check_subscription":
        # Повторная проверка подписки
        is_subscribed = await check_channel_subscription(user_id, context)
        
        if is_subscribed:
            await query.edit_message_text(
                "✅ Отлично! Вы подписаны на канал.\n\n"
                "Теперь создадим ваше приватное хранилище...\n\n"
                "Введите надежный пароль для вашего хранилища:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🎲 Сгенерировать пароль", callback_data="generate_password"),
                    InlineKeyboardButton("🔙 Назад", callback_data="back_to_start")
                ]])
            )
            return CREATE_STORAGE
        else:
            await query.edit_message_text(
                "❌ Вы еще не подписались на канал!\n\n"
                f"Пожалуйста, подпишитесь: {CHANNEL_USERNAME}\n"
                "и попробуйте снова.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔄 Проверить снова", callback_data="check_subscription")
                ]])
            )
        return CHECK_CHANNEL
    
    elif query.data == "generate_password":
        strong_password = SecureStorage.generate_strong_password()
        await query.edit_message_text(
            f"🔐 *Сгенерированный пароль:*\n\n"
            f"`{strong_password}`\n\n"
            f"*Сохраните этот пароль!* Он нужен для входа в хранилище.\n\n"
            f"Введите пароль для подтверждения:",
            parse_mode=ParseMode.MARKDOWN
        )
        user_data['generated_password'] = strong_password
        return ENTER_PASSWORD
    
    elif query.data == "back_to_start":
        await query.edit_message_text(
            "🔒 *Секретное Хранилище*\n\n"
            "Выберите действие:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_start_keyboard()
        )
        return START
    
    elif query.data == "back_to_main":
        await query.edit_message_text(
            "🏠 *Главное меню хранилища*\n\n"
            "Выберите действие:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_main_menu_keyboard()
        )
        return MAIN_MENU
    
    elif query.data == "upload_file":
        await query.edit_message_text(
            "📤 *Загрузка файла*\n\n"
            "Отправьте мне любой файл, фото, видео или документ.\n"
            "Я сохраню его в вашем приватном хранилище.\n\n"
            "Максимальный размер: 20 МБ\n\n"
            "Можете отправлять несколько файлов подряд.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_back_keyboard()
        )
        return UPLOAD_FILE
    
    elif query.data == "my_files":
        if 'storage_id' not in user_data:
            await query.edit_message_text(
                "❌ Нет активной сессии!",
                reply_markup=get_back_keyboard()
            )
            return MAIN_MENU
        
        storage_id = user_data['storage_id']
        user_storage = UserStorage(storage_id)
        files = user_storage.get_file_list()
        
        if not files:
            await query.edit_message_text(
                "📭 *Ваше хранилище пусто*\n\n"
                "Загрузите первый файл!",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("📁 Загрузить файл", callback_data="upload_file"),
                    InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")
                ]])
            )
            return MAIN_MENU
        else:
            files_text = f"📂 *Ваши файлы:*\n\n"
            files_text += f"Всего файлов: {len(files)}\n\n"
            
            # Сохраняем список файлов в контексте для пагинации
            user_data['file_list'] = files
            user_data['current_file_page'] = 0
            
            # Показываем первую страницу
            return await show_file_page(query, context)
    
    elif query.data.startswith("page_"):
        # Обработка пагинации
        page = int(query.data.split("_")[1])
        user_data['current_file_page'] = page
        return await show_file_page(query, context)
    
    elif query.data.startswith("file_"):
        # Просмотр информации о файле
        file_id = query.data.split("_")[1]
        if 'storage_id' in user_data:
            storage_id = user_data['storage_id']
            user_storage = UserStorage(storage_id)
            file_meta = user_storage.get_file_by_id(file_id)
            
            if file_meta:
                file_info = f"""
📄 *Информация о файле:*

📁 Имя: `{file_meta.get('filename', 'Unknown')}`
📅 Загружен: `{file_meta.get('saved_at', 'Unknown')[:19]}`
📏 Размер: `{file_meta.get('file_size', 0) / 1024:.1f} KB`
📍 Путь: `{file_meta.get('file_path', 'Unknown')}`
"""
                await query.edit_message_text(
                    file_info,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=get_back_keyboard()
                )
        return VIEW_FILES
    
    elif query.data == "settings":
        if 'storage_id' not in user_data:
            await query.edit_message_text(
                "❌ Нет активной сессии!",
                reply_markup=get_back_keyboard()
            )
            return MAIN_MENU
        
        storage_id = user_data['storage_id']
        user_storage = UserStorage(storage_id)
        user_data_info = user_storage.load_user_data()
        
        if user_data_info:
            settings_text = f"""
⚙️ *Настройки хранилища*

🔑 ID хранилища: `{storage_id}`
👤 Telegram ID: `{user_data_info.get('telegram_id', 'Unknown')}`
📅 Создано: `{user_data_info.get('created_at', 'Unknown')[:19]}`
📊 Всего файлов: `{len(user_storage.get_file_list())}`

*Действия:*
"""
            keyboard = [
                [InlineKeyboardButton("🔄 Сменить пароль", callback_data="change_password")],
                [InlineKeyboardButton("📊 Статистика", callback_data="stats")],
                [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
            ]
            
            await query.edit_message_text(
                settings_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await query.edit_message_text(
                "❌ Ошибка загрузки настроек!",
                reply_markup=get_back_keyboard()
            )
        return SETTINGS
    
    elif query.data == "logout":
        # Завершаем сессию
        if 'session_id' in user_data:
            session_id = user_data['session_id']
            SessionManager.end_session(session_id)
            del user_data['session_id']
            del user_data['storage_id']
        
        await query.edit_message_text(
            "🚪 *Выход из хранилища*\n\n"
            "Ваша сессия завершена.\n\n"
            "💡 *Рекомендация:* Очистите историю чата с ботом для максимальной приватности.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_start_keyboard()
        )
        return START
    
    return START

async def show_file_page(query, context):
    """Показать страницу с файлами"""
    user_data = context.user_data
    files = user_data.get('file_list', [])
    page = user_data.get('current_file_page', 0)
    items_per_page = 5
    
    start_idx = page * items_per_page
    end_idx = start_idx + items_per_page
    current_files = files[start_idx:end_idx]
    
    files_text = f"📂 *Ваши файлы:*\n\n"
    files_text += f"Страница {page + 1} из {((len(files) - 1) // items_per_page) + 1}\n"
    files_text += f"Файлы {start_idx + 1}-{min(end_idx, len(files))} из {len(files)}\n\n"
    
    for i, file_meta in enumerate(current_files, start_idx + 1):
        filename = file_meta.get('filename', 'Unknown')
        saved_time = file_meta.get('saved_at', 'Unknown')
        if len(saved_time) > 10:
            saved_time = saved_time[:10]
        files_text += f"{i}. {filename[:30]}\n"
        files_text += f"   📅 {saved_time} | 📏 {file_meta.get('file_size', 0) / 1024:.1f} KB\n\n"
    
    await query.edit_message_text(
        files_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=get_file_list_keyboard(files, page)
    )
    return VIEW_FILES

# Обработка создания хранилища
async def create_storage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message:
        password = update.message.text.strip()
        
        # Проверяем длину пароля
        if len(password) < 8:
            await update.message.reply_text(
                "❌ Пароль слишком короткий!\n"
                "Минимум 8 символов.\n"
                "Попробуйте еще раз:"
            )
            return CREATE_STORAGE
        
        # Генерируем уникальный ID
        storage_id = SecureStorage.generate_user_id()
        
        # Проверяем, не существует ли уже такого ID
        while os.path.exists(os.path.join(DATA_DIR, storage_id)):
            storage_id = SecureStorage.generate_user_id()
        
        # Создаем хранилище пользователя
        user_storage = UserStorage(storage_id)
        
        # Сохраняем данные пользователя
        user_data = {
            'telegram_id': update.effective_user.id,
            'storage_id': storage_id,
            'username': update.effective_user.username or "",
            'first_name': update.effective_user.first_name or "",
            'last_name': update.effective_user.last_name or ""
        }
        
        success = user_storage.save_user_data(user_data, password)
        
        if not success:
            await update.message.reply_text(
                "❌ Ошибка при создании хранилища!",
                reply_markup=get_start_keyboard()
            )
            return START
        
        # Создаем сессию
        session_id = SessionManager.create_session(update.effective_user.id, storage_id)
        context.user_data['session_id'] = session_id
        context.user_data['storage_id'] = storage_id
        
        # Сообщаем пользователю его данные
        await update.message.reply_text(
            f"🎉 *Хранилище создано!*\n\n"
            f"🔑 *Ваш ID:* `{storage_id}`\n"
            f"🔐 *Ваш пароль:* `{password}`\n\n"
            f"⚠️ *ВАЖНО!*\n"
            f"• Сохраните эти данные в надежном месте\n"
            f"• Без них вы не сможете восстановить доступ\n"
            f"• ID состоит из 5 цифр\n\n"
            f"Автоматический выход через 5 минут бездействия.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_main_menu_keyboard()
        )
        
        return MAIN_MENU
    
    return CREATE_STORAGE

# Обработка входа в хранилище
async def login_storage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message:
        storage_id = update.message.text.strip()
        
        if len(storage_id) != 5 or not storage_id.isdigit():
            await update.message.reply_text(
                "❌ Неверный формат ID!\n"
                "ID должен состоять из 5 цифр.\n"
                "Попробуйте снова:"
            )
            return LOGIN
        
        # Проверяем существование хранилища
        if not os.path.exists(os.path.join(DATA_DIR, storage_id)):
            await update.message.reply_text(
                "❌ Хранилище не найдено!\n"
                "Проверьте ID или создайте новое хранилище.",
                reply_markup=get_start_keyboard()
            )
            return START
        
        # Сохраняем ID для следующего шага
        context.user_data['login_storage_id'] = storage_id
        
        await update.message.reply_text(
            f"ID: `{storage_id}`\n\n"
            f"Теперь введите пароль:",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return ENTER_PASSWORD
    
    return LOGIN

# Обработка пароля для входа
async def enter_password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message:
        password = update.message.text.strip()
        user_data = context.user_data
        
        # Проверяем, это вход или создание
        if 'login_storage_id' in user_data:
            # Это вход
            storage_id = user_data['login_storage_id']
            user_storage = UserStorage(storage_id)
            
            # Проверяем пароль
            if user_storage.verify_user_password(password):
                # Обновляем время входа
                user_info = user_storage.load_user_data()
                if user_info:
                    user_info['last_login'] = datetime.now().isoformat()
                    # Сохраняем без изменения пароля
                    try:
                        with open(user_storage.data_file, 'w', encoding='utf-8') as f:
                            json.dump(user_info, f, ensure_ascii=False, indent=2)
                    except:
                        pass
                
                # Создаем сессию
                session_id = SessionManager.create_session(update.effective_user.id, storage_id)
                user_data['session_id'] = session_id
                user_data['storage_id'] = storage_id
                
                # Удаляем временные данные
                del user_data['login_storage_id']
                
                await update.message.reply_text(
                    "✅ *Вход выполнен успешно!*\n\n"
                    "Добро пожаловать в ваше приватное хранилище.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=get_main_menu_keyboard()
                )
                
                return MAIN_MENU
            else:
                await update.message.reply_text(
                    "❌ Неверный пароль!\n"
                    "Попробуйте снова или начните заново.",
                    reply_markup=get_start_keyboard()
                )
                return START
        
        elif 'generated_password' in user_data:
            # Это создание хранилища (продолжение из генерации пароля)
            generated_password = user_data['generated_password']
            
            if password == generated_password:
                # Удаляем временные данные
                del user_data['generated_password']
                
                # Продолжаем создание хранилища
                return await create_storage(update, context)
            else:
                await update.message.reply_text(
                    "❌ Пароли не совпадают!\n"
                    "Введите пароль еще раз:"
                )
                return ENTER_PASSWORD
        else:
            # Это создание хранилища напрямую
            return await create_storage(update, context)
    
    return ENTER_PASSWORD

# Обработка загрузки файлов
async def upload_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if 'session_id' not in context.user_data:
        if update.message:
            await update.message.reply_text(
                "❌ Сессия истекла!\n"
                "Пожалуйста, войдите заново.",
                reply_markup=get_start_keyboard()
            )
        return START
    
    # Обновляем активность сессии
    session_id = context.user_data['session_id']
    SessionManager.update_activity(session_id)
    
    # Проверяем подписку перед каждым действием
    is_subscribed = await check_channel_subscription(update.effective_user.id, context)
    if not is_subscribed:
        await update.message.reply_text(
            "❌ Вы отписались от канала!\n\n"
            f"Для продолжения работы подпишитесь: {CHANNEL_USERNAME}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔄 Проверить подписку", callback_data="check_subscription")
            ]])
        )
        return CHECK_CHANNEL
    
    # Обрабатываем разные типы файлов
    message = update.message
    
    try:
        file = None
        filename = ""
        file_type = ""
        
        if message.document:
            file = await message.document.get_file()
            filename = message.document.file_name or f"document_{int(time.time())}.bin"
            file_type = "document"
        elif message.photo:
            file = await message.photo[-1].get_file()
            filename = f"photo_{int(time.time())}.jpg"
            file_type = "photo"
        elif message.video:
            file = await message.video.get_file()
            filename = message.video.file_name or f"video_{int(time.time())}.mp4"
            file_type = "video"
        elif message.audio:
            file = await message.audio.get_file()
            filename = message.audio.file_name or f"audio_{int(time.time())}.mp3"
            file_type = "audio"
        elif message.text:
            # Сохраняем текстовое сообщение
            storage_id = context.user_data['storage_id']
            user_storage = UserStorage(storage_id)
            
            text_filename = f"text_{int(time.time())}.txt"
            text_path = os.path.join(user_storage.files_dir, text_filename)
            
            with open(text_path, 'w', encoding='utf-8') as f:
                f.write(message.text)
            
            # Генерируем уникальный ID для текстового файла
            file_id = f"text_{int(time.time())}_{random.randint(1000, 9999)}"
            
            # Сохраняем метаданные
            meta_path = os.path.join(user_storage.files_dir, f"{file_id}.meta")
            metadata = {
                'filename': text_filename,
                'original_filename': "text_message.txt",
                'saved_at': datetime.now().isoformat(),
                'file_path': text_path,
                'file_size': len(message.text.encode('utf-8')),
                'file_id': file_id,
                'type': 'text'
            }
            
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, ensure_ascii=False)
            
            await message.reply_text(
                "✅ Текст сохранен в хранилище!\n\n"
                "Можете отправить еще файлы или вернуться в меню.",
                reply_markup=get_back_keyboard()
            )
            return UPLOAD_FILE
        else:
            await message.reply_text(
                "❌ Неподдерживаемый тип файла.",
                reply_markup=get_back_keyboard()
            )
            return UPLOAD_FILE
        
        # Скачиваем файл
        file_data = await file.download_as_bytearray()
        
        # Проверяем размер файла (20 МБ лимит)
        if len(file_data) > 20 * 1024 * 1024:
            await message.reply_text(
                "❌ Файл слишком большой!\n"
                "Максимальный размер: 20 МБ",
                reply_markup=get_back_keyboard()
            )
            return UPLOAD_FILE
        
        # Сохраняем файл
        storage_id = context.user_data['storage_id']
        user_storage = UserStorage(storage_id)
        
        success = user_storage.save_file(file.file_id, bytes(file_data), filename)
        
        if success:
            await message.reply_text(
                f"✅ Файл сохранен!\n\n"
                f"📝 Тип: {file_type}\n"
                f"📁 Имя: {filename[:50]}\n"
                f"📏 Размер: {len(file_data) / 1024:.1f} KB\n\n"
                f"Можете отправить еще файлы или вернуться в меню.",
                reply_markup=get_back_keyboard()
            )
        else:
            await message.reply_text(
                "❌ Ошибка при сохранении файла!",
                reply_markup=get_back_keyboard()
            )
        
    except Exception as e:
        logger.error(f"Error in upload_file: {e}")
        await message.reply_text(
            "❌ Произошла ошибка при обработке файла!",
            reply_markup=get_back_keyboard()
        )
    
    return UPLOAD_FILE

# Админ команды
async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Статистика для админа"""
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Доступ запрещен!")
        return
    
    # Считаем пользователей
    try:
        user_folders = [f for f in os.listdir(DATA_DIR) if os.path.isdir(os.path.join(DATA_DIR, f))]
        total_users = len(user_folders)
        
        # Считаем файлы
        total_files = 0
        total_size = 0
        
        for user_id in user_folders:
            user_files_dir = os.path.join(FILES_DIR, user_id)
            if os.path.exists(user_files_dir):
                for file in os.listdir(user_files_dir):
                    if not file.endswith('.meta'):
                        file_path = os.path.join(user_files_dir, file)
                        if os.path.isfile(file_path):
                            total_files += 1
                            total_size += os.path.getsize(file_path)
        
        # Конвертируем размер
        size_str = ""
        if total_size < 1024:
            size_str = f"{total_size} B"
        elif total_size < 1024 * 1024:
            size_str = f"{total_size / 1024:.2f} KB"
        elif total_size < 1024 * 1024 * 1024:
            size_str = f"{total_size / (1024 * 1024):.2f} MB"
        else:
            size_str = f"{total_size / (1024 * 1024 * 1024):.2f} GB"
        
        stats_text = f"""
📊 *Статистика бота:*

👥 Пользователей: {total_users}
📁 Файлов сохранено: {total_files}
💾 Использовано места: {size_str}
🔄 Активных сессий: {len(active_sessions)}

📈 *Директории:*
• Основная: {BASE_DIR}
• Данные: {DATA_DIR}
• Файлы: {FILES_DIR}
• Логи: {LOGS_DIR}
        """
        
        await update.message.reply_text(stats_text, parse_mode=ParseMode.MARKDOWN)
    except Exception as e:
        logger.error(f"Error in admin_stats: {e}")
        await update.message.reply_text(f"❌ Ошибка получения статистики: {e}")

# Обработка ошибок
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ошибок"""
    logger.error(f"Update {update} caused error {context.error}")
    
    try:
        if update and update.message:
            await update.message.reply_text(
                "❌ Произошла ошибка!\n"
                "Пожалуйста, попробуйте еще раз или перезапустите бота командой /start",
                reply_markup=get_reply_keyboard()
            )
    except:
        pass

# Главная функция
def main():
    """Запуск бота"""
    # Создаем Application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Создаем ConversationHandler
    conv_handler = ConversationHandler(
        entry_points=[
            CommandHandler('start', start),
            CommandHandler('login', login_command)
        ],
        states={
            START: [CallbackQueryHandler(button_handler)],
            CHECK_CHANNEL: [CallbackQueryHandler(button_handler)],
            CREATE_STORAGE: [
                CallbackQueryHandler(button_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, create_storage)
            ],
            ENTER_PASSWORD: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, enter_password)
            ],
            LOGIN: [
                CallbackQueryHandler(button_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, login_storage)
            ],
            MAIN_MENU: [CallbackQueryHandler(button_handler)],
            UPLOAD_FILE: [
                CallbackQueryHandler(button_handler),
                MessageHandler(
                    (filters.Document.ALL | filters.PHOTO | filters.VIDEO | 
                     filters.AUDIO | filters.TEXT) & ~filters.COMMAND, 
                    upload_file
                )
            ],
            VIEW_FILES: [CallbackQueryHandler(button_handler)],
            SETTINGS: [CallbackQueryHandler(button_handler)],
        },
        fallbacks=[
            CommandHandler('start', start),
            CommandHandler('login', login_command),
            CommandHandler('help', help_command)
        ],
    )
    
    # Добавляем обработчики
    application.add_handler(conv_handler)
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("admin", admin_stats))
    application.add_error_handler(error_handler)
    
    # Запускаем бота
    logger.info("Бот запущен...")
    print(f"Базовая директория: {BASE_DIR}")
    print(f"Директория данных: {DATA_DIR}")
    print(f"Директория файлов: {FILES_DIR}")
    print(f"Директория логов: {LOGS_DIR}")
    
    try:
        application.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем")
    except Exception as e:
        logger.error(f"Fatal error: {e}")

if __name__ == '__main__':
    main()