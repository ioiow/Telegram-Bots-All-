import os
import json
import hashlib
import random
import time
import logging
import shutil
from datetime import datetime, timedelta
from typing import Dict, Optional, List

from telegram import (
    Update, 
    InlineKeyboardMarkup,
    InlineKeyboardButton
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes,
    ConversationHandler
)
from telegram.constants import ParseMode

# ===================== ЛОГИРОВАНИЕ =====================
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('storage_bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ===================== КОНФИГУРАЦИЯ =====================
BOT_TOKEN = "8570765506:AAG6y0oIkhVdfIb3pc5oILcF94crvyWS2nQ"
ADMIN_IDS = [7633663691]

# Директории
BASE_DIR = "/storage/emulated/0/Download/pyComad/Telegram-Storage"
DATA_DIR = os.path.join(BASE_DIR, "Information")
FILES_DIR = os.path.join(BASE_DIR, "Files")
LOGS_DIR = os.path.join(BASE_DIR, "Logs")
CONFIG_DIR = os.path.join(BASE_DIR, "Config")
ADMIN_MESSAGES_DIR = os.path.join(BASE_DIR, "AdminMessages")

# Создаем директории
for directory in [BASE_DIR, DATA_DIR, FILES_DIR, LOGS_DIR, CONFIG_DIR, ADMIN_MESSAGES_DIR]:
    os.makedirs(directory, exist_ok=True)

# Файл каналов
CHANNELS_FILE = os.path.join(CONFIG_DIR, "channels.json")

# Состояния
(START, CHECK_SUB, CREATE_STORAGE, ENTER_PASS, LOGIN, ENTER_LOGIN_PASS,
 MAIN_MENU, SELECT_FOLDER, UPLOAD_FILE, VIEW_FILES, CREATE_FOLDER,
 SETTINGS, ADMIN_PANEL, CONTACT_ADMIN, ADMIN_REPLY, ADD_CHANNEL,
 CONFIRM_DELETE) = range(17)

# Глобальные переменные
active_sessions = {}
admin_messages = {}

# ===================== МЕНЕДЖЕР КАНАЛОВ =====================
class ChannelManager:
    @staticmethod
    def load():
        if os.path.exists(CHANNELS_FILE):
            try:
                with open(CHANNELS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f).get('channels', [])
            except:
                pass
        return []
    
    @staticmethod
    def save(channels):
        with open(CHANNELS_FILE, 'w', encoding='utf-8') as f:
            json.dump({'channels': channels}, f, ensure_ascii=False)
    
    @staticmethod
    def add(channel):
        channels = ChannelManager.load()
        if channel not in channels:
            channels.append(channel)
            ChannelManager.save(channels)
            return True
        return False
    
    @staticmethod
    def remove(channel):
        channels = ChannelManager.load()
        if channel in channels:
            channels.remove(channel)
            ChannelManager.save(channels)
            return True
        return False

# ===================== ХРАНИЛИЩЕ ПОЛЬЗОВАТЕЛЯ =====================
class UserStorage:
    DEFAULT_FOLDERS = ['📷 Фото', '🎥 Видео', '📄 Документы', '📝 Заметки']
    
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.user_dir = os.path.join(DATA_DIR, user_id)
        self.files_dir = os.path.join(FILES_DIR, user_id)
        self.data_file = os.path.join(self.user_dir, "data.json")
        self.folders_file = os.path.join(self.user_dir, "folders.json")
        
        os.makedirs(self.user_dir, exist_ok=True)
        os.makedirs(self.files_dir, exist_ok=True)
    
    def _safe_name(self, name):
        return "".join(c for c in name if c.isalnum() or c in ' _-').strip() or "folder"
    
    def get_folders(self):
        if os.path.exists(self.folders_file):
            try:
                with open(self.folders_file, 'r', encoding='utf-8') as f:
                    return json.load(f).get('folders', self.DEFAULT_FOLDERS.copy())
            except:
                pass
        return self.DEFAULT_FOLDERS.copy()
    
    def save_folders(self, folders):
        with open(self.folders_file, 'w', encoding='utf-8') as f:
            json.dump({'folders': folders}, f, ensure_ascii=False)
    
    def create_folder(self, name):
        folders = self.get_folders()
        if name not in folders:
            folders.append(name)
            self.save_folders(folders)
            folder_path = os.path.join(self.files_dir, self._safe_name(name))
            os.makedirs(folder_path, exist_ok=True)
            return True
        return False
    
    def delete_folder(self, name):
        folders = self.get_folders()
        if name in folders:
            folders.remove(name)
            self.save_folders(folders)
            folder_path = os.path.join(self.files_dir, self._safe_name(name))
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
            return True
        return False
    
    def ensure_folder(self, name):
        folders = self.get_folders()
        if name not in folders:
            folders.append(name)
            self.save_folders(folders)
        folder_path = os.path.join(self.files_dir, self._safe_name(name))
        os.makedirs(folder_path, exist_ok=True)
        return folder_path
    
    def save_user(self, data, password):
        data['password'] = password  # Пароль в открытом виде
        data['created_at'] = datetime.now().isoformat()
        data['last_login'] = datetime.now().isoformat()
        
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        self.save_folders(self.DEFAULT_FOLDERS.copy())
        for folder in self.DEFAULT_FOLDERS:
            os.makedirs(os.path.join(self.files_dir, self._safe_name(folder)), exist_ok=True)
        return True
    
    def load_user(self):
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    def check_password(self, password):
        data = self.load_user()
        return data and data.get('password') == password
    
    def save_file(self, file_id, file_data, filename, folder, file_type):
        try:
            safe_filename = self._safe_name(filename) or f"file_{int(time.time())}"
            folder_path = self.ensure_folder(folder)
            
            # Уникальный ID файла
            unique_id = f"{int(time.time())}_{random.randint(1000, 9999)}"
            
            file_path = os.path.join(folder_path, f"{unique_id}_{safe_filename}")
            
            with open(file_path, 'wb') as f:
                f.write(file_data)
            
            # Метаданные
            meta = {
                'file_id': unique_id,
                'filename': safe_filename,
                'original': filename,
                'saved_at': datetime.now().isoformat(),
                'path': file_path,
                'size': len(file_data),
                'folder': folder,
                'type': file_type
            }
            
            meta_path = os.path.join(folder_path, f"{unique_id}.meta")
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)
            
            logger.info(f"Файл сохранен: {filename} -> {folder}")
            return True
        except Exception as e:
            logger.error(f"Ошибка сохранения: {e}")
            return False
    
    def get_files(self, folder, days=None):
        files = []
        folder_path = os.path.join(self.files_dir, self._safe_name(folder))
        
        if os.path.exists(folder_path):
            for f in os.listdir(folder_path):
                if f.endswith('.meta'):
                    try:
                        with open(os.path.join(folder_path, f), 'r', encoding='utf-8') as mf:
                            meta = json.load(mf)
                            
                            if days:
                                saved = datetime.fromisoformat(meta.get('saved_at', ''))
                                if datetime.now() - saved > timedelta(days=days):
                                    continue
                            
                            files.append(meta)
                    except:
                        pass
        
        return sorted(files, key=lambda x: x.get('saved_at', ''), reverse=True)
    
    def get_all_files(self):
        all_files = []
        for folder in self.get_folders():
            all_files.extend(self.get_files(folder))
        return sorted(all_files, key=lambda x: x.get('saved_at', ''), reverse=True)
    
    def delete_file(self, file_id):
        for folder in self.get_folders():
            folder_path = os.path.join(self.files_dir, self._safe_name(folder))
            meta_path = os.path.join(folder_path, f"{file_id}.meta")
            
            if os.path.exists(meta_path):
                try:
                    with open(meta_path, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                    
                    if os.path.exists(meta.get('path', '')):
                        os.remove(meta['path'])
                    os.remove(meta_path)
                    return True
                except:
                    pass
        return False
    
    def get_stats(self):
        files = self.get_all_files()
        total_size = sum(f.get('size', 0) for f in files)
        return {'count': len(files), 'size': total_size}

# ===================== СЕССИИ =====================
class SessionManager:
    @staticmethod
    def create(tg_id, storage_id):
        sid = hashlib.sha256(f"{tg_id}{time.time()}".encode()).hexdigest()[:16]
        active_sessions[sid] = {
            'tg_id': tg_id,
            'storage_id': storage_id,
            'created': datetime.now()
        }
        return sid
    
    @staticmethod
    def update(sid):
        if sid in active_sessions:
            active_sessions[sid]['updated'] = datetime.now()
    
    @staticmethod
    def end(sid):
        if sid in active_sessions:
            del active_sessions[sid]
    
    @staticmethod
    def count():
        return len(active_sessions)

# ===================== КЛАВИАТУРЫ =====================
def kb_start():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔐 Создать хранилище", callback_data="create")],
        [InlineKeyboardButton("🔑 Войти", callback_data="login")]
    ])

def kb_main():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📂 Мои папки", callback_data="folders")],
        [InlineKeyboardButton("📤 Загрузить файл", callback_data="upload")],
        [InlineKeyboardButton("➕ Создать папку", callback_data="new_folder")],
        [InlineKeyboardButton("📊 Статистика", callback_data="stats")],
        [InlineKeyboardButton("✉️ Написать админу", callback_data="contact")],
        [InlineKeyboardButton("⚙️ Настройки", callback_data="settings")],
        [InlineKeyboardButton("🚪 Выйти", callback_data="logout")]
    ])

def kb_back():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 Главное меню", callback_data="menu")]
    ])

def kb_folders(folders, prefix="view"):
    buttons = [[InlineKeyboardButton(f, callback_data=f"{prefix}_{f}")] for f in folders]
    buttons.append([InlineKeyboardButton("🏠 Меню", callback_data="menu")])
    return InlineKeyboardMarkup(buttons)

def kb_folder_actions(folder):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📅 За 5 дней", callback_data=f"days_5_{folder}")],
        [InlineKeyboardButton("📅 За 10 дней", callback_data=f"days_10_{folder}")],
        [InlineKeyboardButton("📋 Все файлы", callback_data=f"days_all_{folder}")],
        [InlineKeyboardButton("🗑 Удалить папку", callback_data=f"delfolder_{folder}")],
        [InlineKeyboardButton("🔙 К папкам", callback_data="folders")]
    ])

def kb_after_upload(folder):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"📂 Открыть {folder}", callback_data=f"view_{folder}")],
        [InlineKeyboardButton("📁 Другая папка", callback_data="upload")],
        [InlineKeyboardButton("📊 Статистика", callback_data="stats")],
        [InlineKeyboardButton("🏠 Меню", callback_data="menu")]
    ])

def kb_admin():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Статистика", callback_data="adm_stats")],
        [InlineKeyboardButton("👥 Пользователи", callback_data="adm_users")],
        [InlineKeyboardButton("📢 Каналы", callback_data="adm_channels")],
        [InlineKeyboardButton("✉️ Сообщения", callback_data="adm_messages")],
        [InlineKeyboardButton("❌ Закрыть", callback_data="adm_close")]
    ])

def kb_channels(channels):
    buttons = [[InlineKeyboardButton(f"❌ {c}", callback_data=f"rmchan_{c}")] for c in channels]
    buttons.append([InlineKeyboardButton("➕ Добавить", callback_data="addchan")])
    buttons.append([InlineKeyboardButton("🔙 Назад", callback_data="adm_panel")])
    return InlineKeyboardMarkup(buttons)

# ===================== ПРОВЕРКА ПОДПИСКИ =====================
async def check_subs(user_id, context):
    channels = ChannelManager.load()
    if not channels:
        return True, []
    
    not_sub = []
    for ch in channels:
        try:
            member = await context.bot.get_chat_member(ch, user_id)
            if member.status not in ['member', 'administrator', 'creator']:
                not_sub.append(ch)
        except:
            not_sub.append(ch)
    
    return len(not_sub) == 0, not_sub

# ===================== КОМАНДЫ =====================
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = """
🔒 *Приватное Хранилище*

Безопасное хранение файлов в Telegram.

📌 *Возможности:*
• Папки: Фото, Видео, Документы, Заметки
• Создание своих папок
• Фильтр по датам
• Связь с админом

Выберите действие:
    """
    
    if update.message:
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb_start())
    else:
        await update.callback_query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb_start())
    
    return START

async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Нет доступа!")
        return START
    
    await update.message.reply_text(
        "🔧 *Панель администратора*",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=kb_admin()
    )
    return ADMIN_PANEL

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = """
📖 *Справка*

/start - Начало работы
/login - Войти в хранилище
/admin - Панель админа
/help - Эта справка

🔐 Создайте хранилище, получите ID и пароль.
📁 Загружайте файлы в папки.
🗂 Создавайте свои папки.
    """
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

async def cmd_login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔑 Введите ID хранилища (5 цифр):")
    return LOGIN

# ===================== ОБРАБОТЧИК КНОПОК =====================
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    data = query.data
    user_id = query.from_user.id
    ud = context.user_data
    
    # === СТАРТ ===
    if data == "create":
        ok, not_sub = await check_subs(user_id, context)
        if not ok and not_sub:
            text = "📢 *Подпишитесь на каналы:*\n\n" + "\n".join(not_sub)
            await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✅ Проверить", callback_data="checksub")]]))
            return CHECK_SUB
        
        await query.edit_message_text(
            "🔐 *Создание хранилища*\n\nВведите пароль (мин. 8 символов):",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎲 Сгенерировать", callback_data="genpass")],
                [InlineKeyboardButton("🔙 Назад", callback_data="back_start")]
            ])
        )
        return CREATE_STORAGE
    
    elif data == "login":
        await query.edit_message_text("🔑 Введите ID хранилища (5 цифр):")
        return LOGIN
    
    elif data == "checksub":
        ok, not_sub = await check_subs(user_id, context)
        if ok:
            await query.edit_message_text(
                "✅ Отлично! Введите пароль:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🎲 Сгенерировать", callback_data="genpass")]
                ])
            )
            return CREATE_STORAGE
        else:
            text = "❌ *Не подписаны:*\n\n" + "\n".join(not_sub)
            await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔄 Проверить", callback_data="checksub")]]))
            return CHECK_SUB
    
    elif data == "genpass":
        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%"
        password = ''.join(random.choice(chars) for _ in range(12))
        ud['gen_pass'] = password
        await query.edit_message_text(
            f"🔐 *Ваш пароль:*\n\n`{password}`\n\n⚠️ Сохраните! Введите для подтверждения:"
        , parse_mode=ParseMode.MARKDOWN)
        return ENTER_PASS
    
    elif data == "back_start":
        return await cmd_start(update, context)
    
    # === ГЛАВНОЕ МЕНЮ ===
    elif data == "menu":
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        await query.edit_message_text(
            "🏠 *Главное меню*\n\nВыберите действие:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_main()
        )
        return MAIN_MENU
    
    elif data == "folders":
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        storage = UserStorage(ud['storage_id'])
        folders = storage.get_folders()
        
        text = "📂 *Ваши папки:*\n\n"
        for f in folders:
            stats = storage.get_files(f)
            text += f"{f}: {len(stats)} файлов\n"
        
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb_folders(folders))
        return VIEW_FILES
    
    elif data == "upload":
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        storage = UserStorage(ud['storage_id'])
        folders = storage.get_folders()
        
        await query.edit_message_text(
            "📤 *Загрузка файла*\n\nВыберите папку:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_folders(folders, "upl")
        )
        return SELECT_FOLDER
    
    elif data == "new_folder":
        await query.edit_message_text(
            "➕ *Создание папки*\n\nВведите название:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_back()
        )
        return CREATE_FOLDER
    
    elif data == "stats":
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        storage = UserStorage(ud['storage_id'])
        stats = storage.get_stats()
        size = stats['size']
        size_str = f"{size/1024:.1f} KB" if size < 1024*1024 else f"{size/(1024*1024):.2f} MB"
        
        text = f"""
📊 *Статистика*

🔑 ID: `{ud['storage_id']}`
📁 Папок: {len(storage.get_folders())}
📄 Файлов: {stats['count']}
💾 Размер: {size_str}
        """
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb_back())
        return MAIN_MENU
    
    elif data == "contact":
        await query.edit_message_text(
            "✉️ *Написать админу*\n\nОтправьте сообщение или фото:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_back()
        )
        return CONTACT_ADMIN
    
    elif data == "settings":
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        storage = UserStorage(ud['storage_id'])
        info = storage.load_user()
        
        text = f"""
⚙️ *Настройки*

🔑 ID: `{ud['storage_id']}`
📅 Создано: {info.get('created_at', 'N/A')[:10] if info else 'N/A'}
        """
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb_back())
        return SETTINGS
    
    elif data == "logout":
        if 'session_id' in ud:
            SessionManager.end(ud['session_id'])
        ud.clear()
        
        await query.edit_message_text(
            "🚪 *Выход выполнен*\n\n💡 Очистите историю чата для приватности.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_start()
        )
        return START
    
    # === ПАПКИ ===
    elif data.startswith("view_"):
        folder = data[5:]
        ud['current_folder'] = folder
        
        await query.edit_message_text(
            f"📂 *{folder}*\n\nВыберите период:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_folder_actions(folder)
        )
        return VIEW_FILES
    
    elif data.startswith("upl_"):
        folder = data[4:]
        ud['upload_folder'] = folder
        
        await query.edit_message_text(
            f"📤 *Загрузка в: {folder}*\n\nОтправьте файл, фото, видео или текст:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_back()
        )
        return UPLOAD_FILE
    
    elif data.startswith("days_"):
        parts = data.split("_", 2)
        period = parts[1]
        folder = parts[2]
        
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        storage = UserStorage(ud['storage_id'])
        days = None if period == "all" else int(period)
        files = storage.get_files(folder, days)
        
        if not files:
            await query.edit_message_text(
                f"📭 *{folder}* — нет файлов",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=kb_folder_actions(folder)
            )
            return VIEW_FILES
        
        text = f"📂 *{folder}* — {len(files)} файлов\n\n"
        buttons = []
        
        for f in files[:10]:
            name = f.get('filename', 'file')[:20]
            fid = f.get('file_id', '')
            size = f.get('size', 0) / 1024
            text += f"• {name} ({size:.1f}KB)\n"
            buttons.append([InlineKeyboardButton(f"📄 {name}", callback_data=f"file_{fid}_{folder}")])
        
        if len(files) > 10:
            text += f"\n... и еще {len(files) - 10}"
        
        buttons.append([InlineKeyboardButton("🔙 К папке", callback_data=f"view_{folder}")])
        
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(buttons))
        return VIEW_FILES
    
    elif data.startswith("file_"):
        parts = data.split("_", 2)
        file_id = parts[1]
        folder = parts[2] if len(parts) > 2 else ""
        
        if 'storage_id' not in ud:
            return await cmd_start(update, context)
        
        storage = UserStorage(ud['storage_id'])
        
        # Ищем файл
        for fld in storage.get_folders():
            for f in storage.get_files(fld):
                if f.get('file_id') == file_id:
                    text = f"""
📄 *Файл*

📁 Имя: `{f.get('filename')}`
📂 Папка: {f.get('folder')}
📅 Дата: {f.get('saved_at', '')[:10]}
📏 Размер: {f.get('size', 0) / 1024:.1f} KB
🏷 Тип: {f.get('type', 'unknown')}
                    """
                    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🗑 Удалить", callback_data=f"delfile_{file_id}")],
                            [InlineKeyboardButton("🔙 К папке", callback_data=f"view_{f.get('folder', '')}")]
                        ]))
                    return VIEW_FILES
        
        await query.edit_message_text("❌ Файл не найден", reply_markup=kb_back())
        return VIEW_FILES
    
    elif data.startswith("delfile_"):
        file_id = data[8:]
        if 'storage_id' in ud:
            storage = UserStorage(ud['storage_id'])
            if storage.delete_file(file_id):
                await query.edit_message_text("✅ Файл удален!", reply_markup=kb_back())
            else:
                await query.edit_message_text("❌ Ошибка удаления", reply_markup=kb_back())
        return MAIN_MENU
    
    elif data.startswith("delfolder_"):
        folder = data[10:]
        ud['del_folder'] = folder
        await query.edit_message_text(
            f"🗑 *Удалить папку {folder}?*\n\nВсе файлы будут удалены!",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Удалить", callback_data="confirm_del")],
                [InlineKeyboardButton("❌ Отмена", callback_data="folders")]
            ])
        )
        return CONFIRM_DELETE
    
    elif data == "confirm_del":
        folder = ud.get('del_folder', '')
        if folder and 'storage_id' in ud:
            storage = UserStorage(ud['storage_id'])
            storage.delete_folder(folder)
            await query.edit_message_text("✅ Папка удалена!", reply_markup=kb_back())
        return MAIN_MENU
    
    # === АДМИН ===
    elif data == "adm_panel":
        if user_id not in ADMIN_IDS:
            return START
        await query.edit_message_text("🔧 *Админ панель*", parse_mode=ParseMode.MARKDOWN, reply_markup=kb_admin())
        return ADMIN_PANEL
    
    elif data == "adm_stats":
        users = [f for f in os.listdir(DATA_DIR) if os.path.isdir(os.path.join(DATA_DIR, f))]
        total_files = 0
        total_size = 0
        
        for u in users:
            ufiles = os.path.join(FILES_DIR, u)
            if os.path.exists(ufiles):
                for root, dirs, files in os.walk(ufiles):
                    for f in files:
                        if not f.endswith('.meta'):
                            fp = os.path.join(root, f)
                            total_files += 1
                            total_size += os.path.getsize(fp)
        
        size_str = f"{total_size/(1024*1024):.2f} MB"
        
        text = f"""
📊 *Статистика бота*

👥 Пользователей: {len(users)}
📁 Файлов: {total_files}
💾 Размер: {size_str}
🔄 Сессий: {SessionManager.count()}
📢 Каналов: {len(ChannelManager.load())}
        """
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="adm_panel")]]))
        return ADMIN_PANEL
    
    elif data == "adm_users":
        users = [f for f in os.listdir(DATA_DIR) if os.path.isdir(os.path.join(DATA_DIR, f))]
        
        text = "👥 *Пользователи:*\n\n"
        for u in users[:20]:
            storage = UserStorage(u)
            info = storage.load_user()
            if info:
                text += f"ID: `{u}` | TG: `{info.get('telegram_id')}` | Pass: `{info.get('password')}`\n"
        
        if len(users) > 20:
            text += f"\n... и еще {len(users) - 20}"
        
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="adm_panel")]]))
        return ADMIN_PANEL
    
    elif data == "adm_channels":
        channels = ChannelManager.load()
        text = "📢 *Каналы:*\n\n" + ("\n".join(channels) if channels else "Нет каналов")
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb_channels(channels))
        return ADMIN_PANEL
    
    elif data == "addchan":
        await query.edit_message_text(
            "➕ *Добавление канала*\n\nОтправьте @username канала:\n\n⚠️ Бот должен быть админом!",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="adm_channels")]])
        )
        return ADD_CHANNEL
    
    elif data.startswith("rmchan_"):
        channel = data[7:]
        ChannelManager.remove(channel)
        channels = ChannelManager.load()
        await query.edit_message_text(f"✅ Канал {channel} удален!", reply_markup=kb_channels(channels))
        return ADMIN_PANEL
    
    elif data == "adm_messages":
        if admin_messages:
            text = "✉️ *Сообщения:*\n\n"
            buttons = []
            for mid, mdata in list(admin_messages.items())[:10]:
                text += f"От: {mdata.get('from_user')}\n"
                buttons.append([InlineKeyboardButton(f"📩 {mdata.get('from_user')}", callback_data=f"replymsg_{mid}")])
            buttons.append([InlineKeyboardButton("🔙 Назад", callback_data="adm_panel")])
            await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(buttons))
        else:
            await query.edit_message_text("📭 Нет сообщений",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="adm_panel")]]))
        return ADMIN_PANEL
    
    elif data.startswith("replymsg_"):
        mid = data[9:]
        ud['reply_msg'] = mid
        mdata = admin_messages.get(mid, {})
        await query.edit_message_text(
            f"📩 *От {mdata.get('from_user')}:*\n\n{mdata.get('text', '[Фото]')}\n\n✍️ Введите ответ:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="adm_messages")]])
        )
        return ADMIN_REPLY
    
    elif data == "adm_close":
        await query.edit_message_text("✅ Панель закрыта")
        return START
    
    return START

# ===================== ОБРАБОТЧИКИ ТЕКСТА =====================
async def handle_create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    password = update.message.text.strip()
    
    if len(password) < 8:
        await update.message.reply_text("❌ Минимум 8 символов!")
        return CREATE_STORAGE
    
    # Генерируем ID
    storage_id = str(random.randint(10000, 99999))
    while os.path.exists(os.path.join(DATA_DIR, storage_id)):
        storage_id = str(random.randint(10000, 99999))
    
    storage = UserStorage(storage_id)
    user_info = {
        'telegram_id': update.effective_user.id,
        'storage_id': storage_id,
        'username': update.effective_user.username or ""
    }
    storage.save_user(user_info, password)
    
    session_id = SessionManager.create(update.effective_user.id, storage_id)
    context.user_data['session_id'] = session_id
    context.user_data['storage_id'] = storage_id
    
    await update.message.reply_text(
        f"🎉 *Хранилище создано!*\n\n"
        f"🔑 ID: `{storage_id}`\n"
        f"🔐 Пароль: `{password}`\n\n"
        f"⚠️ Сохраните эти данные!",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=kb_main()
    )
    return MAIN_MENU

async def handle_enter_pass(update: Update, context: ContextTypes.DEFAULT_TYPE):
    password = update.message.text.strip()
    gen_pass = context.user_data.get('gen_pass', '')
    
    if gen_pass and password == gen_pass:
        del context.user_data['gen_pass']
        return await handle_create(update, context)
    elif gen_pass:
        await update.message.reply_text("❌ Пароли не совпадают!")
        return ENTER_PASS
    else:
        return await handle_create(update, context)

async def handle_login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    storage_id = update.message.text.strip()
    
    if len(storage_id) != 5 or not storage_id.isdigit():
        await update.message.reply_text("❌ ID должен быть 5 цифр!")
        return LOGIN
    
    if not os.path.exists(os.path.join(DATA_DIR, storage_id)):
        await update.message.reply_text("❌ Хранилище не найдено!", reply_markup=kb_start())
        return START
    
    context.user_data['login_id'] = storage_id
    await update.message.reply_text("🔐 Введите пароль:")
    return ENTER_LOGIN_PASS

async def handle_login_pass(update: Update, context: ContextTypes.DEFAULT_TYPE):
    password = update.message.text.strip()
    storage_id = context.user_data.get('login_id', '')
    
    if not storage_id:
        await update.message.reply_text("❌ Ошибка!", reply_markup=kb_start())
        return START
    
    storage = UserStorage(storage_id)
    if storage.check_password(password):
        session_id = SessionManager.create(update.effective_user.id, storage_id)
        context.user_data['session_id'] = session_id
        context.user_data['storage_id'] = storage_id
        del context.user_data['login_id']
        
        await update.message.reply_text("✅ *Вход выполнен!*", parse_mode=ParseMode.MARKDOWN, reply_markup=kb_main())
        return MAIN_MENU
    else:
        await update.message.reply_text("❌ Неверный пароль!", reply_markup=kb_start())
        return START

async def handle_new_folder(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = update.message.text.strip()
    
    if not name:
        await update.message.reply_text("❌ Введите название!")
        return CREATE_FOLDER
    
    if 'storage_id' not in context.user_data:
        await update.message.reply_text("❌ Сессия истекла!", reply_markup=kb_start())
        return START
    
    storage = UserStorage(context.user_data['storage_id'])
    if storage.create_folder(name):
        await update.message.reply_text(f"✅ Папка *{name}* создана!", parse_mode=ParseMode.MARKDOWN, reply_markup=kb_main())
    else:
        await update.message.reply_text("❌ Папка уже существует!")
    
    return MAIN_MENU

async def handle_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка загрузки файлов"""
    message = update.message
    ud = context.user_data
    
    if 'storage_id' not in ud:
        await message.reply_text("❌ Сессия истекла!", reply_markup=kb_start())
        return START
    
    folder = ud.get('upload_folder')
    if not folder:
        storage = UserStorage(ud['storage_id'])
        await message.reply_text("📂 Сначала выберите папку:", reply_markup=kb_folders(storage.get_folders(), "upl"))
        return SELECT_FOLDER
    
    if 'session_id' in ud:
        SessionManager.update(ud['session_id'])
    
    storage = UserStorage(ud['storage_id'])
    
    try:
        file_obj = None
        filename = ""
        file_type = ""
        
        if message.document:
            file_obj = await message.document.get_file()
            filename = message.document.file_name or f"doc_{int(time.time())}.bin"
            file_type = "document"
        
        elif message.photo:
            file_obj = await message.photo[-1].get_file()
            filename = f"photo_{int(time.time())}.jpg"
            file_type = "photo"
        
        elif message.video:
            file_obj = await message.video.get_file()
            filename = message.video.file_name or f"video_{int(time.time())}.mp4"
            file_type = "video"
        
        elif message.audio:
            file_obj = await message.audio.get_file()
            filename = message.audio.file_name or f"audio_{int(time.time())}.mp3"
            file_type = "audio"
        
        elif message.voice:
            file_obj = await message.voice.get_file()
            filename = f"voice_{int(time.time())}.ogg"
            file_type = "voice"
        
        elif message.video_note:
            file_obj = await message.video_note.get_file()
            filename = f"videonote_{int(time.time())}.mp4"
            file_type = "video_note"
        
        elif message.text:
            # Текстовая заметка
            text_content = message.text
            text_filename = f"note_{int(time.time())}.txt"
            file_id = f"text_{int(time.time())}_{random.randint(1000, 9999)}"
            
            folder_path = storage.ensure_folder(folder)
            text_path = os.path.join(folder_path, f"{file_id}_{text_filename}")
            
            with open(text_path, 'w', encoding='utf-8') as f:
                f.write(text_content)
            
            meta = {
                'file_id': file_id,
                'filename': text_filename,
                'original': text_filename,
                'saved_at': datetime.now().isoformat(),
                'path': text_path,
                'size': len(text_content.encode('utf-8')),
                'folder': folder,
                'type': 'text'
            }
            
            meta_path = os.path.join(folder_path, f"{file_id}.meta")
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)
            
            await message.reply_text(
                f"✅ *Заметка сохранена!*\n\n"
                f"📂 Папка: *{folder}*\n"
                f"📝 Размер: {len(text_content)} символов",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=kb_after_upload(folder)
            )
            return UPLOAD_FILE
        
        else:
            await message.reply_text("❌ Неподдерживаемый тип!", reply_markup=kb_after_upload(folder))
            return UPLOAD_FILE
        
        # Скачиваем файл
        if file_obj:
            file_bytes = await file_obj.download_as_bytearray()
            file_size = len(file_bytes)
            
            if file_size > 20 * 1024 * 1024:
                await message.reply_text("❌ Файл больше 20 МБ!", reply_markup=kb_after_upload(folder))
                return UPLOAD_FILE
            
            if storage.save_file(file_obj.file_id, bytes(file_bytes), filename, folder, file_type):
                size_str = f"{file_size/1024:.1f} KB" if file_size < 1024*1024 else f"{file_size/(1024*1024):.2f} MB"
                
                await message.reply_text(
                    f"✅ *Файл сохранен!*\n\n"
                    f"📂 Папка: *{folder}*\n"
                    f"📄 Имя: {filename}\n"
                    f"📏 Размер: {size_str}\n"
                    f"🏷 Тип: {file_type}",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=kb_after_upload(folder)
                )
                logger.info(f"Сохранен файл: {filename} в {folder}")
            else:
                await message.reply_text("❌ Ошибка сохранения!", reply_markup=kb_after_upload(folder))
        
    except Exception as e:
        logger.error(f"Ошибка загрузки: {e}", exc_info=True)
        await message.reply_text("❌ Ошибка обработки файла!", reply_markup=kb_after_upload(folder))
    
    return UPLOAD_FILE

async def handle_contact_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    user = message.from_user
    
    mid = f"{user.id}_{int(time.time())}"
    admin_messages[mid] = {
        'from_user': user.username or user.first_name or str(user.id),
        'from_id': user.id,
        'text': message.text or "[Фото/Файл]",
        'time': datetime.now().isoformat()
    }
    
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(
                admin_id,
                f"✉️ *Сообщение от {admin_messages[mid]['from_user']}:*\n\n{admin_messages[mid]['text']}",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📩 Ответить", callback_data=f"replymsg_{mid}")]])
            )
        except Exception as e:
            logger.error(f"Ошибка уведомления админа: {e}")
    
    await message.reply_text("✅ Сообщение отправлено!", reply_markup=kb_back())
    return MAIN_MENU

async def handle_admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return START
    
    text = update.message.text
    mid = context.user_data.get('reply_msg', '')
    
    if mid and mid in admin_messages:
        mdata = admin_messages[mid]
        try:
            await context.bot.send_message(
                mdata['from_id'],
                f"📩 *Ответ от администратора:*\n\n{text}",
                parse_mode=ParseMode.MARKDOWN
            )
            del admin_messages[mid]
            await update.message.reply_text("✅ Ответ отправлен!", reply_markup=kb_admin())
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка: {e}")
    
    return ADMIN_PANEL

async def handle_add_channel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return START
    
    channel = update.message.text.strip()
    if not channel.startswith("@"):
        channel = "@" + channel
    
    if ChannelManager.add(channel):
        await update.message.reply_text(f"✅ Канал {channel} добавлен!", reply_markup=kb_admin())
    else:
        await update.message.reply_text("❌ Канал уже существует!")
    
    return ADMIN_PANEL

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Ошибка: {context.error}", exc_info=True)
    try:
        if update and update.message:
            await update.message.reply_text("❌ Ошибка! /start")
    except:
        pass

# ===================== MAIN =====================
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    
    conv = ConversationHandler(
        entry_points=[
            CommandHandler('start', cmd_start),
            CommandHandler('login', cmd_login),
            CommandHandler('admin', cmd_admin)
        ],
        states={
            START: [CallbackQueryHandler(button_handler)],
            CHECK_SUB: [CallbackQueryHandler(button_handler)],
            CREATE_STORAGE: [
                CallbackQueryHandler(button_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_create)
            ],
            ENTER_PASS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_enter_pass)
            ],
            LOGIN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_login)
            ],
            ENTER_LOGIN_PASS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_login_pass)
            ],
            MAIN_MENU: [CallbackQueryHandler(button_handler)],
            SELECT_FOLDER: [CallbackQueryHandler(button_handler)],
            CREATE_FOLDER: [
                CallbackQueryHandler(button_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_new_folder)
            ],
            UPLOAD_FILE: [
                CallbackQueryHandler(button_handler),
                MessageHandler(
                    (filters.Document.ALL | filters.PHOTO | filters.VIDEO | 
                     filters.AUDIO | filters.VOICE | filters.VIDEO_NOTE | 
                     filters.TEXT) & ~filters.COMMAND,
                    handle_upload
                )
            ],
            VIEW_FILES: [CallbackQueryHandler(button_handler)],
            SETTINGS: [CallbackQueryHandler(button_handler)],
            CONFIRM_DELETE: [CallbackQueryHandler(button_handler)],
            ADMIN_PANEL: [CallbackQueryHandler(button_handler)],
            CONTACT_ADMIN: [
                CallbackQueryHandler(button_handler),
                MessageHandler((filters.TEXT | filters.PHOTO) & ~filters.COMMAND, handle_contact_admin)
            ],
            ADMIN_REPLY: [
                CallbackQueryHandler(button_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_reply)
            ],
            ADD_CHANNEL: [
                CallbackQueryHandler(button_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_add_channel)
            ],
        },
        fallbacks=[
            CommandHandler('start', cmd_start),
            CommandHandler('login', cmd_login),
            CommandHandler('help', cmd_help),
            CommandHandler('admin', cmd_admin)
        ],
    )
    
    app.add_handler(conv)
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_error_handler(error_handler)
    
    logger.info("Бот запущен!")
    print(f"Base: {BASE_DIR}")
    print(f"Data: {DATA_DIR}")
    print(f"Files: {FILES_DIR}")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)

if __name__ == '__main__':
    main()
