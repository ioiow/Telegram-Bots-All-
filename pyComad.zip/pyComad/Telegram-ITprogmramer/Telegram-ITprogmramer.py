import logging
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)

# Настройки
BOT_TOKEN = "8269204829:AAFsDnrmHJqDB_vmNTsDlkmZqVAOUzqYEew"
CHANNEL_USERNAME = "@IT_Programmer_io"  # Без @ тоже работает
ADMIN_ID = 8550701850  # Замени на свой ID (узнать можно через @userinfobot)
WEBSITE_LINK = "http://t.me/DevCodePro_bot/link"  # Ваша ссылка (скрытая)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Глобальное хранилище для диалогов
user_dialogs = {}  # {user_id: {"last_message": message_text, "awaiting_reply": bool}}

# ========== КЛАВИАТУРЫ ==========
def get_main_keyboard():
    """Клавиатура с командами внизу экрана"""
    keyboard = [
        [KeyboardButton("🌐 Сайт")],
        [KeyboardButton("📝 Написать админу"), KeyboardButton("ℹ️ Помощь")],
        [KeyboardButton("📢 Проверить подписку")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_admin_keyboard():
    """Клавиатура для администратора"""
    keyboard = [
        [KeyboardButton("📋 Диалоги")],
        [KeyboardButton("📊 Статистика"), KeyboardButton("🚫 Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_subscription_keyboard():
    """Инлайн-клавиатура для подписки"""
    keyboard = [
        [InlineKeyboardButton("📢 Подписаться на канал", url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}")],
        [InlineKeyboardButton("✅ Я подписался", callback_data="check_subscription")]
    ]
    return InlineKeyboardMarkup(keyboard)

# ========== ПРОВЕРКА ПОДПИСКИ НА КАНАЛ ==========
async def check_subscription(user_id: int, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Проверяет, подписан ли пользователь на канал"""
    try:
        chat_member = await context.bot.get_chat_member(
            chat_id=CHANNEL_USERNAME,
            user_id=user_id
        )
        return chat_member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Ошибка проверки подписки: {e}")
        return False

# ========== ОБРАБОТЧИК КОМАНДЫ /start ==========
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        await update.message.reply_text(
            "📢 Для использования бота необходимо подписаться на наш канал!\n"
            f"Канал: {CHANNEL_USERNAME}\n\n"
            "После подписки нажмите кнопку '✅ Я подписался'",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    # Если подписан, показываем главное меню с клавиатурой
    await show_main_menu(update, context)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает главное меню после успешной подписки"""
    # Создаем HTML-разметку со скрытой ссылкой
    welcome_text = (
        "👋 <b>Приветствую! Здравствуйте!</b>\n\n"
        "Воспользуйтесь нашим сайтом!\n\n"
        f"🌐 - <a href='{WEBSITE_LINK}'>Web</a>\n\n"
        "👇 <i>Используйте кнопки ниже для навигации</i>"
    )
    
    # Показываем клавиатуру с командами
    await update.message.reply_text(
        welcome_text, 
        reply_markup=get_main_keyboard(),
        parse_mode='HTML',
        disable_web_page_preview=True
    )

# ========== ОБРАБОТЧИК КНОПКИ ПРОВЕРКИ ПОДПИСКИ ==========
async def check_subscription_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    
    if is_subscribed:
        welcome_text = (
            "✅ <b>Подписка подтверждена!</b>\n\n"
            f"🌐 - <a href='{WEBSITE_LINK}'>Web</a>\n\n"
            "👇 <i>Используйте кнопки ниже для навигации</i>"
        )
        
        await query.edit_message_text(
            welcome_text,
            parse_mode='HTML',
            disable_web_page_preview=True
        )
        await context.bot.send_message(
            chat_id=user_id,
            text="Теперь вы можете использовать все функции бота:",
            reply_markup=get_main_keyboard()
        )
    else:
        await query.edit_message_text(
            "❌ Вы ещё не подписались на канал!\n"
            f"Пожалуйста, подпишитесь: {CHANNEL_USERNAME}\n"
            "и нажмите кнопку проверки снова.",
            reply_markup=get_subscription_keyboard()
        )

# ========== ОБРАБОТКА КНОПКИ "НАПИСАТЬ АДМИНУ" ==========
async def handle_write_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие кнопки 'Написать админу'"""
    user_id = update.effective_user.id
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        await update.message.reply_text(
            "❌ Сначала подпишитесь на канал!",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    # Устанавливаем флаг ожидания сообщения
    context.user_data['awaiting_admin_message'] = True
    
    await update.message.reply_text(
        "✍️ Напишите своё сообщение Администратору:\n\n"
        "Просто напишите текст сообщения и отправьте его.",
        parse_mode='HTML',
        reply_markup=ReplyKeyboardMarkup([[KeyboardButton("🚫 Отмена")]], resize_keyboard=True)
    )

# ========== ОБРАБОТКА КНОПКИ "САЙТ" ==========
async def handle_website(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие кнопки 'Сайт'"""
    user_id = update.effective_user.id
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        await update.message.reply_text(
            "❌ Сначала подпишитесь на канал!",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    await update.message.reply_text(
        f"🌐 <b>Наш сайт:</b>\n\n"
        f"Перейдите по ссылке: <a href='{WEBSITE_LINK}'>Web</a>",
        parse_mode='HTML',
        disable_web_page_preview=True,
        reply_markup=get_main_keyboard()
    )

# ========== ОБРАБОТКА КНОПКИ "ПОМОЩЬ" ==========
async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие кнопки 'Помощь'"""
    help_text = (
        "🆘 Помощь по использованию бота:\n\n"
        "• Сайт - получить ссылку на наш сайт\n"
        "• Написать админу - отправить сообщение администратору\n"
        "• Проверить подписку - проверить статус подписки на канал\n\n"
        "Все функции доступны после подписки на наш канал!\n"
        f"Канал: {CHANNEL_USERNAME}"
    )
    
    await update.message.reply_text(
        help_text,
        parse_mode='HTML',
        reply_markup=get_main_keyboard()
    )

# ========== ОБРАБОТКА КНОПКИ "ПРОВЕРИТЬ ПОДПИСКУ" ==========
async def handle_check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие кнопки 'Проверить подписку'"""
    user_id = update.effective_user.id
    
    is_subscribed = await check_subscription(user_id, context)
    
    if is_subscribed:
        await update.message.reply_text(
            "✅ Вы подписаны на канал!\n\n"
            "Вы можете использовать все функции бота.",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )
    else:
        await update.message.reply_text(
            "❌ Вы не подписаны на канал!\n\n"
            f"Пожалуйста, подпишитесь: {CHANNEL_USERNAME}",
            reply_markup=get_subscription_keyboard()
        )

# ========== ОБРАБОТКА КНОПКИ "ОТМЕНА" ==========
async def handle_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие кнопки 'Отмена'"""
    user_id = update.effective_user.id
    
    if 'awaiting_admin_message' in context.user_data:
        context.user_data['awaiting_admin_message'] = False
    
    # Если это админ, показываем админскую клавиатуру
    if str(user_id) == str(ADMIN_ID):
        if 'admin_reply_mode' in context.user_data:
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
        await update.message.reply_text(
            "🚫 Действие отменено",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )
    else:
        await update.message.reply_text(
            "🚫 Действие отменено",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )

# ========== ОБРАБОТКА ТЕКСТА ДЛЯ АДМИНА ==========
async def handle_user_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает текст от пользователя для отправки админу"""
    user = update.effective_user
    user_id = user.id
    message_text = update.message.text
    
    # ========== ИСПРАВЛЕНИЕ: Если это админ, передаём обработку в handle_admin_message ==========
    if str(user_id) == str(ADMIN_ID):
        await handle_admin_message(update, context)
        return
    # ========== КОНЕЦ ИСПРАВЛЕНИЯ ==========
    
    # Если это команда через кнопки, пропускаем
    if message_text in ["🌐 Сайт", "📝 Написать админу", "ℹ️ Помощь", "📢 Проверить подписку", "🚫 Отмена"]:
        return
    
    # Проверяем подписку при каждом сообщении
    is_subscribed = await check_subscription(user_id, context)
    if not is_subscribed:
        await update.message.reply_text(
            "❌ Сначала подпишитесь на канал!",
            reply_markup=get_subscription_keyboard()
        )
        return
    
    # Если пользователь ожидает отправки сообщения админу
    if context.user_data.get('awaiting_admin_message', False):
        # Формируем сообщение для админа
        admin_message = (
            f"📩 Новое сообщение от пользователя:\n\n"
            f"👤 ID: {user_id}\n"
            f"📛 Имя: {user.full_name}\n"
            f"🔗 Username: @{user.username if user.username else 'нет'}\n"
            f"📝 Сообщение:\n───────\n{message_text}\n───────"
        )
        
        # Сохраняем информацию о сообщении
        if user_id not in user_dialogs:
            user_dialogs[user_id] = []
        
        user_dialogs[user_id].append({
            "from_user": True,
            "text": message_text,
            "timestamp": update.message.date
        })
        
        # Кнопка для ответа
        keyboard = [[
            InlineKeyboardButton("💬 Ответить", callback_data=f"reply_{user_id}")
        ]]
        
        try:
            # Отправляем сообщение админу
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
            
            # Подтверждаем пользователю
            await update.message.reply_text(
                "✅ Ваше сообщение отправлено администратору!\n\n"
                "Ожидайте ответа в этом чате.",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            
        except Exception as e:
            logger.error(f"Ошибка отправки админу: {e}")
            await update.message.reply_text(
                "❌ Ошибка отправки сообщения. Попробуйте позже.",
                reply_markup=get_main_keyboard()
            )
        
        # Сбрасываем флаг ожидания
        context.user_data['awaiting_admin_message'] = False
    
    # Если пользователь просто пишет текст без контекста
    elif not context.user_data.get('awaiting_admin_message', False):
        await update.message.reply_text(
            "ℹ️ Используйте кнопки для навигации:\n\n"
            "• Нажмите 'Написать админу' для обращения\n"
            "• Нажмите 'Сайт' для перехода на сайт\n"
            "• Нажмите 'Помощь' для справки",
            parse_mode='HTML',
            reply_markup=get_main_keyboard()
        )

# ========== ОБРАБОТКА ОТВЕТА АДМИНА ==========
async def handle_admin_reply_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатие кнопки 'Ответить' у админа"""
    query = update.callback_query
    await query.answer()
    
    # Проверяем, что это админ
    if str(query.from_user.id) != str(ADMIN_ID):
        await query.answer("❌ Только администратор может отвечать!", show_alert=True)
        return
    
    # Извлекаем ID пользователя из callback_data
    data = query.data
    if data.startswith("reply_"):
        target_user_id = int(data.split("_")[1])
        
        # Сохраняем данные для ответа в user_data админа
        context.user_data['admin_reply_mode'] = True
        context.user_data['target_user_id'] = target_user_id
        context.user_data['original_message_id'] = query.message.message_id
        
        await query.message.reply_text(
            f"💬 Вы отвечаете пользователю (ID: {target_user_id})\n\n"
            "Введите ваш ответ:",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает сообщения от админа (ответы пользователям)"""
    user_id = update.effective_user.id
    
    # Проверяем, что это админ
    if str(user_id) != str(ADMIN_ID):
        return
    
    text = update.message.text
    
    # Обработка команд админа через кнопки
    if text == "📋 Диалоги":
        await show_admin_dialogs(update, context)
        return
    elif text == "📊 Статистика":
        await show_admin_stats(update, context)
        return
    elif text == "🚫 Отмена":
        if 'admin_reply_mode' in context.user_data:
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
        await update.message.reply_text(
            "🚫 Режим ответа отменен",
            reply_markup=get_admin_keyboard()
        )
        return
    
    # Если админ в режиме ответа
    if context.user_data.get('admin_reply_mode', False):
        target_user_id = context.user_data.get('target_user_id')
        admin_reply_text = text
        
        if not target_user_id:
            await update.message.reply_text("❌ Ошибка: не найден пользователь для ответа")
            context.user_data['admin_reply_mode'] = False
            return
        
        try:
            # Отправляем ответ пользователю
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"📨 Ответ от администратора:\n\n{admin_reply_text}",
                parse_mode='HTML',
                reply_markup=get_main_keyboard()
            )
            
            # Сохраняем в историю диалога
            if target_user_id not in user_dialogs:
                user_dialogs[target_user_id] = []
            
            user_dialogs[target_user_id].append({
                "from_user": False,
                "text": admin_reply_text,
                "timestamp": update.message.date
            })
            
            # Подтверждаем админу
            await update.message.reply_text(
                f"✅ Ответ отправлен пользователю (ID: {target_user_id})!",
                parse_mode='HTML',
                reply_markup=get_admin_keyboard()
            )
            
            # Сбрасываем режим ответа
            context.user_data['admin_reply_mode'] = False
            context.user_data['target_user_id'] = None
            
        except Exception as e:
            logger.error(f"Ошибка отправки ответа пользователю: {e}")
            
            if "Forbidden" in str(e):
                await update.message.reply_text(
                    f"❌ Не удалось отправить сообщение пользователю (ID: {target_user_id}).\n"
                    "Возможно, пользователь заблокировал бота.",
                    reply_markup=get_admin_keyboard()
                )
            else:
                await update.message.reply_text(
                    f"❌ Ошибка: {str(e)}",
                    reply_markup=get_admin_keyboard()
                )
    else:
        # Если админ не в режиме ответа, показываем подсказку
        await update.message.reply_text(
            "ℹ️ Вы администратор!\n\n"
            "Чтобы ответить пользователю, нажмите кнопку '💬 Ответить' под его сообщением.",
            parse_mode='HTML',
            reply_markup=get_admin_keyboard()
        )

# ========== ФУНКЦИИ ДЛЯ АДМИНА ==========
async def show_admin_dialogs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает активные диалоги админу"""
    if not user_dialogs:
        await update.message.reply_text("📭 Нет активных диалогов", reply_markup=get_admin_keyboard())
        return
    
    message = "📋 Активные диалоги:\n\n"
    count = 1
    for user_id, messages in user_dialogs.items():
        try:
            user_info = await context.bot.get_chat(user_id)
            username = f"@{user_info.username}" if user_info.username else "нет username"
            message += f"{count}. 👤 {user_info.full_name} ({username})\n"
            message += f"   🔹 ID: {user_id}\n"
            message += f"   🔹 Сообщений: {len(messages)}\n"
            last_text = messages[-1]['text'][:50] if len(messages[-1]['text']) > 50 else messages[-1]['text']
            message += f"   🔹 Последнее: {last_text}...\n\n"
            count += 1
        except Exception as e:
            logger.error(f"Ошибка получения информации о пользователе {user_id}: {e}")
            message += f"{count}. 👤 Пользователь ID: {user_id}\n"
            message += f"   🔹 Сообщений: {len(messages)}\n\n"
            count += 1
    
    await update.message.reply_text(message, parse_mode='HTML', reply_markup=get_admin_keyboard())

async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает статистику админу"""
    total_users = len(user_dialogs)
    total_messages = sum(len(messages) for messages in user_dialogs.values())
    
    stats_text = (
        f"📊 Статистика бота:\n\n"
        f"🔹 Всего диалогов: {total_users}\n"
        f"🔹 Всего сообщений: {total_messages}\n"
        f"🔹 Сообщений в среднем: {total_messages/total_users if total_users > 0 else 0:.1f}\n\n"
        f"Для просмотра диалогов нажмите '📋 Диалоги'"
    )
    
    await update.message.reply_text(stats_text, parse_mode='HTML', reply_markup=get_admin_keyboard())

# ========== ПРОВЕРКА ПОДПИСКИ В РЕАЛЬНОМ ВРЕМЕНИ ==========
async def check_message_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Проверяет подписку при каждом сообщении"""
    user_id = update.effective_user.id
    
    # Пропускаем команды и кнопки
    if update.message and update.message.text:
        text = update.message.text
        if text.startswith('/') or text in ["🌐 Сайт", "📝 Написать админу", "ℹ️ Помощь", "📢 Проверить подписку", "🚫 Отмена", "📋 Диалоги", "📊 Статистика"]:
            return
    
    # Пропускаем сообщения от админа
    if str(user_id) == str(ADMIN_ID):
        return
    
    # Проверяем подписку
    is_subscribed = await check_subscription(user_id, context)
    
    if not is_subscribed:
        await update.message.reply_text(
            "❌ Для использования бота необходимо подписаться на канал!\n\n"
            f"Канал: {CHANNEL_USERNAME}\n\n"
            "Подпишитесь и нажмите 'Проверить подписку'",
            reply_markup=get_subscription_keyboard()
        )

# ========== КОМАНДА ДЛЯ АДМИНА /dialogs ==========
async def admin_dialogs_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда для админа посмотреть диалоги"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        await update.message.reply_text("❌ Эта команда только для администратора!")
        return
    
    await show_admin_dialogs(update, context)

# ========== КОМАНДА ДЛЯ АДМИНА /stats ==========
async def admin_stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда для админа посмотреть статистику"""
    if str(update.effective_user.id) != str(ADMIN_ID):
        await update.message.reply_text("❌ Эта команда только для администратора!")
        return
    
    await show_admin_stats(update, context)

# ========== ОСНОВНАЯ ФУНКЦИЯ ==========
def main():
    """Запуск бота"""
    # Создаем приложение
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Добавляем обработчики команд
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("dialogs", admin_dialogs_command))
    application.add_handler(CommandHandler("stats", admin_stats_command))
    
    # Обработчики callback'ов
    application.add_handler(CallbackQueryHandler(check_subscription_callback, pattern="^check_subscription$"))
    application.add_handler(CallbackQueryHandler(handle_admin_reply_button, pattern="^reply_"))
    
    # Обработчики кнопок клавиатуры
    application.add_handler(MessageHandler(filters.Text(["🌐 Сайт"]), handle_website))
    application.add_handler(MessageHandler(filters.Text(["📝 Написать админу"]), handle_write_to_admin))
    application.add_handler(MessageHandler(filters.Text(["ℹ️ Помощь"]), handle_help))
    application.add_handler(MessageHandler(filters.Text(["📢 Проверить подписку"]), handle_check_subscription))
    application.add_handler(MessageHandler(filters.Text(["🚫 Отмена"]), handle_cancel))
    
    # Обработчик текстовых сообщений (один обработчик для всех)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_user_text))
    
    # Запускаем бота
    print("=" * 50)
    print("🤖 Бот запущен!")
    print(f"👑 ID администратора: {ADMIN_ID}")
    print(f"📢 Канал для подписки: {CHANNEL_USERNAME}")
    print("=" * 50)
    print("\n📱 Клавиатура с командами:")
    print("┌─────────────────────────┐")
    print("│        🌐 Сайт         │")
    print("├─────────────────────────┤")
    print("│ 📝 Написать админу     │")
    print("│ ℹ️ Помощь              │")
    print("├─────────────────────────┤")
    print("│ 📢 Проверить подписку  │")
    print("└─────────────────────────┘")
    print("\n👑 Для админа:")
    print("• /dialogs - посмотреть диалоги")
    print("• /stats - статистика")
    print("• Кнопка 'Ответить' под сообщениями")
    print("=" * 50)
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()