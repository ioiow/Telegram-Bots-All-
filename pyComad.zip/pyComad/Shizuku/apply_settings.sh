#!/data/data/com.termux/files/usr/bin/bash
# Скрипт для автоматической отправки команд в Set Edit через Shizuku

PACKAGE="com.axlebolt.standoff2"
SETEDIT_PACKAGE="by4a.setedit22"

# Путь к rish (измените если нужно)
RISH_PATH="/storage/emulated/0/Download/pyComad/Test/rish"

# Проверка наличия rish
if [ ! -f "$RISH_PATH" ]; then
    echo "Ошибка: rish не найден!"
    echo "Убедитесь что Shizuku установлен и rish собран"
    exit 1
fi

# Проверка работы Shizuku
if ! $RISH_PATH whoami > /dev/null 2>&1; then
    echo "Ошибка: Shizuku не работает!"
    echo "Запустите Shizuku и предоставьте права Termux"
    exit 1
fi

# Список команд
commands=(
    "r_fps_max 121"
    "r_vertical_sync 0" 
    "r_display_refresh_rate 120"
    "r_tex_quality 0"
    "r_shadows 0"
    "r_ssao 0"
    "r_antialiasing 0"
    "r_dynamic_lighting 0"
    "r_motion_blur 0"
    "r_dof 0"
    "r_multithread 1"
    "r_low_latency 1"
    "r_particle_quality 0"
    "r_skin_quality 0"
    "r_flash_impact 0"
    "r_post_process 0"
    "r_lighting_quality 0"
    "r_geometry_quality 0"
    "r_decal_life_time 0"
    "r_water_quality 0"
    "r_tex_filtering 0"
    "r_cloud_quality 0"
)

echo "Использую Set Edit: $SETEDIT_PACKAGE"
echo "Для игры: $PACKAGE"
echo ""

# Отправляем команды через rish
for cmd in "${commands[@]}"; do
    echo "Добавляю: $cmd"
    $RISH_PATH am start -n $SETEDIT_PACKAGE/.MainActivity -e command "$cmd" -e package $PACKAGE
    sleep 0.3
done

echo ""
echo "Все команды добавлены! Откройте Set Edit чтобы проверить."
echo "Пакет Set Edit: $SETEDIT_PACKAGE"