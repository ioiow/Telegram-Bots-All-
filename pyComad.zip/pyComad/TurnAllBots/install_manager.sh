#!/bin/bash
echo "📱 Установка Telegram Bots Manager"
echo "=================================="

# Создаем папку если её нет
mkdir -p /storage/emulated/0/Download/pyComad/TurnAllBots

# Копируем файлы
echo "Установка завершена!"
echo "Запускайте: python bot_manager.py"
echo "Все файлы будут сохраняться в: /storage/emulated/0/Download/pyComad/TurnAllBots"
