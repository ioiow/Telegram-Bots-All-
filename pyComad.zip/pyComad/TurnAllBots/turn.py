#!/usr/bin/env python3
"""
📱 Telegram Bots Manager - Advanced Launcher
Управление всеми ботами: запуск, остановка, мониторинг, редактирование путей
"""

import subprocess
import sys
import os
import time
import json
import signal
import threading
from datetime import datetime
from pathlib import Path
import readline  # Для улучшенного ввода в Linux/Termux

# КОНСТАНТЫ ПУТЕЙ
BASE_DIR = "/storage/emulated/0/Download/pyComad/TurnAllBots"
CONFIG_FILE = os.path.join(BASE_DIR, "bots_config.json")
LOGS_DIR = os.path.join(BASE_DIR, "bot_logs")

class BotManager:
    def __init__(self, config_file=CONFIG_FILE):
        # Создаем базовую директорию если её нет
        os.makedirs(BASE_DIR, exist_ok=True)
        
        self.config_file = config_file
        self.logs_dir = LOGS_DIR
        
        print(f"📁 Базовая директория: {BASE_DIR}")
        print(f"⚙️  Конфиг файл: {self.config_file}")
        print(f"📝 Папка логов: {self.logs_dir}")
        
        self.bots = self.load_config()
        self.processes = {}  # bot_id -> process
        
        self.setup_directories()
        
        # Цвета для вывода
        self.COLORS = {
            'HEADER': '\033[95m',
            'OKBLUE': '\033[94m',
            'OKGREEN': '\033[92m',
            'WARNING': '\033[93m',
            'FAIL': '\033[91m',
            'ENDC': '\033[0m',
            'BOLD': '\033[1m',
        }
    
    def setup_directories(self):
        """Создание необходимых директорий"""
        os.makedirs(BASE_DIR, exist_ok=True)
        os.makedirs(self.logs_dir, exist_ok=True)
        print(f"✅ Директории созданы/проверены")
    
    def color_text(self, text, color):
        """Цветной вывод текста"""
        return f"{self.COLORS.get(color, '')}{text}{self.COLORS['ENDC']}"
    
    def load_config(self):
        """Загрузка конфигурации ботов из файла или создание по умолчанию"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                print(f"✅ Загружена конфигурация из {self.config_file}")
                return config
            except Exception as e:
                print(f"⚠️ Ошибка загрузки конфига: {e}. Создаю новый...")
        
        # Конфигурация по умолчанию с абсолютными путями
        default_config = [
            {
                "id": 1,
                "name": "Storage Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-Storage/piece2.py",
                "description": "Бот для хранения файлов",
                "enabled": True,
                "auto_start": True
            },
            {
                "id": 2,
                "name": "Search Person Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-SearchPerson/Telegram-SearchPerson48.py",
                "description": "Поиск людей в Telegram",
                "enabled": True,
                "auto_start": False
            },
            {
                "id": 3,
                "name": "ID Telegram Bot",
                "path": "/storage/emulated/0/Download/pyComad/telegram-Id-telegram/typ.py",
                "description": "Получение ID пользователей",
                "enabled": True,
                "auto_start": False
            },
            {
                "id": 4,
                "name": "GPT Download Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-GptDowland/bot1.py",
                "description": "Загрузка контента GPT",
                "enabled": True,
                "auto_start": False
            },
            {
                "id": 5,
                "name": "GPT Premium Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-GptBuyPremium/Telegram-Py4.py",
                "description": "Покупка премиум GPT",
                "enabled": True,
                "auto_start": False
            },
            {
                "id": 6,
                "name": "Dolgi Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-DolgiBot/bot.py",
                "description": "Бот для учета долгов",
                "enabled": True,
                "auto_start": False
            },
            {
                "id": 7,
                "name": "Chity Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-ChityBot/bot.py",
                "description": "Бот для читов",
                "enabled": True,
                "auto_start": False
            },
            {
                "id": 8,
                "name": "Bitz AI Bot",
                "path": "/storage/emulated/0/Download/pyComad/Telegram-BitzAI/py2.py",
                "description": "AI бот Bitz",
                "enabled": True,
                "auto_start": False
            }
        ]
        
        self.save_config(default_config)
        return default_config
    
    def save_config(self, bots=None):
        """Сохранение конфигурации в файл"""
        if bots is None:
            bots = self.bots
        
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(bots, f, ensure_ascii=False, indent=4)
            print(f"✅ Конфигурация сохранена в {self.config_file}")
            return True
        except Exception as e:
            print(f"❌ Ошибка сохранения конфига: {e}")
            return False
    
    def check_bot_file(self, bot_path):
        """Проверка существования файла бота"""
        if not os.path.exists(bot_path):
            return False, f"Файл не найден: {bot_path}"
        
        if not bot_path.endswith('.py'):
            return False, "Файл должен быть .py файлом"
        
        return True, "OK"
    
    def start_bot(self, bot_id):
        """Запуск конкретного бота"""
        bot = self.get_bot_by_id(bot_id)
        if not bot:
            print(f"❌ Бот с ID {bot_id} не найден")
            return False
        
        if bot_id in self.processes:
            print(f"⚠️ Бот '{bot['name']}' уже запущен")
            return True
        
        if not bot.get('enabled', True):
            print(f"⚠️ Бот '{bot['name']}' отключен в конфигурации")
            return False
        
        # Проверка файла
        is_valid, message = self.check_bot_file(bot['path'])
        if not is_valid:
            print(f"❌ Ошибка запуска '{bot['name']}': {message}")
            return False
        
        try:
            # Создание лог-файла
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_filename = f"{bot['name'].replace(' ', '_')}_{timestamp}.log"
            log_path = os.path.join(self.logs_dir, log_filename)
            
            print(f"🚀 Запуск бота: {self.color_text(bot['name'], 'OKGREEN')}")
            print(f"   📁 Файл: {bot['path']}")
            
            # Запуск процесса
            with open(log_path, 'w') as log_file:
                process = subprocess.Popen(
                    [sys.executable, bot['path']],
                    stdout=log_file,
                    stderr=log_file,
                    preexec_fn=os.setsid  # Для правильного завершения
                )
            
            self.processes[bot_id] = {
                'process': process,
                'log_file': log_path,
                'start_time': datetime.now(),
                'bot_name': bot['name']
            }
            
            # Небольшая задержка для инициализации
            time.sleep(2)
            
            # Проверка, жив ли процесс
            if process.poll() is None:
                print(f"✅ Бот '{bot['name']}' успешно запущен (PID: {process.pid})")
                print(f"   📝 Логи: {log_path}")
                return True
            else:
                print(f"❌ Бот '{bot['name']}' завершился сразу после запуска")
                if bot_id in self.processes:
                    del self.processes[bot_id]
                return False
                
        except Exception as e:
            print(f"❌ Ошибка при запуске бота '{bot['name']}': {e}")
            return False
    
    def stop_bot(self, bot_id):
        """Остановка конкретного бота"""
        if bot_id not in self.processes:
            print(f"⚠️ Бот с ID {bot_id} не запущен")
            return False
        
        bot_info = self.processes[bot_id]
        process = bot_info['process']
        bot_name = bot_info['bot_name']
        
        print(f"🛑 Остановка бота: {self.color_text(bot_name, 'WARNING')}")
        
        try:
            # Попытка мягкой остановки
            process.terminate()
            
            # Ждем завершения
            for _ in range(10):
                if process.poll() is not None:
                    break
                time.sleep(0.5)
            
            # Если не остановился - убиваем
            if process.poll() is None:
                process.kill()
                process.wait()
            
            # Удаляем из списка процессов
            del self.processes[bot_id]
            
            uptime = datetime.now() - bot_info['start_time']
            print(f"✅ Бот '{bot_name}' остановлен")
            print(f"   ⏱️  Время работы: {uptime}")
            return True
            
        except Exception as e:
            print(f"❌ Ошибка при остановке бота '{bot_name}': {e}")
            return False
    
    def restart_bot(self, bot_id):
        """Перезапуск бота"""
        print(f"🔄 Перезапуск бота ID: {bot_id}")
        if bot_id in self.processes:
            self.stop_bot(bot_id)
            time.sleep(1)
        return self.start_bot(bot_id)
    
    def start_all_bots(self):
        """Запуск всех включенных ботов"""
        print("=" * 60)
        print(f"{self.color_text('🚀 ЗАПУСК ВСЕХ БОТОВ', 'OKGREEN')}")
        print("=" * 60)
        
        started_count = 0
        for bot in self.bots:
            if bot.get('enabled', True) and bot.get('auto_start', False):
                if self.start_bot(bot['id']):
                    started_count += 1
                time.sleep(1)  # Пауза между запусками
        
        print(f"\n✅ Запущено {started_count} ботов")
        return started_count
    
    def stop_all_bots(self):
        """Остановка всех ботов"""
        print("=" * 60)
        print(f"{self.color_text('🛑 ОСТАНОВКА ВСЕХ БОТОВ', 'WARNING')}")
        print("=" * 60)
        
        stopped_count = 0
        bot_ids = list(self.processes.keys())
        
        for bot_id in bot_ids:
            if self.stop_bot(bot_id):
                stopped_count += 1
            time.sleep(0.5)
        
        print(f"\n✅ Остановлено {stopped_count} ботов")
        return stopped_count
    
    def show_status(self):
        """Показать статус всех ботов"""
        print("=" * 60)
        print(f"{self.color_text('📊 СТАТУС БОТОВ', 'OKBLUE')}")
        print("=" * 60)
        
        for bot in self.bots:
            bot_id = bot['id']
            status = self.color_text("🟢 ЗАПУЩЕН", "OKGREEN") if bot_id in self.processes else self.color_text("🔴 ОСТАНОВЛЕН", "FAIL")
            enabled = "✅" if bot.get('enabled', True) else "❌"
            auto_start = "⚡" if bot.get('auto_start', False) else "⏸️"
            
            # Проверка файла
            file_ok, file_msg = self.check_bot_file(bot['path'])
            file_status = "📁✅" if file_ok else "📁❌"
            
            print(f"\n{bot_id:2d}. {bot['name']}")
            print(f"   Статус: {status}")
            print(f"   Файл: {file_status} {bot['path']}")
            print(f"   Включен: {enabled} | Автозапуск: {auto_start}")
            print(f"   Описание: {bot.get('description', 'Нет описания')}")
            
            # Дополнительная информация если бот запущен
            if bot_id in self.processes:
                bot_info = self.processes[bot_id]
                uptime = datetime.now() - bot_info['start_time']
                hours = uptime.seconds // 3600
                minutes = (uptime.seconds % 3600) // 60
                print(f"   PID: {bot_info['process'].pid}")
                print(f"   Время работы: {hours:02d}:{minutes:02d}")
                print(f"   Логи: {bot_info['log_file']}")
        
        print(f"\n📈 Всего ботов: {len(self.bots)}")
        print(f"🚀 Запущено: {len(self.processes)}")
        print(f"⏸️  Остановлено: {len(self.bots) - len(self.processes)}")
    
    def get_bot_by_id(self, bot_id):
        """Получить бота по ID"""
        for bot in self.bots:
            if bot['id'] == bot_id:
                return bot
        return None
    
    def edit_bot_path(self, bot_id):
        """Редактирование пути к файлу бота"""
        bot = self.get_bot_by_id(bot_id)
        if not bot:
            print(f"❌ Бот с ID {bot_id} не найден")
            return False
        
        print(f"\n📝 Редактирование пути для бота: {self.color_text(bot['name'], 'OKBLUE')}")
        print(f"Текущий путь: {bot['path']}")
        
        # Предлагаем ввести новый путь
        print(f"\nВведите новый путь к файлу .py")
        print("Или нажмите Enter для отмены")
        print("Пример: /storage/emulated/0/Download/pyComad/НоваяПапка/bot.py")
        
        try:
            new_path = input("> ").strip()
            
            if not new_path:
                print("✋ Отмена редактирования")
                return False
            
            # Проверка нового пути
            is_valid, message = self.check_bot_file(new_path)
            if not is_valid:
                print(f"❌ {message}")
                choice = input("Всё равно сохранить? (y/N): ").lower()
                if choice != 'y':
                    return False
            
            # Если бот запущен - останавливаем
            if bot_id in self.processes:
                print("⚠️ Бот запущен. Останавливаю...")
                self.stop_bot(bot_id)
            
            # Обновляем путь
            old_path = bot['path']
            bot['path'] = new_path
            
            # Сохраняем конфиг
            if self.save_config():
                print(f"✅ Путь обновлён:")
                print(f"   Было: {old_path}")
                print(f"   Стало: {new_path}")
                
                # Предлагаем перезапустить
                restart = input("\nПерезапустить бота с новым путем? (Y/n): ").lower()
                if restart != 'n':
                    self.start_bot(bot_id)
                
                return True
            else:
                print("❌ Ошибка сохранения конфигурации")
                return False
                
        except KeyboardInterrupt:
            print("\n✋ Отмена редактирования")
            return False
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return False
    
    def add_new_bot(self):
        """Добавление нового бота"""
        print("\n" + "=" * 60)
        print(f"{self.color_text('➕ ДОБАВЛЕНИЕ НОВОГО БОТА', 'OKGREEN')}")
        print("=" * 60)
        
        try:
            name = input("Название бота: ").strip()
            if not name:
                print("❌ Название не может быть пустым")
                return False
            
            path = input("Путь к файлу .py: ").strip()
            if not path:
                print("❌ Путь не может быть пустым")
                return False
            
            # Проверка файла
            is_valid, message = self.check_bot_file(path)
            if not is_valid:
                print(f"⚠️ Предупреждение: {message}")
                proceed = input("Всё равно добавить? (y/N): ").lower()
                if proceed != 'y':
                    return False
            
            description = input("Описание (не обязательно): ").strip()
            
            # Находим максимальный ID
            max_id = max([bot['id'] for bot in self.bots]) if self.bots else 0
            
            # Создаём нового бота
            new_bot = {
                "id": max_id + 1,
                "name": name,
                "path": path,
                "description": description,
                "enabled": True,
                "auto_start": False
            }
            
            # Добавляем в список
            self.bots.append(new_bot)
            
            if self.save_config():
                print(f"\n✅ Бот '{name}' успешно добавлен!")
                print(f"   ID: {new_bot['id']}")
                print(f"   Путь: {path}")
                
                # Предлагаем запустить
                start_now = input("\nЗапустить бота сейчас? (Y/n): ").lower()
                if start_now != 'n':
                    self.start_bot(new_bot['id'])
                
                return True
            else:
                print("❌ Ошибка сохранения конфигурации")
                return False
                
        except KeyboardInterrupt:
            print("\n✋ Отмена добавления")
            return False
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return False
    
    def remove_bot(self, bot_id):
        """Удаление бота из конфигурации"""
        bot = self.get_bot_by_id(bot_id)
        if not bot:
            print(f"❌ Бот с ID {bot_id} не найден")
            return False
        
        print(f"\n🗑️  Удаление бота: {self.color_text(bot['name'], 'FAIL')}")
        print(f"   Путь: {bot['path']}")
        
        confirm = input("\n❌ Вы уверены? Это действие нельзя отменить! (y/N): ").lower()
        if confirm != 'y':
            print("✋ Удаление отменено")
            return False
        
        # Останавливаем если запущен
        if bot_id in self.processes:
            self.stop_bot(bot_id)
        
        # Удаляем из списка
        self.bots = [b for b in self.bots if b['id'] != bot_id]
        
        # Перенумеровываем ID для оставшихся ботов
        for i, bot in enumerate(self.bots, 1):
            bot['id'] = i
        
        # Удаляем из процессов
        if bot_id in self.processes:
            del self.processes[bot_id]
        
        if self.save_config():
            print(f"✅ Бот '{bot['name']}' удалён из конфигурации")
            return True
        else:
            print("❌ Ошибка сохранения конфигурации")
            return False
    
    def toggle_auto_start(self, bot_id):
        """Переключение автозапуска бота"""
        bot = self.get_bot_by_id(bot_id)
        if not bot:
            print(f"❌ Бот с ID {bot_id} не найден")
            return False
        
        current = bot.get('auto_start', False)
        bot['auto_start'] = not current
        
        if self.save_config():
            status = "включен" if not current else "выключен"
            print(f"✅ Автозапуск для '{bot['name']}' {status}")
            return True
        else:
            print("❌ Ошибка сохранения конфигурации")
            return False
    
    def toggle_enabled(self, bot_id):
        """Включение/выключение бота"""
        bot = self.get_bot_by_id(bot_id)
        if not bot:
            print(f"❌ Бот с ID {bot_id} не найден")
            return False
        
        current = bot.get('enabled', True)
        bot['enabled'] = not current
        
        # Если выключаем и бот запущен - останавливаем
        if not bot['enabled'] and bot_id in self.processes:
            self.stop_bot(bot_id)
        
        if self.save_config():
            status = "включен" if not current else "выключен"
            print(f"✅ Бот '{bot['name']}' {status}")
            return True
        else:
            print("❌ Ошибка сохранения конфигурации")
            return False
    
    def show_logs(self, bot_id):
        """Показать последние строки логов бота"""
        if bot_id not in self.processes:
            print(f"⚠️ Бот с ID {bot_id} не запущен")
            return False
        
        bot_info = self.processes[bot_id]
        log_file = bot_info['log_file']
        
        if not os.path.exists(log_file):
            print(f"❌ Лог-файл не найден: {log_file}")
            return False
        
        try:
            print(f"\n📋 Логи бота '{bot_info['bot_name']}':")
            print("-" * 60)
            
            with open(log_file, 'r') as f:
                lines = f.readlines()
                
            # Показываем последние 20 строк
            for line in lines[-20:]:
                print(line.rstrip())
            
            print("-" * 60)
            print(f"Файл: {log_file}")
            print(f"Всего строк: {len(lines)}")
            
            return True
            
        except Exception as e:
            print(f"❌ Ошибка чтения логов: {e}")
            return False
    
    def clean_logs(self):
        """Очистка старых логов"""
        try:
            log_files = os.listdir(self.logs_dir)
            removed_count = 0
            
            for log_file in log_files:
                if log_file.endswith('.log'):
                    log_path = os.path.join(self.logs_dir, log_file)
                    # Удаляем файлы старше 7 дней
                    if os.path.getmtime(log_path) < time.time() - (7 * 24 * 3600):
                        os.remove(log_path)
                        removed_count += 1
            
            print(f"✅ Удалено {removed_count} старых лог-файлов")
            return removed_count
            
        except Exception as e:
            print(f"❌ Ошибка очистки логов: {e}")
            return 0

def show_menu():
    """Отображение главного меню"""
    print("\n" + "=" * 60)
    print(f"{'📱 ТЕЛЕГРАМ БОТЫ - МЕНЕДЖЕР':^60}")
    print("=" * 60)
    print(f"Конфиг: {CONFIG_FILE}")
    print("=" * 60)
    print("1. 📊 Показать статус всех ботов")
    print("2. 🚀 Запустить все боты (автозапуск)")
    print("3. 🛑 Остановить все боты")
    print("4. ⚙️  Управление конкретным ботом")
    print("5. 📝 Редактировать путь к файлу бота")
    print("6. ➕ Добавить нового бота")
    print("7. 🗑️  Удалить бота")
    print("8. 📋 Показать логи бота")
    print("9. 🧹 Очистить старые логи")
    print("0. 🔴 Выйти")
    print("=" * 60)

def bot_management_menu(manager):
    """Меню управления конкретным ботом"""
    print("\n" + "=" * 60)
    print(f"{'⚙️  УПРАВЛЕНИЕ БОТОМ':^60}")
    print("=" * 60)
    
    manager.show_status()
    
    try:
        bot_id = int(input("\nВведите ID бота для управления (0 - отмена): "))
        if bot_id == 0:
            return
        
        bot = manager.get_bot_by_id(bot_id)
        if not bot:
            print(f"❌ Бот с ID {bot_id} не найден")
            return
        
        print(f"\nУправление ботом: {manager.color_text(bot['name'], 'OKBLUE')}")
        print("=" * 40)
        print("1. ▶️  Запустить бота")
        print("2. ⏸️  Остановить бота")
        print("3. 🔄 Перезапустить бота")
        print("4. ⚡ Вкл/Выкл автозапуск")
        print("5. ✅ Вкл/Выкл бота")
        print("6. 📋 Показать логи")
        print("0. ↩️  Назад")
        
        choice = input("\nВыберите действие: ").strip()
        
        if choice == '1':
            manager.start_bot(bot_id)
        elif choice == '2':
            manager.stop_bot(bot_id)
        elif choice == '3':
            manager.restart_bot(bot_id)
        elif choice == '4':
            manager.toggle_auto_start(bot_id)
        elif choice == '5':
            manager.toggle_enabled(bot_id)
        elif choice == '6':
            manager.show_logs(bot_id)
        elif choice == '0':
            return
        else:
            print("❌ Неверный выбор")
            
    except ValueError:
        print("❌ Введите число!")
    except KeyboardInterrupt:
        print("\n✋ Отмена")

def main():
    """Главная функция"""
    # Очистка экрана
    os.system('cls' if os.name == 'nt' else 'clear')
    
    print(f"{'🚀 TELEGRAM BOTS MANAGER':^60}")
    print(f"{'Version 3.0 - TurnAllBots':^60}")
    print("=" * 60)
    print(f"📁 Все файлы сохраняются в: {BASE_DIR}")
    print("=" * 60)
    
    manager = BotManager()
    
    # Запуск ботов с автозапуском
    print("\nЗапуск ботов с автозапуском...")
    manager.start_all_bots()
    
    while True:
        try:
            show_menu()
            choice = input("\nВыберите действие: ").strip()
            
            if choice == '1':
                os.system('cls' if os.name == 'nt' else 'clear')
                manager.show_status()
                
            elif choice == '2':
                manager.start_all_bots()
                
            elif choice == '3':
                confirm = input("\nОстановить ВСЕ боты? (y/N): ").lower()
                if confirm == 'y':
                    manager.stop_all_bots()
                    
            elif choice == '4':
                os.system('cls' if os.name == 'nt' else 'clear')
                bot_management_menu(manager)
                
            elif choice == '5':
                os.system('cls' if os.name == 'nt' else 'clear')
                manager.show_status()
                try:
                    bot_id = int(input("\nВведите ID бота для редактирования пути: "))
                    manager.edit_bot_path(bot_id)
                except ValueError:
                    print("❌ Введите число!")
                    
            elif choice == '6':
                manager.add_new_bot()
                
            elif choice == '7':
                os.system('cls' if os.name == 'nt' else 'clear')
                manager.show_status()
                try:
                    bot_id = int(input("\nВведите ID бота для удаления: "))
                    manager.remove_bot(bot_id)
                except ValueError:
                    print("❌ Введите число!")
                    
            elif choice == '8':
                os.system('cls' if os.name == 'nt' else 'clear')
                manager.show_status()
                try:
                    bot_id = int(input("\nВведите ID бота для просмотра логов: "))
                    manager.show_logs(bot_id)
                except ValueError:
                    print("❌ Введите число!")
                    
            elif choice == '9':
                confirm = input("\nОчистить логи старше 7 дней? (y/N): ").lower()
                if confirm == 'y':
                    manager.clean_logs()
                    
            elif choice == '0':
                print("\n" + "=" * 60)
                print(f"{'👋 ВЫХОД ИЗ ПРОГРАММЫ':^60}")
                print("=" * 60)
                
                # Останавливаем все боты при выходе
                if manager.processes:
                    confirm = input("\nОстановить все боты перед выходом? (Y/n): ").lower()
                    if confirm != 'n':
                        manager.stop_all_bots()
                
                print("\nДо свидания! 👋")
                break
                
            else:
                print("❌ Неверный выбор. Попробуйте снова.")
                
            input("\nНажмите Enter для продолжения...")
            os.system('cls' if os.name == 'nt' else 'clear')
            
        except KeyboardInterrupt:
            print(f"\n\n{manager.color_text('⚠️  ПРЕРЫВАНИЕ', 'WARNING')}")
            confirm = input("\nОстановить все боты и выйти? (Y/n): ").lower()
            if confirm != 'n':
                if manager.processes:
                    manager.stop_all_bots()
                break

def create_installation_script():
    """Создание скрипта установки"""
    install_script = os.path.join(BASE_DIR, "install_manager.sh")
    
    install_content = '''#!/bin/bash
echo "📱 Установка Telegram Bots Manager"
echo "=================================="

# Создаем папку если её нет
mkdir -p /storage/emulated/0/Download/pyComad/TurnAllBots

# Копируем файлы
echo "Установка завершена!"
echo "Запускайте: python bot_manager.py"
echo "Все файлы будут сохраняться в: /storage/emulated/0/Download/pyComad/TurnAllBots"
'''
    
    with open(install_script, 'w') as f:
        f.write(install_content)
    
    os.chmod(install_script, 0o755)
    print(f"✅ Создан скрипт установки: {install_script}")

if __name__ == "__main__":
    try:
        # Создаем скрипт установки
        create_installation_script()
        
        # Создаем README файл
        readme_file = os.path.join(BASE_DIR, "README.md")
        with open(readme_file, 'w', encoding='utf-8') as f:
            f.write("# Telegram Bots Manager\n\n")
            f.write("## 📁 Файлы конфигурации:\n")
            f.write(f"- Конфиг: `{CONFIG_FILE}`\n")
            f.write(f"- Логи: `{LOGS_DIR}/`\n")
            f.write(f"- Скрипт: `{os.path.join(BASE_DIR, 'bot_manager.py')}`\n\n")
            f.write("## 🚀 Использование:\n")
            f.write("```bash\npython bot_manager.py\n```\n")
        
        print("=" * 60)
        print(f"📁 БАЗОВАЯ ДИРЕКТОРИЯ: {BASE_DIR}")
        print("=" * 60)
        print("📋 Файлы которые будут созданы:")
        print(f"1. {CONFIG_FILE} - конфигурация ботов")
        print(f"2. {LOGS_DIR}/ - папка с логами")
        print(f"3. install_manager.sh - скрипт установки")
        print(f"4. README.md - документация")
        print("=" * 60)
        
        main()
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        input("\nНажмите Enter для выхода...")