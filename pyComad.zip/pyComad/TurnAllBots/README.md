# Telegram Bots Manager

## 📁 Файлы конфигурации:
- Конфиг: `/storage/emulated/0/Download/pyComad/TurnAllBots/bots_config.json`
- Логи: `/storage/emulated/0/Download/pyComad/TurnAllBots/bot_logs/`
- Скрипт: `/storage/emulated/0/Download/pyComad/TurnAllBots/bot_manager.py`

## 🚀 Использование:
```bash
python bot_manager.py
```
