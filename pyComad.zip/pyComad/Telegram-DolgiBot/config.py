import os
from typing import Final

# ТОКЕН БОТА
BOT_TOKEN: Final = "8136446489:AAHxMSCqHfczwxddYfyTGGIYovTWqdf2ZdI"

# Настройки безопасности
MAX_DEBT_AMOUNT = 1000000
MAX_DEBTS_PER_USER = 100

# Пути для хранения данных - прямо в папке с ботом
BOT_DIR = "/storage/emulated/0/Download/pyComad/Telegram-DolgiBot"
USERS_INFO_DIR = os.path.join(BOT_DIR, "user-info")
BACKUP_DIR = os.path.join(BOT_DIR, "backups")
LOG_FILE = os.path.join(BOT_DIR, "bot.log")

# Создаем необходимые директории
os.makedirs(USERS_INFO_DIR, exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)

print("✅ Конфигурация Debt Bot загружена")
print(f"📁 Данные будут храниться в: {USERS_INFO_DIR}")