from datetime import datetime

def format_debt_list(debts: list) -> str:
    if not debts:
        return "📋 У вас пока нет записанных долгов."
    
    active_debts = [d for d in debts if d.get("status") == "active"]
    if not active_debts:
        return "✅ Все долги погашены!"
    
    result = "📋 Ваши активные долги:\n\n"
    total = 0
    
    for debt in active_debts:
        notify_status = "🔔" if debt.get("notification_sent") else "🔕"
        result += f"{notify_status} ID: {debt['id']} - {debt['debtor_identifier']}: {debt['amount']} руб.\n"
        if debt.get('description'):
            result += f"   💬 {debt['description']}\n"
        result += f"   📅 {format_date(debt['created_at'])}\n\n"
        total += debt['amount']
    
    result += f"💰 Общая сумма: {total} руб."
    return result

def format_date(date_string: str) -> str:
    try:
        dt = datetime.fromisoformat(date_string)
        return dt.strftime("%d.%m.%Y %H:%M")
    except:
        return date_string

def validate_amount(amount_str: str) -> tuple:
    try:
        amount = float(amount_str.replace(',', '.'))
        return (True, amount) if amount > 0 else (False, 0)
    except:
        return (False, 0)

def parse_debtor_identifier(identifier: str) -> dict:
    """Парсит идентификатор должника"""
    identifier = identifier.strip()
    
    if identifier.startswith('@'):
        return {"type": "username", "value": identifier[1:], "original": identifier}
    
    if identifier.isdigit():
        return {"type": "user_id", "value": int(identifier), "original": identifier}
    
    return {"type": "name", "value": identifier, "original": identifier}