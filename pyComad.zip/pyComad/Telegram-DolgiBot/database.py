import json
import os
from datetime import datetime
from config import USERS_INFO_DIR
from security import SecurityManager

security = SecurityManager()

class DebtDatabase:
    def __init__(self):
        self.users_dir = USERS_INFO_DIR
    
    def get_user_file(self, special_id: str) -> str:
        return os.path.join(self.users_dir, f"{special_id}.json")
    
    def user_exists(self, special_id: str) -> bool:
        return os.path.exists(self.get_user_file(special_id))
    
    def create_user(self, telegram_user_id: int, username: str = "") -> dict:
        special_id = security.generate_user_id(telegram_user_id, username)
        user_file = self.get_user_file(special_id)
        
        user_data = {
            "telegram_user_id": telegram_user_id,
            "username": username,
            "special_id": special_id,
            "created_at": datetime.now().isoformat(),
            "first_seen": datetime.now().strftime("%d.%m.%Y %H:%M"),
            "debts": [],
            "total_owed": 0,
            "total_lent": 0,
            "user_info": {
                "telegram_id": telegram_user_id,
                "username": username,
                "registration_date": datetime.now().isoformat(),
                "file_name": f"{special_id}.json"
            }
        }
        
        try:
            with open(user_file, 'w', encoding='utf-8') as f:
                json.dump(user_data, f, ensure_ascii=False, indent=2)
            print(f"✅ Создан пользователь: {special_id}.json")
            return {"success": True, "special_id": special_id, "user_data": user_data}
        except Exception as e:
            print(f"❌ Ошибка создания пользователя: {e}")
            return {"success": False, "error": str(e)}
    
    def get_or_create_user(self, telegram_user_id: int, username: str = "") -> dict:
        if not os.path.exists(self.users_dir):
            os.makedirs(self.users_dir, exist_ok=True)
            
        for filename in os.listdir(self.users_dir):
            if filename.endswith('.json'):
                file_path = os.path.join(self.users_dir, filename)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        user_data = json.load(f)
                    if user_data.get('telegram_user_id') == telegram_user_id:
                        return {"success": True, "special_id": user_data.get('special_id'), "user_data": user_data, "is_new": False}
                except:
                    continue
        
        return self.create_user(telegram_user_id, username)
    
    def add_debt(self, special_id: str, debtor_identifier: str, amount: float, description: str = "") -> dict:
        user_file = self.get_user_file(special_id)
        
        try:
            with open(user_file, 'r', encoding='utf-8') as f:
                user_data = json.load(f)
            
            debt_id = len(user_data["debts"]) + 1
            debt = {
                "id": debt_id,
                "debtor_identifier": debtor_identifier,
                "amount": amount,
                "description": description,
                "created_at": datetime.now().isoformat(),
                "created_date": datetime.now().strftime("%d.%m.%Y %H:%M"),
                "status": "active",
                "debt_hash": f"debt_{debt_id}_{int(datetime.now().timestamp())}",
                "notification_sent": False
            }
            
            user_data["debts"].append(debt)
            user_data["total_lent"] += amount
            user_data["last_active"] = datetime.now().isoformat()
            
            with open(user_file, 'w', encoding='utf-8') as f:
                json.dump(user_data, f, ensure_ascii=False, indent=2)
            
            print(f"✅ Добавлен долг для {special_id}.json: {debtor_identifier} - {amount} руб.")
            return {"success": True, "debt": debt}
        except Exception as e:
            print(f"❌ Ошибка добавления долга: {e}")
            return {"success": False, "error": str(e)}
    
    def get_user_debts(self, special_id: str) -> list:
        user_file = self.get_user_file(special_id)
        
        try:
            with open(user_file, 'r', encoding='utf-8') as f:
                user_data = json.load(f)
            return user_data.get("debts", [])
        except:
            return []
    
    def get_user_info(self, special_id: str) -> dict:
        user_file = self.get_user_file(special_id)
        
        try:
            with open(user_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    
    def mark_notification_sent(self, special_id: str, debt_id: int) -> bool:
        user_file = self.get_user_file(special_id)
        
        try:
            with open(user_file, 'r', encoding='utf-8') as f:
                user_data = json.load(f)
            
            for debt in user_data["debts"]:
                if debt["id"] == debt_id:
                    debt["notification_sent"] = True
                    debt["notification_sent_at"] = datetime.now().isoformat()
                    
                    with open(user_file, 'w', encoding='utf-8') as f:
                        json.dump(user_data, f, ensure_ascii=False, indent=2)
                    return True
            return False
        except:
            return False