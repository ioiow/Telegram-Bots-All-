import logging
import json
import os
from datetime import datetime
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    Application, CommandHandler, MessageHandler, 
    ContextTypes, ConversationHandler, filters
)

from config import BOT_TOKEN
from database import DebtDatabase
from security import SecurityManager
from utils import format_debt_list, validate_amount, parse_debtor_identifier

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Состояния разговора
DEBTOR_IDENTIFIER, DEBT_AMOUNT, DEBT_DESCRIPTION = range(3)

# Инициализация
db = DebtDatabase()
security = SecurityManager()

# Клавиатуры
main_keyboard = ReplyKeyboardMarkup([
    ["📝 Добавить долг", "📋 Мои долги"],
    ["🆔 Мой ID", "🔔 Уведомить", "ℹ️ Помощь"]
], resize_keyboard=True)

async def send_debt_notification(application, debtor_info: dict, creditor_name: str, amount: float, description: str = "", creditor_username: str = ""):
    """Отправляет уведомление должнику"""
    try:
        message_text = f"""
🔔 **УВЕДОМЛЕНИЕ О ДОЛГЕ**

💳 Вам записан долг:
💰 Сумма: {amount} руб.
👤 Кредитор: {creditor_name} ({creditor_username})
📅 Дата: {datetime.now().strftime("%d.%m.%Y %H:%M")}
📝 Примечание: {description if description else "Не указано"}

💡 Это автоматическое уведомление о записи долга.
Рекомендуется уточнить детали у кредитора.

⚠️ **Внимание:** Это уведомление носит информационный характер.
Для подтверждения долга свяжитесь с кредитором напрямую.

📊 Для учета своих долгов используйте @DebtTrackerRobot
        """
        
        if debtor_info["type"] == "user_id":
            # Пытаемся отправить по user_id
            try:
                await application.bot.send_message(
                    chat_id=debtor_info["value"],
                    text=message_text
                )
                print(f"✅ Уведомление отправлено пользователю {debtor_info['value']}")
                return True
            except Exception as e:
                print(f"❌ Не удалось отправить уведомление по ID {debtor_info['value']}: {e}")
                return False
        else:
            print(f"ℹ️ Уведомление для {debtor_info['original']}: {amount} руб.")
            return False
            
    except Exception as e:
        print(f"❌ Общая ошибка отправки уведомления: {e}")
        return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    
    result = db.get_or_create_user(user_id, user.username or "")
    
    if result["success"]:
        special_id = result["special_id"]
        user_data = result["user_data"]
        
        welcome_text = f"""
👋 Привет, {user.first_name}!

💼 Я бот для учета долгов с системой уведомлений.

🔔 **Важно об уведомлениях:**
• Бот может отправлять уведомления только тем, кто УЖЕ начинал с ним диалог
• Для новых пользователей - попросите их написать боту @DebtTrackerRobot
• После этого уведомления будут приходить автоматически

📊 Ваша информация:
• 🆔 Ваш ID: `{special_id}`
• 📅 Зарегистрирован: {user_data.get('first_seen', 'сегодня')}

💻 **Доступные команды:**
/start - Запустить бота
/add - Добавить долг  
/list - Мои долги
/security - Безопасность
/help - Помощь

Или используйте кнопки ниже:
        """
        
        context.user_data['special_id'] = special_id
        context.user_data['user_name'] = user.first_name
        context.user_data['user_username'] = user.username or ""
        
        await update.message.reply_text(welcome_text, reply_markup=main_keyboard)
    else:
        await update.message.reply_text("❌ Ошибка создания пользователя. Попробуйте снова.")

async def add_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /add"""
    user_id = update.effective_user.id
    
    result = db.get_or_create_user(user_id)
    if not result["success"]:
        await update.message.reply_text("❌ Пользователь не найден.")
        return
    
    context.user_data['special_id'] = result["special_id"]
    context.user_data['user_name'] = update.effective_user.first_name
    context.user_data['user_username'] = update.effective_user.username or ""
    
    instruction_text = """
👤 **Введите данные должника:**

Вы можете указать:
• **@username** (например: @ivanov)
• **ID аккаунта** (только цифры)
• **Имя** (только для записи, без уведомления)

🔔 **Важно об уведомлениях:**
Бот может отправлять уведомления только тем, кто УЖЕ начинал с ним диалог.
Если должник еще не писал боту - попросите его написать @DebtTrackerRobot

📝 Примеры:
@ivanov - попытка уведомления (если писал боту)
123456789 - уведомление по ID (если писал боту)
Иван Иванов - только запись в базу

Введите username или ID должника:
    """
    
    await update.message.reply_text(instruction_text, reply_markup=ReplyKeyboardRemove())
    return DEBTOR_IDENTIFIER

async def list_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /list"""
    user_id = update.effective_user.id
    
    result = db.get_or_create_user(user_id)
    if not result["success"]:
        await update.message.reply_text("❌ Пользователь не найден.")
        return
    
    special_id = result["special_id"]
    debts = db.get_user_debts(special_id)
    message = format_debt_list(debts)
    
    await update.message.reply_text(message, reply_markup=main_keyboard)

async def security_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /security"""
    user_id = update.effective_user.id
    
    result = db.get_or_create_user(user_id)
    if not result["success"]:
        await update.message.reply_text("❌ Пользователь не найден.")
        return
    
    special_id = result["special_id"]
    user_info = db.get_user_info(special_id)
    
    security_text = f"""
🔒 **СИСТЕМА БЕЗОПАСНОСТИ**

{security.get_security_warning()}

📊 **Ваша статистика безопасности:**
• 🆔 Персональный ID: `{special_id}`
• 👤 Telegram ID: `{user_id}`
• 📅 Регистрация: {user_info.get('first_seen', 'Неизвестно')}
• 📊 Активных долгов: {len([d for d in user_info.get('debts', []) if d.get('status') == 'active'])}
• 📁 Файл данных: `{special_id}.json`

💾 **Локальное хранение:**
Все ваши данные хранятся локально в вашем телефоне.

⚠️ **Ограничения уведомлений:**
Бот может отправлять сообщения только тем пользователям,
которые уже начинали с ним диалог.
    """
    
    await update.message.reply_text(security_text, reply_markup=main_keyboard)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /help"""
    help_text = """
📖 **ПОМОЩЬ ПО БОТУ**

💻 **КОМАНДЫ:**
/start - Запустить бота и показать меню
/add - Добавить новый долг
/list - Показать все мои долги  
/security - Информация о безопасности
/help - Эта справка

🔔 **ВАЖНО ОБ УВЕДОМЛЕНИЯХ:**
• Бот может отправлять уведомления только ТЕМ, кто УЖЕ начинал с ним диалог
• Если должник еще не писал боту - попросите его написать @DebtTrackerRobot
• После этого уведомления будут работать автоматически

👤 **ФОРМАТ ДОЛЖНИКА:**
@username - уведомление (если пользователь писал боту)
123456789 - уведомление по ID (если пользователь писал боту)  
Имя Фамилия - только запись (без уведомления)

💾 **СИСТЕМА ХРАНЕНИЯ:**
• Каждый пользователь имеет уникальный ID
• Все данные сохраняются локально
• Формат файлов: UNIXTIMESTAMP_TELEGRAMID.json

💡 **Совет:** Попросите должников написать @DebtTrackerRobot чтобы получать уведомления!
    """
    await update.message.reply_text(help_text, reply_markup=main_keyboard)

async def show_my_debts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки 'Мои долги'"""
    await list_command(update, context)

async def show_my_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    result = db.get_or_create_user(user_id)
    if not result["success"]:
        await update.message.reply_text("❌ Пользователь не найден.")
        return
    
    special_id = result["special_id"]
    user_info = db.get_user_info(special_id)
    
    id_text = f"""
🆔 **ВАШ ПЕРСОНАЛЬНЫЙ ID**

📋 **ID для файла:** `{special_id}`
👤 **Telegram ID:** `{user_id}`
📁 **Файл данных:** `{special_id}.json`
📅 **Дата регистрации:** {user_info.get('first_seen', 'Неизвестно')}
📊 **Всего долгов:** {len(user_info.get('debts', []))}

💡 Этот ID уникален и привязан к вашему аккаунту Telegram.
    """
    
    await update.message.reply_text(id_text, reply_markup=main_keyboard)

async def add_debt_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик кнопки 'Добавить долг'"""
    await add_command(update, context)

async def debt_debtor_identifier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    debtor_input = update.message.text
    debtor_info = parse_debtor_identifier(debtor_input)
    
    context.user_data['debtor_info'] = debtor_info
    context.user_data['debtor_original'] = debtor_input
    
    await update.message.reply_text("💰 Введите сумму долга (только цифры):")
    return DEBTOR_IDENTIFIER

async def debt_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    amount_str = update.message.text
    is_valid, amount = validate_amount(amount_str)
    
    if not is_valid:
        await update.message.reply_text("❌ Неверная сумма! Введите число (например: 1500 или 500.50):")
        return DEBT_AMOUNT
    
    context.user_data['amount'] = amount
    await update.message.reply_text("💬 Введите описание долга (или 'пропустить'):")
    return DEBT_DESCRIPTION

async def debt_description(update: Update, context: ContextTypes.DEFAULT_TYPE):
    description = update.message.text
    if description.lower() == 'пропустить':
        description = ""
    
    special_id = context.user_data['special_id']
    debtor_info = context.user_data['debtor_info']
    amount = context.user_data['amount']
    creditor_name = context.user_data['user_name']
    creditor_username = context.user_data.get('user_username', '')
    
    # Добавляем долг в базу
    result = db.add_debt(special_id, debtor_info["original"], amount, description)
    
    if result["success"]:
        response_text = f"""
✅ Долг успешно добавлен!

👤 Должник: {debtor_info['original']}
💰 Сумма: {amount} руб.
💬 Описание: {description if description else 'нет'}
📁 Сохранено в: {special_id}.json
        """
        
        # Пытаемся отправить уведомление
        if debtor_info["type"] in ["username", "user_id"]:
            notification_sent = await send_debt_notification(
                context.application,
                debtor_info,
                creditor_name,
                amount,
                description,
                creditor_username
            )
            
            if notification_sent:
                response_text += "\n🔔 Уведомление отправлено должнику!"
                # Помечаем что уведомление отправлено
                db.mark_notification_sent(special_id, result["debt"]["id"])
            else:
                if debtor_info["type"] == "username":
                    response_text += f"\n⚠️ Уведомление не отправлено. Пользователь @{debtor_info['value']} должен начать диалог с ботом @DebtTrackerRobot"
                else:
                    response_text += f"\n⚠️ Уведомление не отправлено. Пользователь с ID {debtor_info['value']} должен начать диалог с ботом"
        else:
            response_text += f"\nℹ️ Уведомление не отправлено (указано имя)"
        
        await update.message.reply_text(response_text, reply_markup=main_keyboard)
    else:
        await update.message.reply_text(
            "❌ Ошибка при добавлении долга!",
            reply_markup=main_keyboard
        )
    
    return ConversationHandler.END

async def send_notification_manually(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ручная отправка уведомления по ID долга"""
    user_id = update.effective_user.id
    
    result = db.get_or_create_user(user_id)
    if not result["success"]:
        await update.message.reply_text("❌ Пользователь не найден.")
        return
    
    special_id = result["special_id"]
    debts = db.get_user_debts(special_id)
    active_debts = [d for d in debts if d.get("status") == "active"]
    
    if not active_debts:
        await update.message.reply_text("✅ У вас нет активных долгов!", reply_markup=main_keyboard)
        return
    
    # Показываем долги для уведомления
    debt_list = "📋 Выберите ID долга для отправки уведомления:\n\n"
    for debt in active_debts:
        notify_status = "🔔" if debt.get("notification_sent") else "🔕"
        debtor_info = parse_debtor_identifier(debt['debtor_identifier'])
        debt_list += f"{notify_status} ID: {debt['id']} - {debt['debtor_identifier']}: {debt['amount']} руб.\n"
    
    debt_list += "\nВведите ID долга:"
    await update.message.reply_text(debt_list, reply_markup=ReplyKeyboardRemove())
    
    context.user_data['awaiting_debt_id'] = True

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "❌ Операция отменена.",
        reply_markup=main_keyboard
    )
    return ConversationHandler.END

def main():
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Обработчик разговора для добавления долга
    conv_handler = ConversationHandler(
        entry_points=[
            MessageHandler(filters.Regex("^📝 Добавить долг$"), add_debt_start),
            CommandHandler("add", add_command)
        ],
        states={
            DEBTOR_IDENTIFIER: [MessageHandler(filters.TEXT & ~filters.COMMAND, debt_debtor_identifier)],
            DEBT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, debt_amount)],
            DEBT_DESCRIPTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, debt_description)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    
    # Добавляем обработчики команд
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("list", list_command))
    application.add_handler(CommandHandler("security", security_command))
    application.add_handler(CommandHandler("help", help_command))
    
    # Добавляем обработчик разговора
    application.add_handler(conv_handler)
    
    # Добавляем обработчики кнопок
    application.add_handler(MessageHandler(filters.Regex("^📋 Мои долги$"), show_my_debts))
    application.add_handler(MessageHandler(filters.Regex("^🆔 Мой ID$"), show_my_id))
    application.add_handler(MessageHandler(filters.Regex("^🔔 Уведомить$"), send_notification_manually))
    application.add_handler(MessageHandler(filters.Regex("^ℹ️ Помощь$"), help_command))
    
    print("🤖 Debt Bot запущен!")
    print("💻 Доступные команды: /start, /add, /list, /security, /help")
    print("🔔 Важно: Уведомления работают только для пользователей, которые начали диалог с ботом")
    print("⚠️  Для остановки нажмите Ctrl+C")
    application.run_polling()

if __name__ == "__main__":
    main()