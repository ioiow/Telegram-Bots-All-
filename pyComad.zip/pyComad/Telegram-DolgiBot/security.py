import hashlib
import time
import json
import os
from datetime import datetime
from config import USERS_INFO_DIR

class SecurityManager:
    def __init__(self):
        self.user_sessions = {}
        self.failed_attempts = {}
    
    def generate_user_id(self, telegram_user_id: int, username: str) -> str:
        """Генерирует специальный ID для файла"""
        timestamp = int(time.time())
        special_id = f"{timestamp}_{telegram_user_id}"
        return special_id
    
    def verify_user_access(self, user_id: int, username: str) -> dict:
        """Упрощенная проверка доступа"""
        special_id = self.generate_user_id(user_id, username)
        
        return {
            "allowed": True,
            "special_id": special_id,
            "message": "✅ Добро пожаловать!"
        }
    
    def get_security_warning(self) -> str:
        """Предупреждение о безопасности"""
        return """
🔒 **СИСТЕМА УЧЕТА ДОЛГОВ**

📝 Все записи сохраняются с вашим уникальным ID.
💾 Данные защищены и не могут быть удалены.
⚠️ Каждый долг фиксируется с датой и временем.
        """