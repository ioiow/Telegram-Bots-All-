import requests
import re
import time
import json
import sqlite3
from datetime import datetime
import threading
import os
import signal
import sys

# Флаг для контроля работы бота
running = True

BOT_TOKEN = "8007114766:AAHT0fHTjbUklubWFRRgiyR_9arjYPrw50I"

# Официальный канал (username без @)
OFFICIAL_CHANNEL = "downloadGPT_AI"

# Список каналов для подписки (username без @)
CHANNELS = [
    "Iruma_Standoff2",
    "Kino_vek", 
    "Freelancestar_bot",
    "IT_Programmer_io",
    "searchPersonIP",
    "PeopleQuestions_1_bot",
    "S2CheatX_Bot"
]

# Настройки лимитов
FREE_USES = 3
USES_BETWEEN_SUBSCRIPTIONS = 15

# Глобальные переменные для кэширования
user_cache = {}
cache_lock = threading.Lock()

# Файл для статистики
STATS_FILE = "/storage/emulated/0/Download/botGPTdownload/users_stats.json"

# Папка для истории пользователей
USERS_HISTORY_DIR = "/storage/emulated/0/Download/pyComad/Telegram-GptDowland/users_history"

def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения"""
    global running
    print("\n\n⚠️  Получен сигнал завершения...")
    print("🔄 Завершаю работу бота...")
    running = False
    # Даем время на завершение текущих операций
    time.sleep(0.5)
    print("✅ Бот успешно остановлен")
    sys.exit(0)

def ensure_directories():
    """Создает необходимые директории"""
    os.makedirs(USERS_HISTORY_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(STATS_FILE), exist_ok=True)

def save_user_info(user_id, message_data, action="message", additional_data=None):
    """Сохраняет информацию о пользователе в файл и историю"""
    try:
        # Читаем текущую статистику
        if os.path.exists(STATS_FILE):
            with open(STATS_FILE, 'r', encoding='utf-8') as f:
                stats = json.load(f)
        else:
            stats = {}
        
        # Добавляем/обновляем пользователя
        user_info = message_data.get("from", {})
        user_key = str(user_id)
        
        stats[user_key] = {
            "user_id": user_id,
            "username": user_info.get("username", "Нет username"),
            "first_name": user_info.get("first_name", "Нет имени"),
            "last_name": user_info.get("last_name", "Нет фамилии"),
            "phone_number": user_info.get("phone_number", "Нет номера"),
            "last_activity": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_actions": stats.get(user_key, {}).get("total_actions", 0) + 1
        }
        
        # Сохраняем обратно
        with open(STATS_FILE, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
        
        # Сохраняем детальную историю пользователя
        save_user_history(user_id, message_data, action, additional_data)
            
    except Exception as e:
        print(f"Ошибка сохранения статистики: {e}")

def save_user_history(user_id, message_data, action, additional_data=None):
    """Сохраняет детальную историю действий пользователя"""
    try:
        user_history_dir = os.path.join(USERS_HISTORY_DIR, str(user_id))
        os.makedirs(user_history_dir, exist_ok=True)
        
        # Основной файл информации о пользователе
        user_info_file = os.path.join(user_history_dir, "user_info.json")
        user_info = message_data.get("from", {})
        
        user_data = {
            "user_id": user_id,
            "username": user_info.get("username", "Нет username"),
            "first_name": user_info.get("first_name", "Нет имени"),
            "last_name": user_info.get("last_name", "Нет фамилии"),
            "language_code": user_info.get("language_code", "Не указан"),
            "is_premium": user_info.get("is_premium", False),
            "first_seen": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "last_seen": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_actions": 0
        }
        
        # Если файл уже существует, обновляем данные
        if os.path.exists(user_info_file):
            with open(user_info_file, 'r', encoding='utf-8') as f:
                existing_data = json.load(f)
                user_data["first_seen"] = existing_data.get("first_seen", user_data["first_seen"])
                user_data["total_actions"] = existing_data.get("total_actions", 0) + 1
        else:
            user_data["total_actions"] = 1
        
        with open(user_info_file, 'w', encoding='utf-8') as f:
            json.dump(user_data, f, ensure_ascii=False, indent=2)
        
        # Сохраняем историю действий
        history_file = os.path.join(user_history_dir, "actions_history.json")
        history_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "action": action,
            "message_text": message_data.get("text", ""),
            "chat_id": message_data.get("chat", {}).get("id"),
            "additional_data": additional_data or {}
        }
        
        history_list = []
        if os.path.exists(history_file):
            with open(history_file, 'r', encoding='utf-8') as f:
                history_list = json.load(f)
        
        history_list.append(history_entry)
        
        # Ограничиваем историю последними 1000 действиями
        if len(history_list) > 1000:
            history_list = history_list[-1000:]
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history_list, f, ensure_ascii=False, indent=2)
            
        # Также сохраняем в общий лог
        save_to_main_log(user_id, history_entry)
        
    except Exception as e:
        print(f"Ошибка сохранения истории: {e}")

def save_to_main_log(user_id, history_entry):
    """Сохраняет действие в общий лог всех пользователей"""
    try:
        main_log_file = os.path.join(USERS_HISTORY_DIR, "all_users_log.json")
        
        log_entry = {
            "user_id": user_id,
            **history_entry
        }
        
        log_list = []
        if os.path.exists(main_log_file):
            with open(main_log_file, 'r', encoding='utf-8') as f:
                log_list = json.load(f)
        
        log_list.append(log_entry)
        
        # Ограничиваем общий лог последними 5000 действиями
        if len(log_list) > 5000:
            log_list = log_list[-5000:]
        
        with open(main_log_file, 'w', encoding='utf-8') as f:
            json.dump(log_list, f, ensure_ascii=False, indent=2)
            
    except Exception as e:
        print(f"Ошибка сохранения в общий лог: {e}")

def check_official_channel_subscription(user_id):
    """Проверяет подписку на официальный канал"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember"
        data = {
            "chat_id": f"@{OFFICIAL_CHANNEL}",
            "user_id": user_id
        }
        response = requests.post(url, data=data, timeout=1)
        result = response.json()
        
        if result.get('ok'):
            status = result['result']['status']
            return status in ['member', 'administrator', 'creator']
        return False
    except:
        return False

def send_message_with_button(chat_id, text, button_text, button_url):
    """Отправляет сообщение с кнопкой"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "reply_markup": json.dumps({
            "inline_keyboard": [[
                {
                    "text": button_text,
                    "url": button_url
                }
            ]]
        })
    }
    try:
        requests.post(url, data=data, timeout=0.5)
    except:
        pass

def send_subscription_required_message(chat_id):
    """Отправляет сообщение о необходимости подписки"""
    send_message_with_button(
        chat_id,
        "📢 <b>ПОДПИШИСЬ НА НАШ КАНАЛ!</b>\n\n"
        "Чтобы использовать бота, нужно быть подписанным на наш официальный канал:\n"
        "• Новости и обновления 📢\n"
        "• Важные объявления 💬\n"
        "• Поддержка и помощь 🆘\n\n"
        "<i>После подписки отправь /start снова</i>",
        "🔔 ПОДПИСАТЬСЯ НА КАНАЛ",
        f"https://t.me/{OFFICIAL_CHANNEL}"
    )

def is_user_subscribed(user_id):
    """Проверяет подписку пользователя на все необходимые каналы"""
    if not check_official_channel_subscription(user_id):
        return False, "official"
    
    user_data = get_user_data(user_id)
    required_channels = get_required_channels(user_data)
    
    if required_channels:
        is_subscribed, missing_channels = check_all_subscriptions(user_id, required_channels)
        if not is_subscribed:
            return False, "other"
    
    return True, ""

def init_db():
    """Инициализация базы данных"""
    conn = sqlite3.connect('bot_users.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            usage_count INTEGER DEFAULT 0,
            subscribed_channels TEXT DEFAULT '[]',
            last_check TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def get_user_data(user_id):
    """Получает данные пользователя с кэшированием"""
    with cache_lock:
        if user_id in user_cache:
            return user_cache[user_id]
    
    conn = sqlite3.connect('bot_users.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        user_data = {
            'user_id': user[0],
            'usage_count': user[1],
            'subscribed_channels': json.loads(user[2]),
            'last_check': user[3]
        }
        with cache_lock:
            user_cache[user_id] = user_data
        return user_data
    else:
        new_user = {
            'user_id': user_id,
            'usage_count': 0,
            'subscribed_channels': [],
            'last_check': datetime.now().isoformat()
        }
        save_user_data(new_user)
        return new_user

def save_user_data(user_data):
    """Сохраняет данные пользователя с кэшированием"""
    with cache_lock:
        user_cache[user_data['user_id']] = user_data
    
    conn = sqlite3.connect('bot_users.db', check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, usage_count, subscribed_channels, last_check)
        VALUES (?, ?, ?, ?)
    ''', (
        user_data['user_id'],
        user_data['usage_count'],
        json.dumps(user_data['subscribed_channels']),
        user_data['last_check']
    ))
    conn.commit()
    conn.close()

def check_channel_subscription(user_id, channel_username):
    """Проверяет подписку пользователя на канал"""
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember"
        data = {
            "chat_id": f"@{channel_username}",
            "user_id": user_id
        }
        response = requests.post(url, data=data, timeout=1)
        result = response.json()
        
        if result.get('ok'):
            status = result['result']['status']
            return status in ['member', 'administrator', 'creator']
        return True
    except:
        return True

def get_required_channels(user_data):
    """Определяет какие каналы нужно подписаться"""
    used_count = user_data['usage_count']
    subscribed = user_data['subscribed_channels']
    
    if used_count < FREE_USES:
        return []
    
    if used_count < FREE_USES + USES_BETWEEN_SUBSCRIPTIONS:
        needed_channels = [ch for ch in CHANNELS[:2] if ch not in subscribed]
        return needed_channels
    
    stage = (used_count - FREE_USES) // USES_BETWEEN_SUBSCRIPTIONS
    start_idx = min(stage * 2, len(CHANNELS))
    end_idx = min(start_idx + 2, len(CHANNELS))
    
    needed_channels = [ch for ch in CHANNELS[start_idx:end_idx] if ch not in subscribed]
    return needed_channels

def check_all_subscriptions(user_id, required_channels):
    """Проверяет подписку на все требуемые каналы"""
    if not required_channels:
        return True, []
    
    not_subscribed = []
    for channel in required_channels:
        if not check_channel_subscription(user_id, channel):
            not_subscribed.append(channel)
    
    return len(not_subscribed) == 0, not_subscribed

def send_message_fast(chat_id, text):
    """Сверхбыстрая отправка сообщения"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": chat_id, "text": text}
    try:
        requests.post(url, data=data, timeout=0.3)
    except:
        pass

def send_video_fast(chat_id, video_url):
    """Сверхбыстрая отправка видео"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendVideo"
    data = {
        "chat_id": chat_id,
        "video": video_url,
        "caption": "🎥 Ваше видео готово!",
        "supports_streaming": True
    }
    try:
        requests.post(url, data=data, timeout=0.5)
    except:
        try:
            url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
            data = {
                "chat_id": chat_id,
                "document": video_url,
                "caption": "📹 Ваше видео готово!"
            }
            requests.post(url, data=data, timeout=0.5)
        except:
            pass

def send_channel_info(chat_id):
    """Отправляет информацию о канале с кнопкой"""
    send_message_with_button(
        chat_id,
        "📢 <b>НАШ ОФИЦИАЛЬНЫЙ КАНАЛ</b>\n\n"
        "Здесь вы найдете:\n"
        "• Последние новости и обновления 📰\n"
        "• Важные объявления и уведомления 🔔\n"  
        "• Полезные материалы и инструкции 📚\n"
        "• Поддержку и ответы на вопросы 🆘\n\n"
        "<i>Нажмите на кнопку ниже чтобы перейти в канал и посмотреть все посты</i>",
        "📱 ПЕРЕЙТИ В КАНАЛ",
        f"https://t.me/{OFFICIAL_CHANNEL}"
    )

def process_message(message):
    """Обрабатывает сообщение"""
    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]
    text = message.get("text", "").strip()
    
    # Сохраняем информацию о пользователе с указанием действия
    action = "unknown"
    additional_data = {}
    
    if text == "/start":
        action = "start_command"
        save_user_info(user_id, message, action, additional_data)
        
    elif text == "/info":
        action = "info_command"
        save_user_info(user_id, message, action, additional_data)
        
    elif re.match(r'https?://(www\.)?instagram\.com/', text):
        action = "instagram_link"
        additional_data = {"instagram_url": text, "processed_url": text.replace('instagram.com', 'kkinstagram.com')}
        save_user_info(user_id, message, action, additional_data)
        
    elif re.match(r'https?://', text):
        action = "other_link"
        additional_data = {"other_url": text}
        save_user_info(user_id, message, action, additional_data)
        
    else:
        action = "other_message"
        additional_data = {"message_text": text}
        save_user_info(user_id, message, action, additional_data)
    
    # Обработка команды /info
    if text == "/info":
        is_subscribed, subscription_type = is_user_subscribed(user_id)
        if not is_subscribed:
            if subscription_type == "official":
                send_subscription_required_message(chat_id)
            else:
                send_message_fast(chat_id, "❌ Для использования этой команды нужно быть подписанным на официальный канал!")
            return
        
        send_channel_info(chat_id)
        return
    
    # ПРОВЕРЯЕМ ПОДПИСКУ ПЕРЕД ЛЮБЫМ ДЕЙСТВИЕМ
    is_subscribed, subscription_type = is_user_subscribed(user_id)
    
    if not is_subscribed:
        if subscription_type == "official":
            send_subscription_required_message(chat_id)
            return
        else:
            user_data = get_user_data(user_id)
            required_channels = get_required_channels(user_data)
            is_subscribed, missing_channels = check_all_subscriptions(user_id, required_channels)
            
            if not is_subscribed:
                channels_text = "\n".join([f"https://t.me/{channel}" for channel in missing_channels])
                send_message_fast(chat_id, f"📢 Подпишитесь:\n{channels_text}")
                return
    
    # ЕСЛИ ПОДПИСАН - ОБРАБАТЫВАЕМ КОМАНДЫ
    if text == "/start":
        send_message_fast(chat_id, "👋 Отправьте ссылку Instagram\n\n📢 Также доступна команда /info - посмотреть посты канала")
        return
    
    # Проверяем Instagram ссылку
    if re.match(r'https?://(www\.)?instagram\.com/', text):
        user_data = get_user_data(user_id)
        required_channels = get_required_channels(user_data)
        
        is_subscribed, missing_channels = check_all_subscriptions(user_id, required_channels)
        
        if not is_subscribed:
            channels_text = "\n".join([f"https://t.me/{channel}" for channel in missing_channels])
            send_message_fast(chat_id, f"📢 Подпишитесь:\n{channels_text}")
            return
        
        # Мгновенная отправка видео
        modified_url = text.replace('instagram.com', 'kkinstagram.com')
        send_video_fast(chat_id, modified_url)
        
        # Обновляем счетчик
        user_data['usage_count'] += 1
        save_user_data(user_data)
    
    elif re.match(r'https?://', text):
        send_message_fast(chat_id, "🚧 Только Instagram. такие как тик-ток и другие сейчас недоступны мы исправляем эту ошибку прошу прощения)")
    else:
        send_message_fast(chat_id, "❌ Отправьте ссылку Instagram\n\n📢 Также доступна команда /info - посмотреть посты канала")

def main():
    """Основная функция бота"""
    global running
    
    # Регистрируем обработчики сигналов
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    ensure_directories()
    init_db()
    offset = 0
    
    print("=" * 50)
    print("🤖 Бот запущен...")
    print(f"📊 Файл статистики: {STATS_FILE}")
    print(f"📁 Папка истории: {USERS_HISTORY_DIR}")
    print(f"📢 Официальный канал: @{OFFICIAL_CHANNEL}")
    print("\nℹ️  Для остановки бота нажмите Ctrl+C")
    print("=" * 50)
    
    try:
        while running:
            try:
                url = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"
                params = {"offset": offset, "timeout": 1}
                response = requests.get(url, params=params, timeout=1)
                
                if response.status_code == 200:
                    data = response.json()
                    if data["ok"] and data["result"]:
                        for update in data["result"]:
                            if "message" in update:
                                process_message(update["message"])
                            offset = update["update_id"] + 1
                
                # Добавляем небольшую паузу для проверки флага running
                time.sleep(0.1)
                
            except requests.exceptions.Timeout:
                continue
            except requests.exceptions.RequestException as e:
                print(f"⚠️  Ошибка подключения: {e}")
                time.sleep(2)
                continue
            except Exception as e:
                print(f"⚠️  Неожиданная ошибка: {e}")
                time.sleep(1)
                continue
                
    except KeyboardInterrupt:
        print("\n\n⚠️  Получен сигнал KeyboardInterrupt...")
    
    finally:
        # Завершающие операции
        print("🔄 Завершаю работу бота...")
        
        # Сохраняем кэш пользователей (если нужно)
        with cache_lock:
            if user_cache:
                print(f"💾 Сохраняю кэш пользователей ({len(user_cache)} записей)...")
        
        # Закрываем соединения с БД
        try:
            # Если есть открытые соединения, их нужно закрыть
            pass
        except:
            pass
        
        print("✅ Бот успешно остановлен")
        print("\n👋 До свидания!")
        time.sleep(0.5)

if __name__ == "__main__":
    main()