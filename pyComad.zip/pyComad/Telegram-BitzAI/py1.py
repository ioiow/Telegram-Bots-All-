"""
╔══════════════════════════════════════════════════════════════════╗
║                      BitzAI TELEGRAM BOT v2.0                    ║
║                                                                  ║
║  Функции:                                                        ║
║  ✓ Приветствие со скрытой ссылкой под словом "web"              ║
║  ✓ Клавиатура: Сайт, Поддержка                                  ║
║  ✓ Пересылка сообщений админу + ответы                          ║
║  ✓ Продвинутая система рекламы /add                             ║
║  ✓ Обязательная подписка на каналы                              ║
║  ✓ Рассылка всем пользователям                                  ║
║  ✓ Статистика бота                                              ║
╚══════════════════════════════════════════════════════════════════╝
"""

import asyncio
import json
import os
import re
from datetime import datetime
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton,
    ChatMemberUpdated
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.enums import ParseMode

# ╔══════════════════════════════════════════════════════════════════╗
# ║                      НАСТРОЙКИ БОТА                              ║
# ║              ⚠️ ИЗМЕНИТЕ ЭТИ ЗНАЧЕНИЯ НА СВОИ! ⚠️                ║
# ╚══════════════════════════════════════════════════════════════════╝

BOT_TOKEN = "8418594153:AAGHK9Hcd2dpcK1AAnLIXAAkq3IiKVPVBZ8"           # Токен от @BotFather
ADMIN_ID = 7633663691                        # Ваш Telegram ID
WEBSITE_URL = "https://t.me/BitzAI_bot/website"  # Ссылка на сайт

# Файлы данных
DATA_FILE = "bot_data.json"

# ══════════════════════════════════════════════════════════════════

bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

# ══════════════════════════════════════════════════════════════════
#                         СОСТОЯНИЯ FSM
# ══════════════════════════════════════════════════════════════════

class UserStates(StatesGroup):
    waiting_for_message = State()

class AdminStates(StatesGroup):
    waiting_for_reply = State()
    # Состояния для добавления канала
    waiting_for_channel = State()
    # Состояния для рекламы
    waiting_for_ad_content = State()
    waiting_for_ad_buttons = State()
    # Состояния для рассылки
    waiting_for_broadcast = State()
    waiting_for_broadcast_buttons = State()

# ══════════════════════════════════════════════════════════════════
#                      РАБОТА С ДАННЫМИ
# ══════════════════════════════════════════════════════════════════

def load_data():
    """Загрузка всех данных"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "users": [],
        "channels": [],
        "ads": [],
        "stats": {"total_messages": 0, "start_count": 0}
    }

def save_data(data):
    """Сохранение данных"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_user(user_id: int):
    """Добавление пользователя в базу"""
    data = load_data()
    if user_id not in data["users"]:
        data["users"].append(user_id)
        save_data(data)

def get_channels():
    """Получение списка каналов"""
    data = load_data()
    return data.get("channels", [])

def add_channel(channel_id: int, username: str, title: str):
    """Добавление канала"""
    data = load_data()
    # Проверяем, нет ли уже такого канала
    for ch in data["channels"]:
        if ch["id"] == channel_id:
            return False
    data["channels"].append({
        "id": channel_id,
        "username": username,
        "title": title,
        "added": datetime.now().strftime("%Y-%m-%d %H:%M")
    })
    save_data(data)
    return True

def remove_channel(index: int):
    """Удаление канала по индексу"""
    data = load_data()
    if 0 <= index < len(data["channels"]):
        removed = data["channels"].pop(index)
        save_data(data)
        return removed
    return None

async def check_subscription(user_id: int) -> tuple:
    """Проверка подписки на все каналы"""
    channels = get_channels()
    not_subscribed = []
    
    for channel in channels:
        try:
            member = await bot.get_chat_member(
                chat_id=channel["id"], 
                user_id=user_id
            )
            if member.status in ["left", "kicked"]:
                not_subscribed.append(channel)
        except Exception as e:
            print(f"Ошибка проверки канала {channel['id']}: {e}")
            # Если не можем проверить - пропускаем
            pass
    
    return len(not_subscribed) == 0, not_subscribed

# ══════════════════════════════════════════════════════════════════
#                         КЛАВИАТУРЫ
# ══════════════════════════════════════════════════════════════════

def get_main_keyboard():
    """Главная клавиатура"""
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="🌐 Сайт"),
                KeyboardButton(text="💬 Поддержка")
            ]
        ],
        resize_keyboard=True
    )

def get_subscribe_keyboard(channels: list):
    """Клавиатура подписки на каналы"""
    buttons = []
    for channel in channels:
        url = f"https://t.me/{channel['username']}" if channel['username'] else f"https://t.me/c/{str(channel['id'])[4:]}"
        buttons.append([InlineKeyboardButton(
            text=f"📢 {channel['title']}", 
            url=url
        )])
    buttons.append([InlineKeyboardButton(
        text="✅ Проверить подписку", 
        callback_data="check_sub"
    )])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_admin_panel_keyboard():
    """Клавиатура админ-панели"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📢 Каналы", callback_data="admin_channels"),
            InlineKeyboardButton(text="📝 Реклама", callback_data="admin_ads")
        ],
        [
            InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats"),
            InlineKeyboardButton(text="📨 Рассылка", callback_data="admin_broadcast")
        ],
        [
            InlineKeyboardButton(text="❌ Закрыть", callback_data="admin_close")
        ]
    ])

def get_channels_keyboard():
    """Клавиатура управления каналами"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить канал", callback_data="ch_add")],
        [InlineKeyboardButton(text="📋 Список каналов", callback_data="ch_list")],
        [InlineKeyboardButton(text="🗑 Удалить канал", callback_data="ch_delete")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back")]
    ])

def get_ads_keyboard():
    """Клавиатура управления рекламой"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Создать пост", callback_data="ad_create")],
        [InlineKeyboardButton(text="📋 Мои посты", callback_data="ad_list")],
        [InlineKeyboardButton(text="🗑 Удалить все", callback_data="ad_clear")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back")]
    ])

def get_reply_keyboard(user_id: int):
    """Клавиатура ответа пользователю"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📝 Ответить", callback_data=f"reply_{user_id}")]
    ])

# ══════════════════════════════════════════════════════════════════
#                        КОМАНДА /start
# ══════════════════════════════════════════════════════════════════

@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    """Обработка /start"""
    user_id = message.from_user.id
    add_user(user_id)
    
    # Обновляем статистику
    data = load_data()
    data["stats"]["start_count"] = data["stats"].get("start_count", 0) + 1
    save_data(data)
    
    # Проверка подписки
    is_subscribed, not_subscribed = await check_subscription(user_id)
    
    if not is_subscribed:
        await message.answer(
            "⚠️ Для использования бота подпишитесь на каналы:",
            reply_markup=get_subscribe_keyboard(not_subscribed),
            parse_mode=ParseMode.HTML
        )
        return
    
    # Приветственное сообщение со СКРЫТОЙ ссылкой под словом "web"
    welcome_text = (
        f'👋 Здравствуйте!\n\n'
        f'Это BitzAI - чтобы узнать нас и наши услуги '
        f'воспользуйтесь сайтом - web\n\n'
        f'💡 Используйте кнопки ниже для навигации.'
    )
    
    await message.answer(
        welcome_text,
        reply_markup=get_main_keyboard(),
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

# ══════════════════════════════════════════════════════════════════
#                     ПРОВЕРКА ПОДПИСКИ
# ══════════════════════════════════════════════════════════════════

@dp.callback_query(F.data == "check_sub")
async def check_sub_callback(callback: types.CallbackQuery):
    """Проверка подписки по кнопке"""
    user_id = callback.from_user.id
    is_subscribed, not_subscribed = await check_subscription(user_id)
    
    if is_subscribed:
        await callback.message.delete()
        
        welcome_text = (
            f'✅ Спасибо за подписку!\n\n'
            f'👋 Здравствуйте!\n\n'
            f'Это BitzAI - чтобы узнать нас и наши услуги '
           f"🌐 - <a href='{WEBSITE_URL}'>Web</a>\n\n"
            f'💡 Используйте кнопки ниже для навигации.'
        )
        
        await callback.message.answer(
            welcome_text,
            reply_markup=get_main_keyboard(),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
    else:
        await callback.answer(
            "❌ Вы не подписались на все каналы!", 
            show_alert=True
        )
        # Обновляем список каналов
        await callback.message.edit_reply_markup(
            reply_markup=get_subscribe_keyboard(not_subscribed)
        )

# ══════════════════════════════════════════════════════════════════
#                       КНОПКИ МЕНЮ
# ══════════════════════════════════════════════════════════════════

@dp.message(F.text == "🌐 Сайт")
async def btn_website(message: types.Message):
    """Кнопка Сайт"""
    # Проверка подписки
    is_subscribed, not_subscribed = await check_subscription(message.from_user.id)
    if not is_subscribed:
        await message.answer(
            "⚠️ Сначала подпишитесь на каналы:",
            reply_markup=get_subscribe_keyboard(not_subscribed),
            parse_mode=ParseMode.HTML
        )
        return
    
    await message.answer(
        f'🌐 Наш сайт:\n\n'
        f'🔗 Открыть сайт',
        parse_mode=ParseMode.HTML,
        disable_web_page_preview=True
    )

@dp.message(F.text == "💬 Поддержка")
async def btn_support(message: types.Message, state: FSMContext):
    """Кнопка Поддержка"""
    # Проверка подписки
    is_subscribed, not_subscribed = await check_subscription(message.from_user.id)
    if not is_subscribed:
        await message.answer(
            "⚠️ Сначала подпишитесь на каналы:",
            reply_markup=get_subscribe_keyboard(not_subscribed),
            parse_mode=ParseMode.HTML
        )
        return
    
    await message.answer(
        "💬 Напишите ваше сообщение\n\n"
        "Опишите вашу проблему или вопрос, и мы ответим вам в ближайшее время!\n\n"
        "📎 Вы можете отправить текст, фото или документ.",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(UserStates.waiting_for_message)

# ══════════════════════════════════════════════════════════════════
#                    КОМАНДА /add (АДМИН-ПАНЕЛЬ)
# ══════════════════════════════════════════════════════════════════

@dp.message(Command("add"))
async def cmd_admin(message: types.Message):
    """Админ-панель"""
    if message.from_user.id != ADMIN_ID:
        return
    
    data = load_data()
    users_count = len(data.get("users", []))
    channels_count = len(data.get("channels", []))
    
    await message.answer(
        f"⚙️ Админ-панель BitzAI Bot\n\n"
        f"👥 Пользователей: {users_count}\n"
        f"📢 Каналов для подписки: {channels_count}\n\n"
        f"Выберите действие:",
        reply_markup=get_admin_panel_keyboard(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "admin_back")
async def admin_back(callback: types.CallbackQuery):
    """Возврат в главное меню админки"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    data = load_data()
    users_count = len(data.get("users", []))
    channels_count = len(data.get("channels", []))
    
    await callback.message.edit_text(
        f"⚙️ Админ-панель BitzAI Bot\n\n"
        f"👥 Пользователей: {users_count}\n"
        f"📢 Каналов для подписки: {channels_count}\n\n"
        f"Выберите действие:",
        reply_markup=get_admin_panel_keyboard(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "admin_close")
async def admin_close(callback: types.CallbackQuery):
    """Закрыть админку"""
    if callback.from_user.id != ADMIN_ID:
        return
    await callback.message.delete()

# ══════════════════════════════════════════════════════════════════
#                     УПРАВЛЕНИЕ КАНАЛАМИ
# ══════════════════════════════════════════════════════════════════

@dp.callback_query(F.data == "admin_channels")
async def admin_channels(callback: types.CallbackQuery):
    """Меню управления каналами"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await callback.message.edit_text(
        "📢 Управление каналами\n\n"
        "Здесь вы можете добавить каналы, на которые пользователи "
        "должны подписаться для использования бота.\n\n"
        "⚠️ Важно: Бот должен быть админом канала!",
        reply_markup=get_channels_keyboard(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "ch_add")
async def ch_add(callback: types.CallbackQuery, state: FSMContext):
    """Добавление канала"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await callback.message.edit_text(
        "📢 Добавление канала\n\n"
        "Отправьте одним из способов:\n\n"
        "1️⃣ Ссылку на канал:\n"
        "https://t.me/channel_name\n"
        "t.me/channel_name\n"
        "@channel_name\n\n"
        "2️⃣ Перешлите любое сообщение из канала\n\n"
        "⚠️ Бот должен быть админом этого канала!",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(AdminStates.waiting_for_channel)

@dp.message(AdminStates.waiting_for_channel)
async def process_channel(message: types.Message, state: FSMContext):
    """Обработка добавления канала"""
    if message.from_user.id != ADMIN_ID:
        return
    
    channel_id = None
    channel_username = None
    channel_title = None
    
    # Способ 1: Пересланное сообщение
    if message.forward_from_chat:
        chat = message.forward_from_chat
        if chat.type in ["channel", "supergroup"]:
            channel_id = chat.id
            channel_username = chat.username
            channel_title = chat.title
    
    # Способ 2: Ссылка или @username
    elif message.text:
        text = message.text.strip()
        
        # Извлекаем username из разных форматов
        patterns = [
            r'(?:https?://)?t\.me/([a-zA-Z][a-zA-Z0-9_]{3,})',
            r'@([a-zA-Z][a-zA-Z0-9_]{3,})',
        ]
        
        username = None
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                username = match.group(1)
                break
        
        if username:
            try:
                # Получаем информацию о канале
                chat = await bot.get_chat(f"@{username}")
                channel_id = chat.id
                channel_username = chat.username
                channel_title = chat.title
            except Exception as e:
                await message.answer(
                    f"❌ Ошибка!\n\n"
                    f"Не удалось найти канал @{username}\n"
                    f"Убедитесь, что бот является админом канала.\n\n"
                    f"Ошибка: {e}",
                    parse_mode=ParseMode.HTML
                )
                await state.clear()
                return
    
    if channel_id:
        # Проверяем, что бот админ
        try:
            bot_member = await bot.get_chat_member(channel_id, bot.id)
            if bot_member.status not in ["administrator", "creator"]:
                await message.answer(
                    "❌ Бот не является админом этого канала!\n\n"
                    "Добавьте бота в админы канала и попробуйте снова.",
                    parse_mode=ParseMode.HTML
                )
                await state.clear()
                return
        except:
            pass
        
        # Добавляем канал
        if add_channel(channel_id, channel_username, channel_title):
            await message.answer(
                f"✅ Канал добавлен!\n\n"
                f"📢 {channel_title}\n"
                f"🆔 ID: {channel_id}\n"
                f"🔗 @{channel_username if channel_username else 'приватный'}",
                reply_markup=get_channels_keyboard(),
                parse_mode=ParseMode.HTML
            )
        else:
            await message.answer(
                "⚠️ Этот канал уже добавлен!",
                reply_markup=get_channels_keyboard(),
                parse_mode=ParseMode.HTML
            )
    else:
        await message.answer(
            "❌ Не удалось определить канал.\n"
            "Отправьте ссылку или перешлите сообщение из канала.",
            parse_mode=ParseMode.HTML
        )
    
    await state.clear()

@dp.callback_query(F.data == "ch_list")
async def ch_list(callback: types.CallbackQuery):
    """Список каналов"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    channels = get_channels()
    
    if not channels:
        text = "📋 Список каналов пуст\n\nДобавьте каналы через кнопку ➕"
    else:
        text = "📋 Каналы для подписки:\n\n"
        for i, ch in enumerate(channels, 1):
            username = f"@{ch['username']}" if ch['username'] else "приватный"
            text += f"{i}. {ch['title']}\n"
            text += f"   └ {username}\n"
            text += f"   └ ID: {ch['id']}\n\n"
    
    await callback.message.edit_text(
        text,
        reply_markup=get_channels_keyboard(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "ch_delete")
async def ch_delete_menu(callback: types.CallbackQuery):
    """Меню удаления каналов"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    channels = get_channels()
    
    if not channels:
        await callback.answer("Нет каналов для удаления!", show_alert=True)
        return
    
    buttons = []
    for i, ch in enumerate(channels):
        buttons.append([InlineKeyboardButton(
            text=f"🗑 {ch['title']}", 
            callback_data=f"ch_del_{i}"
        )])
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="admin_channels")])
    
    await callback.message.edit_text(
        "🗑 Выберите канал для удаления:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("ch_del_"))
async def ch_delete(callback: types.CallbackQuery):
    """Удаление канала"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    index = int(callback.data.split("_")[2])
    removed = remove_channel(index)
    
    if removed:
        await callback.answer(f"✅ Канал {removed['title']} удален!", show_alert=True)
    
    # Возвращаемся к списку
    await admin_channels(callback)

# ══════════════════════════════════════════════════════════════════
#                      УПРАВЛЕНИЕ РЕКЛАМОЙ
# ══════════════════════════════════════════════════════════════════

@dp.callback_query(F.data == "admin_ads")
async def admin_ads(callback: types.CallbackQuery):
    """Меню управления рекламой"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await callback.message.edit_text(
        "📝 Управление рекламой\n\n"
        "Создавайте рекламные посты с текстом, фото, видео и кнопками.",
        reply_markup=get_ads_keyboard(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "ad_create")
async def ad_create(callback: types.CallbackQuery, state: FSMContext):
    """Создание рекламного поста"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await callback.message.edit_text(
        "📝 Создание рекламного поста\n\n"
        "Отправьте контент для поста:\n\n"
        "• 📄 Текст\n"
        "• 🖼 Фото (можно с подписью)\n"
        "• 🎬 Видео (можно с подписью)\n"
        "• 📁 Документ\n\n"
        "Поддерживается HTML-разметка:\n"
        "<b>жирный</b>\n"
        "<i>курсив</i>\n"
        "<a href=\"url\">ссылка</a>",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(AdminStates.waiting_for_ad_content)

@dp.message(AdminStates.waiting_for_ad_content)
async def process_ad_content(message: types.Message, state: FSMContext):
    """Обработка контента рекламы"""
    if message.from_user.id != ADMIN_ID:
        return
    
    ad_data = {"type": "text", "content": None, "file_id": None, "caption": None}
    
    if message.photo:
        ad_data["type"] = "photo"
        ad_data["file_id"] = message.photo[-1].file_id
        ad_data["caption"] = message.caption or ""
    elif message.video:
        ad_data["type"] = "video"
        ad_data["file_id"] = message.video.file_id
        ad_data["caption"] = message.caption or ""
    elif message.document:
        ad_data["type"] = "document"
        ad_data["file_id"] = message.document.file_id
        ad_data["caption"] = message.caption or ""
    elif message.text:
        ad_data["type"] = "text"
        ad_data["content"] = message.text
    else:
        await message.answer("❌ Неподдерживаемый тип контента!")
        return
    
    await state.update_data(ad_data=ad_data)
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить кнопки", callback_data="ad_add_buttons")],
        [InlineKeyboardButton(text="✅ Сохранить без кнопок", callback_data="ad_save_no_buttons")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_ads")]
    ])
    
    await message.answer(
        "✅ Контент получен!\n\n"
        "Хотите добавить кнопки со ссылками?",
        reply_markup=keyboard,
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "ad_add_buttons")
async def ad_add_buttons(callback: types.CallbackQuery, state: FSMContext):
    """Добавление кнопок к рекламе"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await callback.message.edit_text(
        "🔘 Добавление кнопок\n\n"
        "Отправьте кнопки в формате:\n"
        "Текст кнопки 1 | ссылка1\n"
        "Текст кнопки 2 | ссылка2\n\n"
        "Каждая кнопка на новой строке.\n\n"
        "Пример:\n"
        "📢 Подписаться | https://t.me/channel\n"
        "🌐 Сайт | https://example.com",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(AdminStates.waiting_for_ad_buttons)

@dp.message(AdminStates.waiting_for_ad_buttons)
async def process_ad_buttons(message: types.Message, state: FSMContext):
    """Обработка кнопок рекламы"""
    if message.from_user.id != ADMIN_ID:
        return
    
    buttons = []
    lines = message.text.strip().split("\n")
    
    for line in lines:
        if "|" in line:
            parts = line.split("|", 1)
            text = parts[0].strip()
            url = parts[1].strip()
            buttons.append({"text": text, "url": url})
    
    if not buttons:
        await message.answer("❌ Неверный формат! Попробуйте ещё раз.")
        return
    
    data = await state.get_data()
    ad_data = data.get("ad_data", {})
    ad_data["buttons"] = buttons
    
    # Сохраняем
    all_data = load_data()
    all_data["ads"].append(ad_data)
    save_data(all_data)
    
    await message.answer(
        f"✅ Рекламный пост сохранен!\n\n"
        f"Добавлено кнопок: {len(buttons)}",
        reply_markup=get_ads_keyboard(),
        parse_mode=ParseMode.HTML
    )
    await state.clear()

@dp.callback_query(F.data == "ad_save_no_buttons")
async def ad_save_no_buttons(callback: types.CallbackQuery, state: FSMContext):
    """Сохранение рекламы без кнопок"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    data = await state.get_data()
    ad_data = data.get("ad_data", {})
    ad_data["buttons"] = []
    
    all_data = load_data()
    all_data["ads"].append(ad_data)
    save_data(all_data)
    
    await callback.message.edit_text(
        "✅ Рекламный пост сохранен!",
        reply_markup=get_ads_keyboard(),
        parse_mode=ParseMode.HTML
    )
    await state.clear()

@dp.callback_query(F.data == "ad_list")
async def ad_list(callback: types.CallbackQuery):
    """Список рекламных постов"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    data = load_data()
    ads = data.get("ads", [])
    
    if not ads:
        await callback.answer("Нет сохраненных постов!", show_alert=True)
        return
    
    text = f"📋 Рекламные посты ({len(ads)}):\n\n"
    for i, ad in enumerate(ads, 1):
        ad_type = {"text": "📄", "photo": "🖼", "video": "🎬", "document": "📁"}.get(ad["type"], "📄")
        buttons_count = len(ad.get("buttons", []))
        preview = (ad.get("content") or ad.get("caption") or "")[:30]
        text += f"{i}. {ad_type} {preview}... ({buttons_count} кнопок)\n"
    
    buttons = []
    for i in range(len(ads)):
        buttons.append([
            InlineKeyboardButton(text=f"👁 Пост {i+1}", callback_data=f"ad_view_{i}"),
            InlineKeyboardButton(text="🗑", callback_data=f"ad_del_{i}")
        ])
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="admin_ads")])
    
    await callback.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("ad_view_"))
async def ad_view(callback: types.CallbackQuery):
    """Просмотр рекламного поста"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    index = int(callback.data.split("_")[2])
    data = load_data()
    ads = data.get("ads", [])
    
    if index >= len(ads):
        await callback.answer("Пост не найден!", show_alert=True)
        return
    
    ad = ads[index]
    
    # Создаем кнопки
    buttons = []
    for btn in ad.get("buttons", []):
        buttons.append([InlineKeyboardButton(text=btn["text"], url=btn["url"])])
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons) if buttons else None
    
    # Отправляем превью
    try:
        if ad["type"] == "photo":
            await bot.send_photo(
                callback.from_user.id,
                photo=ad["file_id"],
                caption=ad.get("caption"),
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML
            )
        elif ad["type"] == "video":
            await bot.send_video(
                callback.from_user.id,
                video=ad["file_id"],
                caption=ad.get("caption"),
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML
            )
        elif ad["type"] == "document":
            await bot.send_document(
                callback.from_user.id,
                document=ad["file_id"],
                caption=ad.get("caption"),
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML
            )
        else:
            await bot.send_message(
                callback.from_user.id,
                text=ad["content"],
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=False
            )
        await callback.answer("👆 Пост отправлен выше")
    except Exception as e:
        await callback.answer(f"Ошибка: {e}", show_alert=True)

@dp.callback_query(F.data.startswith("ad_del_"))
async def ad_delete(callback: types.CallbackQuery):
    """Удаление рекламного поста"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    index = int(callback.data.split("_")[2])
    data = load_data()
    
    if index < len(data["ads"]):
        data["ads"].pop(index)
        save_data(data)
        await callback.answer("✅ Пост удален!", show_alert=True)
    
    await ad_list(callback)

@dp.callback_query(F.data == "ad_clear")
async def ad_clear(callback: types.CallbackQuery):
    """Очистка всех постов"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    data = load_data()
    data["ads"] = []
    save_data(data)
    
    await callback.answer("✅ Все посты удалены!", show_alert=True)
    await admin_ads(callback)

# ══════════════════════════════════════════════════════════════════
#                         СТАТИСТИКА
# ══════════════════════════════════════════════════════════════════

@dp.callback_query(F.data == "admin_stats")
async def admin_stats(callback: types.CallbackQuery):
    """Статистика бота"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    data = load_data()
    
    text = (
        "📊 Статистика бота\n\n"
        f"👥 Всего пользователей: {len(data.get('users', []))}\n"
        f"📢 Каналов для подписки: {len(data.get('channels', []))}\n"
        f"📝 Рекламных постов: {len(data.get('ads', []))}\n"
        f"▶️ Нажатий /start: {data.get('stats', {}).get('start_count', 0)}"
    )
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back")]
    ])
    
    await callback.message.edit_text(
        text,
        reply_markup=keyboard,
        parse_mode=ParseMode.HTML
    )

# ══════════════════════════════════════════════════════════════════
#                          РАССЫЛКА
# ══════════════════════════════════════════════════════════════════

@dp.callback_query(F.data == "admin_broadcast")
async def admin_broadcast(callback: types.CallbackQuery, state: FSMContext):
    """Рассылка сообщений"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    data = load_data()
    users_count = len(data.get("users", []))
    
    await callback.message.edit_text(
        f"📨 Рассылка сообщений\n\n"
        f"Получателей: {users_count} пользователей\n\n"
        f"Отправьте сообщение для рассылки\n"
        f"(текст, фото, видео):",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(AdminStates.waiting_for_broadcast)

@dp.message(AdminStates.waiting_for_broadcast)
async def process_broadcast(message: types.Message, state: FSMContext):
    """Обработка рассылки"""
    if message.from_user.id != ADMIN_ID:
        return
    
    await state.update_data(broadcast_message=message)
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить кнопки", callback_data="bc_buttons")],
        [InlineKeyboardButton(text="📤 Отправить без кнопок", callback_data="bc_send")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="admin_back")]
    ])
    
    await message.answer(
        "✅ Сообщение получено!\n\n"
        "Добавить кнопки или отправить?",
        reply_markup=keyboard,
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "bc_buttons")
async def bc_buttons(callback: types.CallbackQuery, state: FSMContext):
    """Добавление кнопок к рассылке"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await callback.message.edit_text(
        "🔘 Добавление кнопок\n\n"
        "Формат:\n"
        "Текст | ссылка\n\n"
        "Каждая кнопка на новой строке.",
        parse_mode=ParseMode.HTML
    )
    await state.set_state(AdminStates.waiting_for_broadcast_buttons)

@dp.message(AdminStates.waiting_for_broadcast_buttons)
async def process_bc_buttons(message: types.Message, state: FSMContext):
    """Обработка кнопок рассылки"""
    if message.from_user.id != ADMIN_ID:
        return
    
    buttons = []
    lines = message.text.strip().split("\n")
    
    for line in lines:
        if "|" in line:
            parts = line.split("|", 1)
            buttons.append([InlineKeyboardButton(
                text=parts[0].strip(),
                url=parts[1].strip()
            )])
    
    await state.update_data(bc_buttons=buttons)
    
    # Отправляем рассылку
    await send_broadcast(message, state)

@dp.callback_query(F.data == "bc_send")
async def bc_send(callback: types.CallbackQuery, state: FSMContext):
    """Отправка рассылки"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    await state.update_data(bc_buttons=[])
    await send_broadcast(callback.message, state)

async def send_broadcast(message: types.Message, state: FSMContext):
    """Отправка рассылки всем пользователям"""
    data = await state.get_data()
    bc_message = data.get("broadcast_message")
    buttons = data.get("bc_buttons", [])
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons) if buttons else None
    
    all_data = load_data()
    users = all_data.get("users", [])
    
    success = 0
    failed = 0
    
    status_msg = await message.answer(f"📤 Рассылка... 0/{len(users)}")
    
    for i, user_id in enumerate(users):
        try:
            if bc_message.photo:
                await bot.send_photo(
                    user_id,
                    photo=bc_message.photo[-1].file_id,
                    caption=bc_message.caption,
                    reply_markup=keyboard,
                    parse_mode=ParseMode.HTML
                )
            elif bc_message.video:
                await bot.send_video(
                    user_id,
                    video=bc_message.video.file_id,
                    caption=bc_message.caption,
                    reply_markup=keyboard,
                    parse_mode=ParseMode.HTML
                )
            elif bc_message.text:
                await bot.send_message(
                    user_id,
                    text=bc_message.text,
                    reply_markup=keyboard,
                    parse_mode=ParseMode.HTML
                )
            success += 1
        except:
            failed += 1
        
        if (i + 1) % 10 == 0:
            await status_msg.edit_text(f"📤 Рассылка... {i+1}/{len(users)}")
        
        await asyncio.sleep(0.05)  # Антифлуд
    
    await status_msg.edit_text(
        f"✅ Рассылка завершена!\n\n"
        f"✓ Успешно: {success}\n"
        f"✗ Ошибок: {failed}",
        parse_mode=ParseMode.HTML
    )
    await state.clear()

# ══════════════════════════════════════════════════════════════════
#                    ПЕРЕСЫЛКА СООБЩЕНИЙ
# ══════════════════════════════════════════════════════════════════

@dp.message(UserStates.waiting_for_message)
async def forward_to_admin(message: types.Message, state: FSMContext):
    """Пересылка сообщения админу"""
    user = message.from_user
    
    user_info = (
        f"📨 Новое сообщение!\n\n"
        f"👤 {user.full_name}\n"
        f"🆔 ID: {user.id}\n"
        f"📝 Username: @{user.username if user.username else 'нет'}\n\n"
    )
    
    # Пересылаем разные типы сообщений
    try:
        if message.photo:
            await bot.send_photo(
                ADMIN_ID,
                photo=message.photo[-1].file_id,
                caption=user_info + f"💬 Фото с подписью:\n{message.caption or 'без подписи'}",
                reply_markup=get_reply_keyboard(user.id),
                parse_mode=ParseMode.HTML
            )
        elif message.document:
            await bot.send_document(
                ADMIN_ID,
                document=message.document.file_id,
                caption=user_info + "💬 Документ",
                reply_markup=get_reply_keyboard(user.id),
                parse_mode=ParseMode.HTML
            )
        else:
            await bot.send_message(
                ADMIN_ID,
                text=user_info + f"💬 Сообщение:\n{message.text}",
                reply_markup=get_reply_keyboard(user.id),
                parse_mode=ParseMode.HTML
            )
        
        await message.answer(
            "✅ Сообщение отправлено!\n\n"
            "Мы ответим вам в ближайшее время.",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка отправки: {e}")
    
    await state.clear()

@dp.callback_query(F.data.startswith("reply_"))
async def start_reply(callback: types.CallbackQuery, state: FSMContext):
    """Начало ответа"""
    if callback.from_user.id != ADMIN_ID:
        return
    
    user_id = int(callback.data.split("_")[1])
    await state.update_data(reply_to=user_id)
    await state.set_state(AdminStates.waiting_for_reply)
    
    await callback.message.answer(
        f"📝 Напишите ответ для пользователя {user_id}:\n\n"
        f"(текст, фото или документ)",
        parse_mode=ParseMode.HTML
    )
    await callback.answer()

@dp.message(AdminStates.waiting_for_reply)
async def send_reply(message: types.Message, state: FSMContext):
    """Отправка ответа"""
    if message.from_user.id != ADMIN_ID:
        return
    
    data = await state.get_data()
    user_id = data.get("reply_to")
    
    try:
        if message.photo:
            await bot.send_photo(
                user_id,
                photo=message.photo[-1].file_id,
                caption=f"📩 Ответ от поддержки:\n\n{message.caption or ''}",
                parse_mode=ParseMode.HTML
            )
        elif message.document:
            await bot.send_document(
                user_id,
                document=message.document.file_id,
                caption="📩 Ответ от поддержки",
                parse_mode=ParseMode.HTML
            )
        else:
            await bot.send_message(
                user_id,
                text=f"📩 Ответ от поддержки:\n\n{message.text}",
                parse_mode=ParseMode.HTML
            )
        
        await message.answer("✅ Ответ отправлен!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")
    
    await state.clear()

# ══════════════════════════════════════════════════════════════════
#                    ДРУГИЕ СООБЩЕНИЯ
# ══════════════════════════════════════════════════════════════════

@dp.message()
async def handle_other(message: types.Message):
    """Обработка других сообщений"""
    # Проверка подписки
    is_subscribed, not_subscribed = await check_subscription(message.from_user.id)
    
    if not is_subscribed:
        await message.answer(
            "⚠️ Подпишитесь на каналы:",
            reply_markup=get_subscribe_keyboard(not_subscribed),
            parse_mode=ParseMode.HTML
        )
        return
    
    await message.answer(
        "💡 Используйте кнопки меню или нажмите 💬 Поддержка",
        reply_markup=get_main_keyboard(),
        parse_mode=ParseMode.HTML
    )

# ══════════════════════════════════════════════════════════════════
#                         ЗАПУСК
# ══════════════════════════════════════════════════════════════════

async def main():
    print("=" * 50)
    print("🤖 BitzAI Bot v2.0 запущен!")
    print(f"👤 Admin ID: {ADMIN_ID}")
    print("=" * 50)
    
    # Создаем файл данных если его нет
    if not os.path.exists(DATA_FILE):
        save_data({"users": [], "channels": [], "ads": [], "stats": {}})
    
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())