import os
import subprocess
import logging
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# ========================================
# 🔐 ВСТАВЬ СВОЙ ТОКЕН ЗДЕСЬ
# ========================================
BOT_TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"
# ========================================

# Папка для временных файлов
SCRIPT_DIR = Path(__file__).parent.resolve()
TEMP_DIR = SCRIPT_DIR / "temp_files"
TEMP_DIR.mkdir(exist_ok=True)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Доступные разрешения
RESOLUTIONS = {
    "4k": (3840, 2160),
    "1080p": (1920, 1080),
    "720p": (1280, 720),
    "960x540": (960, 540),
    "480p": (854, 480),
    "360p": (640, 360),
    "240p": (426, 240),
}

# Качество сжатия
QUALITY_OPTIONS = {
    "high": 23,
    "medium": 28,
    "low": 35,
}

# Хранение файлов пользователей
user_files = {}

def find_ffmpeg():
    """Поиск FFmpeg с поддержкой Termux"""
    
    # Сначала проверяем переменную PREFIX (Termux)
    prefix = os.environ.get('PREFIX', '')
    
    possible_paths = []
    
    # Termux пути
    if prefix:
        possible_paths.append(f"{prefix}/bin/ffmpeg")
    possible_paths.extend([
        "/data/data/com.termux/files/usr/bin/ffmpeg",
        # Стандартные Linux
        "/usr/bin/ffmpeg",
        "/usr/local/bin/ffmpeg",
        # Просто ffmpeg (если в PATH)
        "ffmpeg",
        # Windows
        "C:/ffmpeg/bin/ffmpeg.exe",
    ])
    
    for path in possible_paths:
        try:
            result = subprocess.run(
                [path, "-version"], 
                capture_output=True, 
                timeout=10,
                text=True
            )
            if result.returncode == 0:
                logger.info(f"✅ FFmpeg найден: {path}")
                return path
        except FileNotFoundError:
            continue
        except Exception as e:
            logger.debug(f"Проверка {path}: {e}")
            continue
    
    return None

FFMPEG_PATH = find_ffmpeg()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Приветственное сообщение"""
    welcome_text = """
🎬 *Привет! Я бот для обработки медиа!*

📸 *Отправь мне фото* - и я изменю его размер или сожму

🎥 *Отправь мне видео* - и я:
• Изменю разрешение
• Сожму файл
• Конвертирую в GIF

*Доступные разрешения:*
• 4K (3840x2160)
• 1080p (1920x1080)
• 720p (1280x720)
• 960x540
• 480p (854x480)
• 360p (640x360)
• 240p (426x240)

Просто отправь файл и выбери нужное действие! 🚀
    """
    await update.message.reply_text(welcome_text, parse_mode='Markdown')

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка полученных фото"""
    user_id = update.effective_user.id
    photo = update.message.photo[-1]
    file_id = photo.file_id
    
    user_files[user_id] = {"type": "photo", "file_id": file_id}
    
    keyboard = [
        [InlineKeyboardButton("📐 4K (3840x2160)", callback_data="photo_4k")],
        [InlineKeyboardButton("📐 1080p (1920x1080)", callback_data="photo_1080p")],
        [InlineKeyboardButton("📐 720p (1280x720)", callback_data="photo_720p")],
        [InlineKeyboardButton("📐 960x540", callback_data="photo_960x540")],
        [InlineKeyboardButton("📐 480p (854x480)", callback_data="photo_480p")],
        [InlineKeyboardButton("📐 360p (640x360)", callback_data="photo_360p")],
        [InlineKeyboardButton("📐 240p (426x240)", callback_data="photo_240p")],
        [InlineKeyboardButton("🗜 Сжать (высокое качество)", callback_data="photo_compress_high")],
        [InlineKeyboardButton("🗜 Сжать (среднее качество)", callback_data="photo_compress_medium")],
        [InlineKeyboardButton("🗜 Сжать (низкое качество)", callback_data="photo_compress_low")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📸 *Фото получено!*\nВыбери действие:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка полученных видео"""
    user_id = update.effective_user.id
    video = update.message.video or update.message.document
    file_id = video.file_id
    
    user_files[user_id] = {"type": "video", "file_id": file_id}
    
    keyboard = [
        [InlineKeyboardButton("📐 1080p", callback_data="video_1080p"),
         InlineKeyboardButton("📐 720p", callback_data="video_720p")],
        [InlineKeyboardButton("📐 960x540", callback_data="video_960x540"),
         InlineKeyboardButton("📐 480p", callback_data="video_480p")],
        [InlineKeyboardButton("📐 360p", callback_data="video_360p"),
         InlineKeyboardButton("📐 240p", callback_data="video_240p")],
        [InlineKeyboardButton("🗜 Сжать (высокое)", callback_data="video_compress_high")],
        [InlineKeyboardButton("🗜 Сжать (среднее)", callback_data="video_compress_medium")],
        [InlineKeyboardButton("🗜 Сжать (низкое)", callback_data="video_compress_low")],
        [InlineKeyboardButton("🎞 GIF 480p", callback_data="gif_480p"),
         InlineKeyboardButton("🎞 GIF 360p", callback_data="gif_360p")],
        [InlineKeyboardButton("🎞 GIF 240p", callback_data="gif_240p"),
         InlineKeyboardButton("🎞 GIF 960x540", callback_data="gif_960x540")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🎥 *Видео получено!*\nВыбери действие:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

def run_ffmpeg(args: list, timeout: int = 600):
    """Запуск FFmpeg через shell для Termux совместимости"""
    
    if not FFMPEG_PATH:
        return False, "FFmpeg не найден! Установи: pkg install ffmpeg"
    
    # Формируем команду
    cmd = [FFMPEG_PATH] + args
    cmd_str = ' '.join(cmd)
    
    logger.info(f"Запуск: {cmd_str[:200]}...")
    
    try:
        # Используем shell=True для лучшей совместимости с Termux
        result = subprocess.run(
            cmd_str,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        
        logger.info(f"FFmpeg вернул код: {result.returncode}")
        
        if result.returncode != 0:
            error = result.stderr[-500:] if result.stderr else "Неизвестная ошибка"
            logger.error(f"FFmpeg ошибка: {error}")
            return False, f"FFmpeg ошибка: {error[-200:]}"
        
        return True, ""
        
    except subprocess.TimeoutExpired:
        return False, "Таймаут - файл слишком большой или медленное устройство"
    except Exception as e:
        logger.error(f"Исключение: {e}")
        return False, str(e)

async def process_photo_resize(input_path: str, output_path: str, resolution: tuple):
    """Изменение размера фото"""
    width, height = resolution
    args = [
        "-y", "-i", f'"{input_path}"',
        "-vf", f"scale={width}:{height}:force_original_aspect_ratio=decrease",
        "-q:v", "2",
        f'"{output_path}"'
    ]
    return run_ffmpeg(args)

async def process_photo_compress(input_path: str, output_path: str, quality: str):
    """Сжатие фото"""
    quality_map = {"high": 5, "medium": 15, "low": 30}
    q = quality_map.get(quality, 15)
    args = [
        "-y", "-i", f'"{input_path}"',
        "-q:v", str(q),
        f'"{output_path}"'
    ]
    return run_ffmpeg(args)

async def process_video_resize(input_path: str, output_path: str, resolution: tuple):
    """Изменение разрешения видео"""
    width, height = resolution
    # Делаем размеры чётными
    width = width if width % 2 == 0 else width - 1
    height = height if height % 2 == 0 else height - 1
    
    args = [
        "-y", "-i", f'"{input_path}"',
        "-vf", f"scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2",
        "-c:v", "libx264", "-crf", "23", "-preset", "ultrafast",
        "-c:a", "aac", "-b:a", "128k",
        "-movflags", "+faststart",
        f'"{output_path}"'
    ]
    return run_ffmpeg(args)

async def process_video_compress(input_path: str, output_path: str, quality: str):
    """Сжатие видео"""
    crf = QUALITY_OPTIONS.get(quality, 28)
    args = [
        "-y", "-i", f'"{input_path}"',
        "-c:v", "libx264", "-crf", str(crf), "-preset", "ultrafast",
        "-c:a", "aac", "-b:a", "96k",
        "-movflags", "+faststart",
        f'"{output_path}"'
    ]
    return run_ffmpeg(args)

async def process_video_to_gif(input_path: str, output_path: str, resolution: tuple):
    """Конвертация видео в GIF"""
    width = resolution[0]
    # Делаем ширину чётной
    width = width if width % 2 == 0 else width - 1
    
    # Простой метод создания GIF
    args = [
        "-y", "-i", f'"{input_path}"',
        "-vf", f"fps=10,scale={width}:-1:flags=lanczos",
        "-t", "15",  # Максимум 15 секунд
        "-loop", "0",
        f'"{output_path}"'
    ]
    return run_ffmpeg(args, timeout=300)

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка нажатий на кнопки"""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    callback_data = query.data
    
    if user_id not in user_files:
        await query.edit_message_text("❌ Файл не найден. Отправь новый файл.")
        return
    
    file_info = user_files[user_id]
    file_id = file_info["file_id"]
    file_type = file_info["type"]
    
    await query.edit_message_text("⏳ Обрабатываю... Подожди немного!")
    
    try:
        # Скачиваем файл
        file = await context.bot.get_file(file_id)
        
        # Определяем пути к файлам (используем абсолютные пути)
        if file_type == "photo":
            input_path = str(TEMP_DIR / f"{user_id}_input.jpg")
            output_path = str(TEMP_DIR / f"{user_id}_output.jpg")
        else:
            input_path = str(TEMP_DIR / f"{user_id}_input.mp4")
            if "gif" in callback_data:
                output_path = str(TEMP_DIR / f"{user_id}_output.gif")
            else:
                output_path = str(TEMP_DIR / f"{user_id}_output.mp4")
        
        # Удаляем старые файлы
        for p in [input_path, output_path]:
            if os.path.exists(p):
                try:
                    os.remove(p)
                except:
                    pass
        
        # Скачиваем файл
        logger.info(f"Скачиваю файл в: {input_path}")
        await file.download_to_drive(input_path)
        
        if not os.path.exists(input_path):
            raise Exception("Не удалось скачать файл")
        
        input_size = os.path.getsize(input_path)
        logger.info(f"Файл скачан: {input_size} байт")
        
        # Обрабатываем
        success = False
        error_msg = ""
        
        if callback_data.startswith("photo_"):
            action = callback_data.replace("photo_", "")
            if action.startswith("compress_"):
                quality = action.replace("compress_", "")
                success, error_msg = await process_photo_compress(input_path, output_path, quality)
            else:
                resolution = RESOLUTIONS.get(action, (960, 540))
                success, error_msg = await process_photo_resize(input_path, output_path, resolution)
        
        elif callback_data.startswith("video_"):
            action = callback_data.replace("video_", "")
            if action.startswith("compress_"):
                quality = action.replace("compress_", "")
                success, error_msg = await process_video_compress(input_path, output_path, quality)
            else:
                resolution = RESOLUTIONS.get(action, (960, 540))
                success, error_msg = await process_video_resize(input_path, output_path, resolution)
        
        elif callback_data.startswith("gif_"):
            resolution_key = callback_data.replace("gif_", "")
            resolution = RESOLUTIONS.get(resolution_key, (480, 270))
            success, error_msg = await process_video_to_gif(input_path, output_path, resolution)
        
        # Проверяем результат
        if not success:
            raise Exception(error_msg or "Ошибка FFmpeg")
        
        if not os.path.exists(output_path):
            raise Exception(f"Файл не создан. Проверь права на запись в {TEMP_DIR}")
        
        output_size = os.path.getsize(output_path)
        logger.info(f"Готово! Размер: {output_size} байт")
        
        if output_size == 0:
            raise Exception("Выходной файл пустой")
        
        # Отправляем результат
        size_kb = output_size // 1024
        size_mb = size_kb / 1024
        size_text = f"{size_mb:.1f} МБ" if size_mb >= 1 else f"{size_kb} КБ"
        
        with open(output_path, 'rb') as f:
            if callback_data.startswith("photo_"):
                await context.bot.send_photo(
                    chat_id=user_id, 
                    photo=f, 
                    caption=f"✅ Готово! Размер: {size_text}"
                )
            elif callback_data.startswith("video_"):
                await context.bot.send_video(
                    chat_id=user_id, 
                    video=f, 
                    caption=f"✅ Готово! Размер: {size_text}"
                )
            elif callback_data.startswith("gif_"):
                await context.bot.send_animation(
                    chat_id=user_id, 
                    animation=f, 
                    caption=f"✅ GIF готов! Размер: {size_text}"
                )
        
        # Удаляем временные файлы
        for p in [input_path, output_path]:
            try:
                if os.path.exists(p):
                    os.remove(p)
            except:
                pass
                
    except Exception as e:
        logger.error(f"Ошибка: {e}")
        error_text = str(e)
        if len(error_text) > 300:
            error_text = error_text[:300] + "..."
        await context.bot.send_message(
            chat_id=user_id, 
            text=f"❌ Ошибка: {error_text}"
        )

def main():
    """Запуск бота"""
    print("=" * 50)
    print("🤖 Telegram Media Bot")
    print("=" * 50)
    
    if BOT_TOKEN == "ВСТАВЬ_СВОЙ_ТОКЕН_СЮДА":
        print("❌ ОШИБКА: Вставь свой токен бота!")
        print("Получи токен у @BotFather в Telegram")
        return
    
    # Проверяем FFmpeg
    if FFMPEG_PATH:
        print(f"✅ FFmpeg: {FFMPEG_PATH}")
    else:
        print("❌ FFmpeg НЕ НАЙДЕН!")
        print("")
        print("📱 Для Termux выполни:")
        print("   pkg update && pkg install ffmpeg")
        print("")
        print("🐧 Для Linux:")
        print("   sudo apt install ffmpeg")
        print("")
        return
    
    print(f"📁 Временная папка: {TEMP_DIR}")
    print("")
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.VIDEO | filters.Document.VIDEO, handle_video))
    application.add_handler(CallbackQueryHandler(button_callback))
    
    print("🚀 Бот запущен! Ожидаю сообщения...")
    print("Для остановки нажми Ctrl+C")
    print("")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()

