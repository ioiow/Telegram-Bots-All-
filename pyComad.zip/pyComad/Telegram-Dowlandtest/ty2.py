import os
import re
import asyncio
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import yt_dlp
from urllib.parse import urlparse
import tempfile
import shutil
import glob
from concurrent.futures import ThreadPoolExecutor

# Минимальное логирование
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

# =============================================
# 🔑 ВСТАВЬТЕ ВАШ ТОКЕН СЮДА
# =============================================
BOT_TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"

# Пул потоков для быстрого скачивания
executor = ThreadPoolExecutor(max_workers=4)

# Ключевые слова для определения приватного контента
PRIVATE_KEYWORDS = [
    'private video', 'video is private', 'приватное', 
    'login required', 'sign in', 'авторизац',
    'private account', 'this account is private',
    'video unavailable', 'is not available',
    'join this channel', 'подписчик',
    'members only', 'subscribers only',
    'this video is protected', 'protected video',
    'age-restricted', 'age restricted', 'confirm your age',
    'content isn\'t available', 'page not found',
    'removed', 'deleted', 'taken down'
]

# Регулярные выражения для платформ
PATTERNS = {
    'youtube': r'(youtube\.com|youtu\.be)',
    'instagram': r'(instagram\.com|instagr\.am)',
    'tiktok': r'(tiktok\.com|vm\.tiktok\.com)',
    'snapchat': r'(snapchat\.com|story\.snapchat\.com)',
    'pinterest': r'(pinterest\.com|pin\.it)'
}

def detect_platform(url: str) -> str:
    for platform, pattern in PATTERNS.items():
        if re.search(pattern, url, re.IGNORECASE):
            return platform
    return None

def is_private_error(error_msg: str) -> bool:
    """Проверяет, является ли ошибка из-за приватности"""
    error_lower = error_msg.lower()
    return any(keyword in error_lower for keyword in PRIVATE_KEYWORDS)

def get_ydl_opts(output_path: str, platform: str = None) -> dict:
    """Быстрые настройки для yt-dlp"""
    opts = {
        'outtmpl': os.path.join(output_path, '%(id)s.%(ext)s'),
        'quiet': True,
        'no_warnings': True,
        'no_color': True,
        'socket_timeout': 15,
        'retries': 2,
        'fragment_retries': 2,
        'concurrent_fragment_downloads': 4,  # Параллельная загрузка
        'buffersize': 1024 * 64,  # Больший буфер
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    }
    
    # Быстрые форматы для каждой платформы
    if platform == 'youtube':
        opts['format'] = 'best[filesize<50M][ext=mp4]/best[height<=720][ext=mp4]/best[ext=mp4]/best'
    elif platform == 'tiktok':
        opts['format'] = 'best[ext=mp4]/best'
    elif platform == 'pinterest':
        opts['format'] = 'best'
    else:
        opts['format'] = 'best[ext=mp4]/best'
    
    return opts

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""
🎬 *Video Downloader Bot*

Привет! Я скачиваю видео и фото с:

📺 YouTube • 📸 Instagram • 🎵 TikTok
👻 Snapchat • 📌 Pinterest

Просто отправь ссылку! 🔗
/help
    """, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""
📖 *Как использовать:*

1️⃣ Скопируй ссылку на видео/фото
2️⃣ Отправь мне
3️⃣ Получи файл!

⚠️ *Ограничения:*
• Макс. размер: 50 МБ
• Приватный контент недоступен
    """, parse_mode='Markdown')

def find_file(output_path: str) -> str:
    """Быстрый поиск скачанного файла"""
    for ext in ['mp4', 'jpg', 'jpeg', 'png', 'webp', 'webm', 'mkv', 'gif']:
        files = glob.glob(os.path.join(output_path, f'*.{ext}'))
        if files:
            return files[0]
    all_files = [f for f in glob.glob(os.path.join(output_path, '*')) if os.path.isfile(f)]
    return all_files[0] if all_files else None

def is_photo(filename: str) -> bool:
    return os.path.splitext(filename)[1].lower() in ['.jpg', '.jpeg', '.png', '.webp', '.gif']

def download_sync(url: str, output_path: str, platform: str) -> dict:
    """Синхронное скачивание (выполняется в отдельном потоке)"""
    opts = get_ydl_opts(output_path, platform)
    
    if platform == 'tiktok' and '/photo/' in url:
        opts['format'] = 'best'
    
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            
            if info is None:
                return {'error': 'not_found'}
            
            filename = find_file(output_path)
            if not filename:
                return {'error': 'not_found'}
            
            title = info.get('title') or info.get('description', '')[:50] or ''
            
            return {
                'filename': filename,
                'title': title[:80],
                'is_photo': is_photo(filename)
            }
            
    except Exception as e:
        error_str = str(e)
        if is_private_error(error_str):
            return {'error': 'private'}
        return {'error': 'failed', 'message': error_str}

async def process_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Быстрая обработка ссылок"""
    url = update.message.text.strip()
    
    if not re.match(r'https?://', url):
        return
    
    platform = detect_platform(url)
    if not platform:
        return
    
    emoji = {'youtube': '📺', 'instagram': '📸', 'tiktok': '🎵', 'snapchat': '👻', 'pinterest': '📌'}
    
    # Быстрое сообщение о загрузке
    status = await update.message.reply_text(f"{emoji.get(platform, '📥')} Скачиваю...")
    
    temp_dir = tempfile.mkdtemp()
    
    try:
        # Скачивание в отдельном потоке (не блокирует бота)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(executor, download_sync, url, temp_dir, platform)
        
        # Проверка на приватность
        if result.get('error') == 'private':
            await status.edit_text("🔒 Это видео приватное или недоступно")
            return
        
        if result.get('error'):
            await status.delete()
            return
        
        filename = result['filename']
        file_size = os.path.getsize(filename)
        
        if file_size > 50 * 1024 * 1024:
            await status.edit_text("📦 Файл слишком большой (>50 МБ)")
            return
        
        # Мгновенная отправка
        caption = f"✅ {result['title']}" if result['title'] else "✅"
        
        with open(filename, 'rb') as f:
            try:
                if result['is_photo']:
                    await update.message.reply_photo(
                        photo=f, 
                        caption=caption,
                        read_timeout=60,
                        write_timeout=60
                    )
                else:
                    await update.message.reply_video(
                        video=f, 
                        caption=caption,
                        supports_streaming=True,  # Стриминг для быстрого просмотра
                        read_timeout=60,
                        write_timeout=60
                    )
            except:
                f.seek(0)
                await update.message.reply_document(document=f, caption=caption)
        
        await status.delete()
        
    except Exception as e:
        try:
            await status.delete()
        except:
            pass
        logger.warning(f"Error: {e}")
        
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def main():
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ Установите BOT_TOKEN!")
        return
    
    print("🚀 Бот запускается...")
    
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .read_timeout(60)
        .write_timeout(60)
        .connect_timeout(30)
        .pool_timeout(30)
        .build()
    )
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, process_url))
    
    print("✅ Бот запущен!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()