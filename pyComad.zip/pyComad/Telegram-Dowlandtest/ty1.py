import os
import re
import asyncio
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import yt_dlp
import requests
from urllib.parse import urlparse
import tempfile
import shutil
import glob

# Настройка логирования (только в консоль для отладки)
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.WARNING  # Меньше логов
)
logger = logging.getLogger(__name__)

# =============================================
# 🔑 ВСТАВЬТЕ ВАШ ТОКЕН СЮДА
# =============================================
BOT_TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"

# Настройки
MAX_RETRIES = 3  # Количество попыток при ошибке
RETRY_DELAY = 2  # Задержка между попытками (сек)

# Регулярные выражения для определения платформы
PATTERNS = {
    'youtube': r'(youtube\.com|youtu\.be)',
    'instagram': r'(instagram\.com|instagr\.am)',
    'tiktok': r'(tiktok\.com|vm\.tiktok\.com)',
    'snapchat': r'(snapchat\.com|story\.snapchat\.com)',
    'pinterest': r'(pinterest\.com|pin\.it)'
}

def detect_platform(url: str) -> str:
    """Определяет платформу по URL"""
    for platform, pattern in PATTERNS.items():
        if re.search(pattern, url, re.IGNORECASE):
            return platform
    return None

def get_ydl_opts(output_path: str, platform: str = None) -> dict:
    """Возвращает оптимальные настройки для yt-dlp"""
    base_opts = {
        'outtmpl': os.path.join(output_path, '%(id)s.%(ext)s'),
        'quiet': True,
        'no_warnings': True,
        'ignoreerrors': True,
        'no_color': True,
        'socket_timeout': 30,
        'retries': 5,
        'fragment_retries': 5,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    }
    
    # Специфичные настройки для платформ
    if platform == 'pinterest':
        base_opts['format'] = 'best[ext=mp4]/best[ext=jpg]/best[ext=png]/best'
    elif platform == 'tiktok':
        base_opts['format'] = 'best[ext=mp4]/best'
    elif platform == 'youtube':
        base_opts['format'] = 'best[filesize<50M][ext=mp4]/best[filesize<50M]/best[ext=mp4]/best'
    else:
        base_opts['format'] = 'best[ext=mp4]/best'
    
    return base_opts

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    welcome_message = """
🎬 *Video Downloader Bot*

Привет! Я могу скачать видео и фото с:

📺 YouTube
📸 Instagram  
🎵 TikTok
👻 Snapchat
📌 Pinterest

Просто отправь мне ссылку! 🔗

*Команды:*
/start - Показать это сообщение
/help - Помощь
    """
    await update.message.reply_text(welcome_message, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /help"""
    help_text = """
📖 *Как использовать бота:*

1️⃣ Скопируйте ссылку на видео или фото
2️⃣ Отправьте ссылку в этот чат
3️⃣ Дождитесь загрузки

*Поддерживаемые ссылки:*

• YouTube: youtube.com/watch?v=... или youtu.be/...
• Instagram: instagram.com/p/... или instagram.com/reel/...
• TikTok: tiktok.com/@user/video/...
• Snapchat: story.snapchat.com/...
• Pinterest: pinterest.com/pin/...

⚠️ *Ограничения:*
• Максимальный размер файла: 50 МБ
• Приватный контент недоступен
    """
    await update.message.reply_text(help_text, parse_mode='Markdown')

def find_downloaded_file(output_path: str) -> str:
    """Находит скачанный файл в директории"""
    patterns = ['*.mp4', '*.jpg', '*.jpeg', '*.png', '*.webp', '*.gif', '*.webm', '*.mkv']
    for pattern in patterns:
        files = glob.glob(os.path.join(output_path, pattern))
        if files:
            return files[0]
    # Если не нашли по расширению, берём любой файл
    all_files = glob.glob(os.path.join(output_path, '*'))
    files = [f for f in all_files if os.path.isfile(f)]
    return files[0] if files else None

def get_media_type(filename: str) -> str:
    """Определяет тип медиа по расширению"""
    ext = os.path.splitext(filename)[1].lower()
    if ext in ['.jpg', '.jpeg', '.png', '.webp', '.gif']:
        return 'photo'
    return 'video'

async def download_media(url: str, output_path: str, platform: str) -> dict:
    """Универсальная функция скачивания с повторными попытками"""
    last_error = None
    
    for attempt in range(MAX_RETRIES):
        try:
            ydl_opts = get_ydl_opts(output_path, platform)
            
            # Для TikTok фото используем альтернативный подход
            if platform == 'tiktok' and '/photo/' in url:
                ydl_opts['format'] = 'best'
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                
                if info is None:
                    raise Exception("Не удалось получить информацию")
                
                # Ищем скачанный файл
                filename = find_downloaded_file(output_path)
                
                if not filename or not os.path.exists(filename):
                    raise Exception("Файл не найден")
                
                media_type = get_media_type(filename)
                title = info.get('title', '') or info.get('description', '')[:50] or 'Media'
                
                return {
                    'filename': filename,
                    'title': title[:100],  # Ограничиваем длину
                    'type': media_type
                }
                
        except Exception as e:
            last_error = e
            if attempt < MAX_RETRIES - 1:
                await asyncio.sleep(RETRY_DELAY)
                continue
    
    raise last_error

async def process_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ссылок"""
    url = update.message.text.strip()
    
    # Проверяем, является ли сообщение URL
    if not re.match(r'https?://', url):
        return  # Тихо игнорируем не-ссылки
    
    platform = detect_platform(url)
    
    if not platform:
        return  # Тихо игнорируем неподдерживаемые ссылки
    
    # Отправляем сообщение о начале загрузки
    platform_emoji = {
        'youtube': '📺',
        'instagram': '📸',
        'tiktok': '🎵',
        'snapchat': '👻',
        'pinterest': '📌'
    }
    
    status_message = await update.message.reply_text(
        f"{platform_emoji.get(platform, '📥')} Загружаю..."
    )
    
    temp_dir = None
    
    try:
        # Создаём временную директорию для загрузки
        temp_dir = tempfile.mkdtemp()
        
        # Скачиваем
        result = await download_media(url, temp_dir, platform)
        
        filename = result['filename']
        media_type = result['type']
        title = result['title']
        
        # Проверяем размер файла
        file_size = os.path.getsize(filename)
        if file_size > 50 * 1024 * 1024:  # 50 MB
            await status_message.edit_text("📦 Файл слишком большой для Telegram")
            return
        
        # Отправляем файл
        await status_message.edit_text("📤 Отправляю...")
        
        with open(filename, 'rb') as f:
            caption = f"✅ {title}" if title and title != 'Media' else "✅ Готово!"
            
            try:
                if media_type == 'video':
                    await update.message.reply_video(video=f, caption=caption)
                else:
                    await update.message.reply_photo(photo=f, caption=caption)
            except Exception:
                # Если не удалось отправить как видео/фото, отправляем как документ
                f.seek(0)
                await update.message.reply_document(document=f, caption=caption)
        
        # Удаляем статусное сообщение после успешной отправки
        await status_message.delete()
        
    except Exception as e:
        # Тихо удаляем сообщение о загрузке при ошибке
        try:
            await status_message.delete()
        except:
            pass
        # Логируем ошибку только в консоль (не пользователю)
        logger.warning(f"Download failed for {url}: {e}")
        
    finally:
        # Очищаем временные файлы
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except:
                pass

def main():
    """Запуск бота"""
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ Ошибка: Установите BOT_TOKEN!")
        print("Получите токен у @BotFather в Telegram")
        return
    
    print("🚀 Запуск бота...")
    
    # Создаём приложение с увеличенными таймаутами
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .read_timeout(60)
        .write_timeout(60)
        .connect_timeout(30)
        .build()
    )
    
    # Добавляем обработчики
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, process_url))
    
    # Запускаем бота
    print("✅ Бот запущен! Нажмите Ctrl+C для остановки")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()