import os
import re
import asyncio
from telegram import Update, InputFile
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import yt_dlp
import tempfile
import shutil
from concurrent.futures import ProcessPoolExecutor

# =============================================
# 🔑 ВСТАВЬТЕ ВАШ ТОКЕН СЮДА
# =============================================
BOT_TOKEN = "8300587383:AAF8u1_nbEQ7GF3KKW6iuF-Gp5lLEFhVd88"

# Процессы для МАКСИМАЛЬНОЙ скорости (быстрее потоков)
executor = ProcessPoolExecutor(max_workers=8)

# Приватный контент
PRIVATE_KW = ['private', 'login', 'sign in', 'unavailable', 'restricted', 'removed', 'deleted', 'members only']

# Платформы
PLATFORMS = {
    'youtube': r'(youtube\.com|youtu\.be)',
    'instagram': r'(instagram\.com|instagr\.am)',
    'tiktok': r'(tiktok\.com|vm\.tiktok)',
    'snapchat': r'snapchat\.com',
    'pinterest': r'(pinterest|pin\.it)'
}

def download(url: str, path: str) -> dict:
    """Молниеносное скачивание"""
    opts = {
        'outtmpl': f'{path}/%(id)s.%(ext)s',
        'format': 'best[filesize<50M]/best[height<=480]/best',  # Лёгкий формат = быстро
        'quiet': True,
        'no_warnings': True,
        'extract_flat': False,
        'socket_timeout': 10,
        'retries': 1,
        'concurrent_fragment_downloads': 8,  # Максимум параллельных загрузок
        'buffersize': 1024 * 128,  # Огромный буфер
        'http_chunk_size': 1024 * 1024,  # Большие чанки
        'noprogress': True,
        'no_color': True,
        'geo_bypass': True,
        'nocheckcertificate': True,  # Пропуск проверок = быстрее
    }
    
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            if not info:
                return {'error': 'none'}
            
            # Быстрый поиск файла
            for f in os.listdir(path):
                fp = os.path.join(path, f)
                if os.path.isfile(fp):
                    ext = f.split('.')[-1].lower()
                    return {
                        'file': fp,
                        'photo': ext in ['jpg', 'jpeg', 'png', 'webp', 'gif'],
                        'title': (info.get('title') or '')[:60]
                    }
            return {'error': 'none'}
    except Exception as e:
        err = str(e).lower()
        if any(k in err for k in PRIVATE_KW):
            return {'error': 'private'}
        return {'error': 'fail'}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🎬 *Video Downloader*\n\n"
        "📺 YouTube • 📸 Instagram • 🎵 TikTok\n"
        "👻 Snapchat • 📌 Pinterest\n\n"
        "Отправь ссылку — получи файл! ⚡",
        parse_mode='Markdown'
    )

async def process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text.strip()
    
    # Быстрая проверка
    if not url.startswith('http'):
        return
    
    platform = None
    for p, pattern in PLATFORMS.items():
        if re.search(pattern, url, re.I):
            platform = p
            break
    if not platform:
        return
    
    icons = {'youtube': '📺', 'instagram': '📸', 'tiktok': '🎵', 'snapchat': '👻', 'pinterest': '📌'}
    msg = await update.message.reply_text(f"{icons.get(platform, '📥')} ⚡")
    
    tmp = tempfile.mkdtemp()
    
    try:
        # Скачивание в отдельном ПРОЦЕССЕ (максимальная скорость)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(executor, download, url, tmp)
        
        if result.get('error') == 'private':
            await msg.edit_text("🔒 Приватное видео")
            return
        
        if result.get('error'):
            await msg.delete()
            return
        
        fp = result['file']
        
        if os.path.getsize(fp) > 50 * 1024 * 1024:
            await msg.edit_text("📦 Файл > 50 МБ")
            return
        
        # МГНОВЕННАЯ отправка
        caption = f"✅ {result['title']}" if result['title'] else "✅"
        
        with open(fp, 'rb') as f:
            if result['photo']:
                await update.message.reply_photo(f, caption=caption)
            else:
                await update.message.reply_video(
                    f, caption=caption,
                    supports_streaming=True,
                    read_timeout=120,
                    write_timeout=120
                )
        
        await msg.delete()
        
    except:
        try:
            await msg.delete()
        except:
            pass
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def main():
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ Вставьте BOT_TOKEN!")
        return
    
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .read_timeout(120)
        .write_timeout(120)
        .connect_timeout(60)
        .concurrent_updates(True)  # Параллельная обработка сообщений
        .build()
    )
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, process))
    
    print("⚡ Бот запущен!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()